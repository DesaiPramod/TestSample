using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.Compatibility.VB6;

namespace SKS
{
	/// <summary>
	/// Summary description for frmOrderReception.
	/// </summary>
	public class frmOrderReception : System.Windows.Forms.Form
	{
		public System.Windows.Forms.TextBox txtNotes;
		public System.Windows.Forms.TextBox txtSubTotal;
		public System.Windows.Forms.TextBox txtTotal;
		public System.Windows.Forms.TextBox txtTotalTax;
		public System.Windows.Forms.TextBox txtFreightCharge;
		public System.Windows.Forms.TextBox txtSalesTax;
		public System.Windows.Forms.TextBox txtEntry;
		public AxMSFlexGridLib.AxMSFlexGrid fgProducts;
		public System.Windows.Forms.StatusBar sbStatusBar;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel1;
		public System.Windows.Forms.Button cmdSave;
		public System.Windows.Forms.Button cmdClose;
		public System.Windows.Forms.Button cmdAddProducts;
		public System.Windows.Forms.GroupBox Frame1;
		public System.Windows.Forms.TextBox txtProviderName;
		public System.Windows.Forms.TextBox txtContactLastName;
		public System.Windows.Forms.TextBox txtContactName;
		public System.Windows.Forms.Button cmdProviders;
		public System.Windows.Forms.ListView lvProviders;
		private System.Windows.Forms.ColumnHeader lvProvidersColumnHeader0;
		private System.Windows.Forms.ColumnHeader lvProvidersColumnHeader1;
		private System.Windows.Forms.ColumnHeader lvProvidersColumnHeader2;
		private System.Windows.Forms.ColumnHeader lvProvidersColumnHeader3;
		private System.Windows.Forms.ColumnHeader lvProvidersColumnHeader4;
		private System.Windows.Forms.ColumnHeader lvProvidersColumnHeader5;
		private System.Windows.Forms.ColumnHeader lvProvidersColumnHeader6;
		public System.Windows.Forms.Label Label3;
		public System.Windows.Forms.Label Label4;
		public System.Windows.Forms.Label Label2;
		public System.Windows.Forms.GroupBox Frame2;
		public System.Windows.Forms.TextBox txtProviderContact;
		public System.Windows.Forms.TextBox txtProviderCompany;
		public System.Windows.Forms.Label Label5;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.Label Label7;
		public System.Windows.Forms.Label Label12;
		public System.Windows.Forms.Label Label11;
		public System.Windows.Forms.Label Label10;
		public System.Windows.Forms.Label Label9;
		public System.Windows.Forms.Label Label8;
		public System.Windows.Forms.Label Label6;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmOrderReception()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmOrderReception InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmOrderReception();
				return _InstancePtr;
			}
		}
		protected static frmOrderReception _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmOrderReception));
			this.txtNotes = new System.Windows.Forms.TextBox();
			this.txtSubTotal = new System.Windows.Forms.TextBox();
			this.txtTotal = new System.Windows.Forms.TextBox();
			this.txtTotalTax = new System.Windows.Forms.TextBox();
			this.txtFreightCharge = new System.Windows.Forms.TextBox();
			this.txtSalesTax = new System.Windows.Forms.TextBox();
			this.txtEntry = new System.Windows.Forms.TextBox();
			this.fgProducts = new AxMSFlexGridLib.AxMSFlexGrid();
			this.sbStatusBar = new System.Windows.Forms.StatusBar();
			this.sbStatusBar_Panel1 = new System.Windows.Forms.StatusBarPanel();
			this.cmdSave = new System.Windows.Forms.Button();
			this.cmdClose = new System.Windows.Forms.Button();
			this.cmdAddProducts = new System.Windows.Forms.Button();
			this.Frame1 = new System.Windows.Forms.GroupBox();
			this.txtProviderName = new System.Windows.Forms.TextBox();
			this.txtContactLastName = new System.Windows.Forms.TextBox();
			this.txtContactName = new System.Windows.Forms.TextBox();
			this.cmdProviders = new System.Windows.Forms.Button();
			this.lvProviders = new System.Windows.Forms.ListView();
			this.lvProvidersColumnHeader0 = new System.Windows.Forms.ColumnHeader();
			this.lvProvidersColumnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.lvProvidersColumnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.lvProvidersColumnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.lvProvidersColumnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.lvProvidersColumnHeader5 = new System.Windows.Forms.ColumnHeader();
			this.lvProvidersColumnHeader6 = new System.Windows.Forms.ColumnHeader();
			this.Label3 = new System.Windows.Forms.Label();
			this.Label4 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.Frame2 = new System.Windows.Forms.GroupBox();
			this.txtProviderContact = new System.Windows.Forms.TextBox();
			this.txtProviderCompany = new System.Windows.Forms.TextBox();
			this.Label5 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.Label7 = new System.Windows.Forms.Label();
			this.Label12 = new System.Windows.Forms.Label();
			this.Label11 = new System.Windows.Forms.Label();
			this.Label10 = new System.Windows.Forms.Label();
			this.Label9 = new System.Windows.Forms.Label();
			this.Label8 = new System.Windows.Forms.Label();
			this.Label6 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			//
			// txtNotes
			//
			this.txtNotes.Name = "txtNotes";
			this.txtNotes.TabIndex = 4;
			this.txtNotes.Location = new System.Drawing.Point(57, 324);
			this.txtNotes.Size = new System.Drawing.Size(430, 44);
			this.txtNotes.Text = "";
			this.txtNotes.BackColor = System.Drawing.SystemColors.Window;
			this.txtNotes.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtNotes.Multiline = true;
			this.txtNotes.TextChanged += new System.EventHandler(this.txtNotes_TextChanged);
			//
			// txtSubTotal
			//
			this.txtSubTotal.Name = "txtSubTotal";
			this.txtSubTotal.TabStop = false;
			this.txtSubTotal.TabIndex = 30;
			this.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtSubTotal.Location = new System.Drawing.Point(356, 607);
			this.txtSubTotal.Size = new System.Drawing.Size(147, 20);
			this.txtSubTotal.Text = "";
			this.txtSubTotal.BackColor = System.Drawing.SystemColors.Menu;
			this.txtSubTotal.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtSubTotal.ReadOnly = true;
			//
			// txtTotal
			//
			this.txtTotal.Name = "txtTotal";
			this.txtTotal.TabStop = false;
			this.txtTotal.TabIndex = 28;
			this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtTotal.Location = new System.Drawing.Point(97, 631);
			this.txtTotal.Size = new System.Drawing.Size(147, 20);
			this.txtTotal.Text = "";
			this.txtTotal.BackColor = System.Drawing.SystemColors.Menu;
			this.txtTotal.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtTotal.ReadOnly = true;
			//
			// txtTotalTax
			//
			this.txtTotalTax.Name = "txtTotalTax";
			this.txtTotalTax.TabStop = false;
			this.txtTotalTax.TabIndex = 26;
			this.txtTotalTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtTotalTax.Location = new System.Drawing.Point(356, 582);
			this.txtTotalTax.Size = new System.Drawing.Size(147, 20);
			this.txtTotalTax.Text = "";
			this.txtTotalTax.BackColor = System.Drawing.SystemColors.Menu;
			this.txtTotalTax.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtTotalTax.ReadOnly = true;
			//
			// txtFreightCharge
			//
			this.txtFreightCharge.Name = "txtFreightCharge";
			this.txtFreightCharge.TabIndex = 7;
			this.txtFreightCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtFreightCharge.Location = new System.Drawing.Point(97, 607);
			this.txtFreightCharge.Size = new System.Drawing.Size(147, 20);
			this.txtFreightCharge.Text = "";
			this.txtFreightCharge.BackColor = System.Drawing.SystemColors.Window;
			this.txtFreightCharge.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtFreightCharge.TextChanged += new System.EventHandler(this.txtFreightCharge_TextChanged);
			this.txtFreightCharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFreightCharge_KeyPress);
			//
			// txtSalesTax
			//
			this.txtSalesTax.Name = "txtSalesTax";
			this.txtSalesTax.TabIndex = 6;
			this.txtSalesTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtSalesTax.Location = new System.Drawing.Point(97, 582);
			this.txtSalesTax.Size = new System.Drawing.Size(147, 20);
			this.txtSalesTax.Text = "";
			this.txtSalesTax.BackColor = System.Drawing.SystemColors.Window;
			this.txtSalesTax.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtSalesTax.TextChanged += new System.EventHandler(this.txtSalesTax_TextChanged);
			this.txtSalesTax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSalesTax_KeyPress);
			//
			// txtEntry
			//
			this.txtEntry.Name = "txtEntry";
			this.txtEntry.Visible = false;
			this.txtEntry.TabIndex = 23;
			this.txtEntry.Location = new System.Drawing.Point(97, 558);
			this.txtEntry.Size = new System.Drawing.Size(147, 19);
			this.txtEntry.Text = "";
			this.txtEntry.BackColor = System.Drawing.SystemColors.Window;
			this.txtEntry.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtEntry.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEntry_KeyDown);
			this.txtEntry.Leave += new System.EventHandler(this.txtEntry_Leave);
			this.txtEntry.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEntry_KeyPress);
			//
			// fgProducts
			//
			this.fgProducts.Name = "fgProducts";
			this.fgProducts.TabIndex = 5;
			this.fgProducts.Location = new System.Drawing.Point(8, 380);
			this.fgProducts.Size = new System.Drawing.Size(511, 171);
			this.fgProducts.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("fgProducts.OcxState")));
			this.fgProducts.ClickEvent += new System.EventHandler(this.fgProducts_ClickEvent);
			this.fgProducts.EnterCell += new System.EventHandler(this.fgProducts_EnterCell);
			this.fgProducts.KeyPressEvent += new AxMSFlexGridLib.DMSFlexGridEvents_KeyPressEventHandler(this.fgProducts_KeyPressEvent);
			this.fgProducts.LeaveCell += new System.EventHandler(this.fgProducts_LeaveCell);
			//
			// sbStatusBar
			//
			this.sbStatusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {this.sbStatusBar_Panel1});
			this.sbStatusBar.Name = "sbStatusBar";
			this.sbStatusBar.TabIndex = 22;
			this.sbStatusBar.Location = new System.Drawing.Point(0, 686);
			this.sbStatusBar.Size = new System.Drawing.Size(527, 25);
			this.sbStatusBar.ShowPanels = true;
			this.sbStatusBar.SizingGrip = false;
			//
			// Panel1
			//
			this.sbStatusBar_Panel1.Text = "";
			this.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbStatusBar_Panel1.Width = 525;
			//
			// cmdSave
			//
			this.cmdSave.Name = "cmdSave";
			this.cmdSave.TabIndex = 8;
			this.cmdSave.Location = new System.Drawing.Point(324, 655);
			this.cmdSave.Size = new System.Drawing.Size(90, 25);
			this.cmdSave.Text = "&Save";
			this.cmdSave.BackColor = System.Drawing.SystemColors.Control;
			this.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
			//
			// cmdClose
			//
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.TabIndex = 9;
			this.cmdClose.Location = new System.Drawing.Point(429, 655);
			this.cmdClose.Size = new System.Drawing.Size(90, 25);
			this.cmdClose.Text = "&Close";
			this.cmdClose.BackColor = System.Drawing.SystemColors.Control;
			this.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			//
			// cmdAddProducts
			//
			this.cmdAddProducts.Name = "cmdAddProducts";
			this.cmdAddProducts.TabStop = false;
			this.cmdAddProducts.TabIndex = 20;
			this.cmdAddProducts.Location = new System.Drawing.Point(493, 348);
			this.cmdAddProducts.Size = new System.Drawing.Size(25, 23);
			this.cmdAddProducts.Text = "...";
			this.cmdAddProducts.BackColor = System.Drawing.SystemColors.Control;
			this.cmdAddProducts.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdAddProducts.Click += new System.EventHandler(this.cmdAddProducts_Click);
			//
			// Frame1
			//
			this.Frame1.Controls.Add(this.txtProviderName);
			this.Frame1.Controls.Add(this.txtContactLastName);
			this.Frame1.Controls.Add(this.txtContactName);
			this.Frame1.Controls.Add(this.cmdProviders);
			this.Frame1.Controls.Add(this.lvProviders);
			this.Frame1.Controls.Add(this.Label3);
			this.Frame1.Controls.Add(this.Label4);
			this.Frame1.Controls.Add(this.Label2);
			this.Frame1.Name = "Frame1";
			this.Frame1.TabIndex = 11;
			this.Frame1.Location = new System.Drawing.Point(8, 8);
			this.Frame1.Size = new System.Drawing.Size(511, 252);
			this.Frame1.Text = "Search supplier";
			this.Frame1.BackColor = System.Drawing.SystemColors.Control;
			this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// txtProviderName
			//
			this.txtProviderName.Name = "txtProviderName";
			this.txtProviderName.TabIndex = 0;
			this.txtProviderName.Location = new System.Drawing.Point(89, 16);
			this.txtProviderName.Size = new System.Drawing.Size(147, 20);
			this.txtProviderName.Text = "";
			this.txtProviderName.BackColor = System.Drawing.SystemColors.Window;
			this.txtProviderName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtProviderName.TextChanged += new System.EventHandler(this.txtProviderName_TextChanged);
			//
			// txtContactLastName
			//
			this.txtContactLastName.Name = "txtContactLastName";
			this.txtContactLastName.TabIndex = 2;
			this.txtContactLastName.Location = new System.Drawing.Point(340, 49);
			this.txtContactLastName.Size = new System.Drawing.Size(147, 20);
			this.txtContactLastName.Text = "";
			this.txtContactLastName.BackColor = System.Drawing.SystemColors.Window;
			this.txtContactLastName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtContactLastName.TextChanged += new System.EventHandler(this.txtContactLastName_TextChanged);
			//
			// txtContactName
			//
			this.txtContactName.Name = "txtContactName";
			this.txtContactName.TabIndex = 1;
			this.txtContactName.Location = new System.Drawing.Point(89, 49);
			this.txtContactName.Size = new System.Drawing.Size(147, 20);
			this.txtContactName.Text = "";
			this.txtContactName.BackColor = System.Drawing.SystemColors.Window;
			this.txtContactName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtContactName.TextChanged += new System.EventHandler(this.txtContactName_TextChanged);
			//
			// cmdProviders
			//
			this.cmdProviders.Name = "cmdProviders";
			this.cmdProviders.TabStop = false;
			this.cmdProviders.TabIndex = 12;
			this.cmdProviders.Location = new System.Drawing.Point(461, 16);
			this.cmdProviders.Size = new System.Drawing.Size(25, 23);
			this.cmdProviders.Text = "...";
			this.cmdProviders.BackColor = System.Drawing.SystemColors.Control;
			this.cmdProviders.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdProviders.Click += new System.EventHandler(this.cmdProviders_Click);
			//
			// lvProviders
			//
			this.lvProviders.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {this.lvProvidersColumnHeader0, this.lvProvidersColumnHeader1, this.lvProvidersColumnHeader2, this.lvProvidersColumnHeader3, this.lvProvidersColumnHeader4, this.lvProvidersColumnHeader5, this.lvProvidersColumnHeader6});
			this.lvProviders.Name = "lvProviders";
			this.lvProviders.TabIndex = 3;
			this.lvProviders.Location = new System.Drawing.Point(8, 81);
			this.lvProviders.Size = new System.Drawing.Size(494, 163);
			this.lvProviders.BackColor = System.Drawing.SystemColors.Window;
			this.lvProviders.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lvProviders.View = System.Windows.Forms.View.Details;
			this.lvProviders.MultiSelect = false;
			this.lvProviders.GridLines = true;
			this.lvProviders.FullRowSelect = true;
			this.lvProviders.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lvProviders.HideSelection = false;
			this.lvProviders.SelectedIndexChanged += new System.EventHandler(this.lvProviders_SelectedIndexChanged);
			//
			// ColumnHeader(1)
			//
			this.lvProvidersColumnHeader0.Text = "Supplier ID";
			this.lvProvidersColumnHeader0.Width = 98;
			//
			// ColumnHeader(2)
			//
			this.lvProvidersColumnHeader1.Text = "Supplier Name";
			this.lvProvidersColumnHeader1.Width = 98;
			//
			// ColumnHeader(3)
			//
			this.lvProvidersColumnHeader2.Text = "Contact Name";
			this.lvProvidersColumnHeader2.Width = 98;
			//
			// ColumnHeader(4)
			//
			this.lvProvidersColumnHeader3.Text = "Contact Last Name";
			this.lvProvidersColumnHeader3.Width = 98;
			//
			// ColumnHeader(5)
			//
			this.lvProvidersColumnHeader4.Text = "City";
			this.lvProvidersColumnHeader4.Width = 98;
			//
			// ColumnHeader(6)
			//
			this.lvProvidersColumnHeader5.Text = "State";
			this.lvProvidersColumnHeader5.Width = 98;
			//
			// ColumnHeader(7)
			//
			this.lvProvidersColumnHeader6.Text = "Country";
			this.lvProvidersColumnHeader6.Width = 98;
			//
			// Label3
			//
			this.Label3.Name = "Label3";
			this.Label3.TabIndex = 15;
			this.Label3.Location = new System.Drawing.Point(243, 49);
			this.Label3.Size = new System.Drawing.Size(98, 17);
			this.Label3.Text = "Contact last name:";
			this.Label3.BackColor = System.Drawing.SystemColors.Control;
			this.Label3.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label4
			//
			this.Label4.Name = "Label4";
			this.Label4.TabIndex = 14;
			this.Label4.Location = new System.Drawing.Point(8, 16);
			this.Label4.Size = new System.Drawing.Size(90, 17);
			this.Label4.Text = "Supplier Name:";
			this.Label4.BackColor = System.Drawing.SystemColors.Control;
			this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label2
			//
			this.Label2.Name = "Label2";
			this.Label2.TabIndex = 13;
			this.Label2.Location = new System.Drawing.Point(8, 49);
			this.Label2.Size = new System.Drawing.Size(90, 17);
			this.Label2.Text = "Contact name:";
			this.Label2.BackColor = System.Drawing.SystemColors.Control;
			this.Label2.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Frame2
			//
			this.Frame2.Controls.Add(this.txtProviderContact);
			this.Frame2.Controls.Add(this.txtProviderCompany);
			this.Frame2.Controls.Add(this.Label5);
			this.Frame2.Controls.Add(this.Label1);
			this.Frame2.Name = "Frame2";
			this.Frame2.TabIndex = 10;
			this.Frame2.Location = new System.Drawing.Point(8, 267);
			this.Frame2.Size = new System.Drawing.Size(511, 50);
			this.Frame2.Text = "Supplier";
			this.Frame2.BackColor = System.Drawing.SystemColors.Control;
			this.Frame2.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// txtProviderContact
			//
			this.txtProviderContact.Name = "txtProviderContact";
			this.txtProviderContact.TabStop = false;
			this.txtProviderContact.TabIndex = 19;
			this.txtProviderContact.Location = new System.Drawing.Point(291, 16);
			this.txtProviderContact.Size = new System.Drawing.Size(211, 20);
			this.txtProviderContact.Text = "";
			this.txtProviderContact.BackColor = System.Drawing.SystemColors.Menu;
			this.txtProviderContact.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtProviderContact.ReadOnly = true;
			//
			// txtProviderCompany
			//
			this.txtProviderCompany.Name = "txtProviderCompany";
			this.txtProviderCompany.TabStop = false;
			this.txtProviderCompany.TabIndex = 18;
			this.txtProviderCompany.Location = new System.Drawing.Point(73, 16);
			this.txtProviderCompany.Size = new System.Drawing.Size(147, 20);
			this.txtProviderCompany.Text = "";
			this.txtProviderCompany.BackColor = System.Drawing.SystemColors.Menu;
			this.txtProviderCompany.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtProviderCompany.ReadOnly = true;
			//
			// Label5
			//
			this.Label5.Name = "Label5";
			this.Label5.TabIndex = 17;
			this.Label5.Location = new System.Drawing.Point(8, 16);
			this.Label5.Size = new System.Drawing.Size(58, 17);
			this.Label5.Text = "Name:";
			this.Label5.BackColor = System.Drawing.SystemColors.Control;
			this.Label5.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label1
			//
			this.Label1.Name = "Label1";
			this.Label1.TabIndex = 16;
			this.Label1.Location = new System.Drawing.Point(235, 16);
			this.Label1.Size = new System.Drawing.Size(58, 17);
			this.Label1.Text = "Contact:";
			this.Label1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label7
			//
			this.Label7.Name = "Label7";
			this.Label7.TabIndex = 32;
			this.Label7.Location = new System.Drawing.Point(8, 558);
			this.Label7.Size = new System.Drawing.Size(82, 17);
			this.Label7.Text = "Line quantity:";
			this.Label7.BackColor = System.Drawing.SystemColors.Control;
			this.Label7.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label12
			//
			this.Label12.Name = "Label12";
			this.Label12.TabIndex = 31;
			this.Label12.Location = new System.Drawing.Point(8, 607);
			this.Label12.Size = new System.Drawing.Size(90, 17);
			this.Label12.Text = "Freight Charge:";
			this.Label12.BackColor = System.Drawing.SystemColors.Control;
			this.Label12.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label11
			//
			this.Label11.Name = "Label11";
			this.Label11.TabIndex = 29;
			this.Label11.Location = new System.Drawing.Point(8, 631);
			this.Label11.Size = new System.Drawing.Size(90, 17);
			this.Label11.Text = "Total:";
			this.Label11.BackColor = System.Drawing.SystemColors.Control;
			this.Label11.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label10
			//
			this.Label10.Name = "Label10";
			this.Label10.TabIndex = 27;
			this.Label10.Location = new System.Drawing.Point(275, 582);
			this.Label10.Size = new System.Drawing.Size(90, 17);
			this.Label10.Text = "Total Tax:";
			this.Label10.BackColor = System.Drawing.SystemColors.Control;
			this.Label10.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label9
			//
			this.Label9.Name = "Label9";
			this.Label9.TabIndex = 25;
			this.Label9.Location = new System.Drawing.Point(275, 607);
			this.Label9.Size = new System.Drawing.Size(90, 17);
			this.Label9.Text = "Sub Total:";
			this.Label9.BackColor = System.Drawing.SystemColors.Control;
			this.Label9.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label8
			//
			this.Label8.Name = "Label8";
			this.Label8.TabIndex = 24;
			this.Label8.Location = new System.Drawing.Point(8, 582);
			this.Label8.Size = new System.Drawing.Size(90, 17);
			this.Label8.Text = "Sales Tax:";
			this.Label8.BackColor = System.Drawing.SystemColors.Control;
			this.Label8.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label6
			//
			this.Label6.Name = "Label6";
			this.Label6.TabIndex = 21;
			this.Label6.Location = new System.Drawing.Point(8, 332);
			this.Label6.Size = new System.Drawing.Size(33, 17);
			this.Label6.Text = "Notes:";
			this.Label6.BackColor = System.Drawing.SystemColors.Control;
			this.Label6.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// frmOrderReception
			//
			this.ClientSize = new System.Drawing.Size(527, 711);
			this.Controls.Add(this.txtNotes);
			this.Controls.Add(this.txtSubTotal);
			this.Controls.Add(this.txtTotal);
			this.Controls.Add(this.txtTotalTax);
			this.Controls.Add(this.txtFreightCharge);
			this.Controls.Add(this.txtSalesTax);
			this.Controls.Add(this.txtEntry);
			this.Controls.Add(this.fgProducts);
			this.Controls.Add(this.sbStatusBar);
			this.Controls.Add(this.cmdSave);
			this.Controls.Add(this.cmdClose);
			this.Controls.Add(this.cmdAddProducts);
			this.Controls.Add(this.Frame1);
			this.Controls.Add(this.Frame2);
			this.Controls.Add(this.Label7);
			this.Controls.Add(this.Label12);
			this.Controls.Add(this.Label11);
			this.Controls.Add(this.Label10);
			this.Controls.Add(this.Label9);
			this.Controls.Add(this.Label8);
			this.Controls.Add(this.Label6);
			this.Name = "frmOrderReception";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmOrderReception_FormClosing);
			this.Load += new System.EventHandler(this.frmOrderReception_Load);
			this.Text = "Add Stock Order";
			((System.ComponentModel.ISupportInitialize)(this.fgProducts)).EndInit();
			this.Frame1.ResumeLayout(false);
			this.Frame2.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================
		private string currentProviderName;
		// VBto upgrade warning: currentIdProvider As short --> As int	OnWrite(string)
		private int currentIdProvider;
		private string currentContactName;
		private bool editingData;

		private double currentSubTotal;
		private double currentTotal;
		private double currentTax;
		private double currentFreightCharge;
		private double currentTotalTax;

		private void cmdAddProducts_Click(object sender, System.EventArgs e)
		{
			frmAddProductTo.InstancePtr.Id = currentIdProvider;
			frmAddProductTo.InstancePtr.ObjectReferred = "Provider "+txtProviderCompany.Text+"|"+txtProviderContact.Text;
			frmAddProductTo.InstancePtr.Table = "ProductsByProvider";
			frmAddProductTo.InstancePtr.ColumnName = "ProviderId";
			frmAddProductTo.InstancePtr.LoadData();
			frmAddProductTo.InstancePtr.ShowDialog();
			if (frmAddProductTo.InstancePtr.SavedChanges) {
				LoadProductsById();
			}
		}

#if defUse_txtName_Change
		private void txtName_Change()
		{
			DoSearchProvider();
		}
#endif

		private void DoSearchProvider(int Id = 0)
		{
			string filter;
			filter = "";
			if (!VBto.IsEmpty(Id)) {
				filter = "ProviderID = "+Convert.ToString(Id);
			}
			if (txtProviderName.Text!=String.Empty) {
				if (filter!=String.Empty) {
					filter += " AND ";
				}
				filter = "ProviderName LIKE '%"+txtProviderName.Text+"%'";
			}
			if (txtContactName.Text!=String.Empty) {
				if (filter!=String.Empty) {
					filter += " AND ";
				}
				filter += "ContactFirstName LIKE '%"+txtContactName.Text+"%'";
			}
			if (txtContactLastName.Text!=String.Empty) {
				if (filter!=String.Empty) {
					filter += " AND ";
				}
				filter += "ContactLastName LIKE '%"+txtContactLastName.Text+"%'";
			}

			if (filter!=String.Empty) {
				filter = "Where "+filter;
			}
			modConnection.ExecuteSql("Select ProviderID, ProviderName, ContactFirstName, ContactLastName, City, StateOrProvince, 'Country/Region' From Providers "+filter);
			lvProviders.Items.Clear();
			if (modConnection.rs.RecordCount==0) {
				modMain.LogStatus("There are no records with the selected criteria", this);
			} else {
				ListViewItem x;
				while (!modConnection.rs.EOF) {
					x = lvProviders.Items.Add(Convert.ToString(modConnection.rs.Fields[0].Value));
					for(modMain.i=1; modMain.i<=(modConnection.rs.ColumnCount-1); modMain.i++) {
						if (!VBto.IsEmpty(modConnection.rs.Fields[modMain.i].Value)) {
							VBto.SubItemsSetText(x, modMain.i, Convert.ToString(modConnection.rs.Fields[modMain.i].Value));
						}
					} // i
					modConnection.rs.MoveNext();
				}
				if (lvProviders.Items.Count==1) {
					lvProviders.FocusedItem = lvProviders.Items[1 - 1]; lvProviders.FocusedItem.Selected = true;
				}
			}
		}

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void cmdProviders_Click(object sender, System.EventArgs e)
		{
			frmProviders.InstancePtr.ShowDialog();
			txtProviderName.Text = "";
			txtContactLastName.Text = "";
			txtContactName.Text = "";
			DoSearchProvider(frmProviders.InstancePtr.CurrentProviderID);
		}

		private void cmdSave_Click(object sender, System.EventArgs e)
		{
			int newOrderId;

			try
			{	// On Error GoTo HandleError
				modConnection.ExecuteSql("Select * from OrderReceptions");
				modConnection.rs.AddNew();
				modConnection.rs.Fields["ProviderId"].Value = currentIdProvider;
				modConnection.rs.Fields["ReceivedBy"].Value = modMain.UserId;
				modConnection.rs.Fields["OrderDate"].Value = Convert.ToString(DateTime.Today);
				modConnection.rs.Fields["Notes"].Value = txtNotes.Text;
				modConnection.rs.Fields["FreightCharge"].Value = currentFreightCharge;
				modConnection.rs.Fields["SalesTaxRate"].Value = currentTax*0.01;
				modConnection.rs.Fields["Status"].Value = "RECEIVED";
				modConnection.rs.Update();
				newOrderId = Convert.ToInt32(modConnection.rs.Fields["OrderID"].Value);


				for(modMain.i=1; modMain.i<=fgProducts.Rows-1; modMain.i++) {
					if (fgProducts.get_TextMatrix(modMain.i, 0)!="0") {
						modConnection.ExecuteSql("Insert into OrderReceptionDetails (OrderID, ProductID, DateSold, Quantity, UnitPrice, SalePrice, SalesTax, LineTotal) Values ("+Convert.ToString(newOrderId)+", '"+fgProducts.get_TextMatrix(modMain.i, 1)+"', '"+VBto.vbFormat(DateTime.Today, "mm/dd/yyyy")+"',"+fgProducts.get_TextMatrix(modMain.i, 0)+","+fgProducts.get_TextMatrix(modMain.i, 3)+","+fgProducts.get_TextMatrix(modMain.i, 4)+","+Convert.ToString(currentTax*0.01)+","+fgProducts.get_TextMatrix(modMain.i, 4)+")");

						// UnitsInTransit
						// ExecuteSql "Update Products Set UnitsOnOrder = UnitsOnOrder + " & fgProducts.TextMatrix(i, 0) &
						// " Where ProductId = '" & fgProducts.TextMatrix(i, 1) & "'"

					}
				} // i



				editingData = false;
				if (MessageBox.Show("Order reception added successfully"+"\r\n"+"Would you like to add a new order reception?", "New data", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes) {
					ClearFields();
				} else {
					Close();
				}
				return;
			}
			catch
			{	// HandleError:
				// ...
			}
			MessageBox.Show("An error has occurred adding the data. Error: ("+Convert.ToString(Information.Err().Number)+") "+Information.Err().Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		public void cmdSave_Click()
		{
			cmdSave_Click(cmdSave, new System.EventArgs());
		}

		private void MakeTextBoxVisible(TextBox txtBox, AxMSFlexGridLib.AxMSFlexGrid grid)
		{

			txtBox.Text = grid.get_TextMatrix(grid.Row, grid.Col);
			// txtBox.Move .CellLeft + .Left, .CellTop + .Top, .CellWidth, .CellHeight
			txtBox.Visible = true;
			txtBox.Enabled = true;
			// DoEvents
			txtBox.Focus();
			modFunctions.SelectAll(txtBox);

		}

		private void fgProducts_ClickEvent(object sender, System.EventArgs e)
		{
			if (fgProducts.Col!=0) return;
			MakeTextBoxVisible(txtEntry, fgProducts);
		}

		private void fgProducts_EnterCell(object sender, System.EventArgs e)
		{
			SaveEdits();
		}

		private void fgProducts_KeyPressEvent(object sender, AxMSFlexGridLib.DMSFlexGridEvents_KeyPressEvent e)
		{
			if (fgProducts.Col!=0) return;
			
			if ((e.keyAscii==46) || (e.keyAscii>=48 && e.keyAscii<=57))
			{
				// Case 45, 46, 47, 48 To 59, 65 To 90, 97 To 122
				MakeTextBoxVisible(txtEntry, fgProducts);
				txtEntry.Text = Convert.ToString(Convert.ToChar(e.keyAscii));
				txtEntry.SelectionStart = 1;
			}
		}

		private void txtEntry_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			Keys KeyCode = e.KeyCode;
			ShiftConstants Shift = (ShiftConstants)((int)e.KeyData / 0x10000);

			EditKeyCode(fgProducts, ref txtEntry, KeyCode, Shift);
		}

		// VBto upgrade warning: txtBox As TextBox	OnWrite(VB.TextBox, string)
		// VBto upgrade warning: KeyCode As short, int --> As Keys
		// VBto upgrade warning: Shift As short, int --> As ShiftConstants
		private void EditKeyCode(AxMSFlexGridLib.AxMSFlexGrid grid, ref TextBox txtBox, Keys KeyCode, ShiftConstants Shift)
		{
			switch (KeyCode) {
				
				case Keys.Escape:
				{
					// ESC
					txtBox.Text = "";
					txtBox.Visible = false;
					grid.Focus();
					break;
				}
				case Keys.Return:
				{
					// Return
					grid.Focus();
					break;
				}
				case Keys.Left:
				{
					// Left Arrow
					grid.Focus();
					Application.DoEvents();
					if (grid.Col>grid.FixedCols) {
						grid.Col -= 1;
					}
					break;
				}
				case Keys.Up:
				{
					// Up Arrow
					grid.Focus();
					Application.DoEvents();
					if (grid.Row>grid.FixedRows) {
						grid.Row -= 1;
					}
					break;
				}
				case Keys.Right:
				{
					// Right Arrow
					grid.Focus();
					Application.DoEvents();
					if (grid.Col<(grid.Cols-1)) {
						grid.Col += 1;
					}
					break;
				}
				case Keys.Down:
				{
					// Down Arrow
					grid.Focus();
					Application.DoEvents();
					if (grid.Row<(grid.Rows-1)) {
						grid.Row += 1;
					}
					break;
				}
			} //end switch
		}

		private void txtEntry_Leave(object sender, System.EventArgs e)
		{
			SaveEdits();
		}


		private void fgProducts_LeaveCell(object sender, System.EventArgs e)
		{
			SaveEdits();
		}

		private void txtEntry_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Keys KeyAscii = (Keys)Strings.Asc(e.KeyChar);

			
				// dot and Numbers
			if ((KeyAscii==Keys.Delete) || (KeyAscii>=Keys.D0 && KeyAscii<=Keys.D0))
			{
				// Alphanumeric
				// Case 45, 46, 47, 48 To 59, 65 To 90, 97 To 122
			}
			else 
			{
				KeyAscii = 0;
			}

			e.KeyChar = Strings.Chr((int)KeyAscii); if (KeyAscii == 0) e.Handled = true;
		}

		private void SaveEdits()
		{
			double lineQuantity, lineUnitPrice, linePrice;
			double previousLinePrice;
			if (!txtEntry.Visible || !modFunctions.ValidateTextBoxDouble(txtEntry, this) || !modFunctions.ValidateTextDouble(fgProducts.get_TextMatrix(fgProducts.Row, 3), this) || !modFunctions.ValidateTextDouble(fgProducts.get_TextMatrix(fgProducts.Row, 4), this)) return;
			previousLinePrice = modFunctions.DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 4));
			fgProducts.set_TextMatrix(fgProducts.Row, fgProducts.Col, txtEntry.Text);
			lineQuantity = modFunctions.DoubleValue(txtEntry.Text);
			lineUnitPrice = modFunctions.DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 3));
			previousLinePrice = modFunctions.DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 4));
			linePrice = Convert.ToDouble(lineQuantity*lineUnitPrice);
			fgProducts.set_TextMatrix(fgProducts.Row, 4, Convert.ToString(linePrice));
			ReCalculateTotals(previousLinePrice, linePrice);
			txtEntry.Visible = false;
			editingData = true;
		}

		private void ReCalculateTotals(double previous, double current)
		{
			currentSubTotal += -previous+current;
			currentTotalTax = currentSubTotal*currentTax*0.01;
			currentTotal = currentFreightCharge+currentSubTotal+currentTotalTax;
			txtSubTotal.Text = VBto.vbFormat(currentSubTotal, "#,##0.00");
			txtTotalTax.Text = VBto.vbFormat(currentTotalTax, "#,##0.00");
			txtTotal.Text = VBto.vbFormat(currentTotal, "#,##0.00");
		}

		// VBto upgrade warning: Cancel As short	OnWrite(bool)
		private void Form_QueryUnload(ref short Cancel, int UnloadMode)
		{
			if (editingData) {
				DialogResult res;
				res = MessageBox.Show("Do you want to save the edited data?", "Save data", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
				if (res==DialogResult.Yes) {
					cmdSave_Click();
				} else if (res!=DialogResult.No) {
					Cancel = Convert.ToInt16(true);
				}
			}
		}

		private void frmOrderReception_FormClosing(object sender, FormClosingEventArgs e)
		{
			short Cancel = 0;
			Form_QueryUnload(ref Cancel, 0);
			if (Cancel != 0)
			{
				e.Cancel = true;
				return;
			}
		}

		private void frmOrderReception_Load(object sender, System.EventArgs e)
		{
			editingData = false;
			ClearFields();
		}

		private void lvProviders_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ListViewItem Item = ((ListView)sender).FocusedItem;
			if (Item==null) return;

			RetrieveDataProvider();
		}

		private void RetrieveDataProvider()
		{
			if (editingData) {
				if (MessageBox.Show("Do you want to cancel previous edited data?", "Data edition", MessageBoxButtons.YesNo, MessageBoxIcon.Question)!=DialogResult.Yes) {
					return;
				}
			}

			if (lvProviders.FocusedItem.Text!=String.Empty) {

				currentIdProvider = VBto.Int(lvProviders.FocusedItem.Text);
				currentProviderName = lvProviders.FocusedItem.SubItems[1].Text;
				currentContactName = lvProviders.FocusedItem.SubItems[2].Text+" "+lvProviders.FocusedItem.SubItems[3].Text;

				txtProviderCompany.Text = currentProviderName;
				txtProviderContact.Text = currentContactName;
				editingData = false;
			}
			LoadProductsById();
			cmdSave.Enabled = true;
			cmdAddProducts.Enabled = true;

		}

		private void LoadProductsById()
		{
			string Table;
			string ColumnName;
			int Id;
			Table = "ProductsByProvider";
			ColumnName = "ProviderId";
			Id = currentIdProvider;

			modConnection.ExecuteSql("Select p.ProductID, p.ProductName, p.UnitPrice, p.UnitsInStock, p.UnitsOnOrder, p.QuantityPerUnit, p.Unit from Products as p, "+Table+" as pb Where pb."+ColumnName+" = "+Convert.ToString(Id)+" And pb.ProductId = p.ProductId");

			// lvProducts.ListItems.Clear
			// If rs.RecordCount > 0 Then
			// With rs
			// While Not .EOF
			// Set x = lvProducts.ListItems.Add(, , 0)
			// For i = 1 To 5
			// If Not IsEmpty(.Fields(i - 1)) Then
			// x.SubItems(i) = .Fields(i - 1)
			// End If
			// Next i
			// x.SubItems(6) = .Fields(5) & .Fields(6)
			// .MoveNext
			// Wend
			// End With
			// End If

			int lng/*unused?*/;
			int j;
			int intLoopCount/*unused?*/;
			const short SCROOL_WIDTH = 320;

			fgProducts.Cols = 8;
			fgProducts.FixedCols = 0;
			fgProducts.Rows = 0;
			fgProducts.AddItem("Quantity"+"\t"+"Code"+"\t"+"Product"+"\t"+"UnitPrice"+"\t"+"Price"+"\t"+"Existence"+"\t"+"Ordered"+"\t"+"Quantity per unit");
			fgProducts.Rows = modConnection.rs.RecordCount+1;
			if (fgProducts.Rows==1) fgProducts.FixedRows = 0; else  fgProducts.FixedRows = 1;
			int i;
			i = 1;
			while (!modConnection.rs.EOF) {
				fgProducts.set_TextMatrix(i, 0, "0");
				for(j=1; j<=6; j++) {
					if (j==4) {
						fgProducts.set_TextMatrix(i, j, "0");
					} else if (j<4) {
						fgProducts.set_TextMatrix(i, j, Convert.ToString(modConnection.rs.Fields[j-1].Value));
					} else {
						fgProducts.set_TextMatrix(i, j, Convert.ToString(modConnection.rs.Fields[j-2].Value));
					}
				} // j
				fgProducts.set_TextMatrix(i, 7, Convert.ToString(modConnection.rs.Fields[5].Value)+Convert.ToString(modConnection.rs.Fields[6].Value));
				modConnection.rs.MoveNext();
				i += 1;
			}


		}


#if defUse_lvProducts_ItemCheck
		private void lvProducts_ItemCheck(ListViewItem Item)
		{
			if (Item.Checked) {
				Item.Text = "1";
			} else {
				Item.Text = "0";
			}
		}
#endif


		private void txtProviderName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchProvider();
		}

		private void txtNotes_TextChanged(object sender, System.EventArgs e)
		{
			editingData = true;
		}

		private void txtContactName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchProvider();
		}

		private void ClearFields()
		{

			fgProducts.Rows = 0;
			fgProducts.Cols = 0;

			currentSubTotal = 0;
			currentTotal = 0;
			currentTax = 0;
			currentTotalTax = 0;
			currentFreightCharge = 0;

			txtSubTotal.Text = "";
			txtTotal.Text = "";
			txtTotalTax.Text = "";
			txtSalesTax.Text = "";
			txtFreightCharge.Text = "";

			txtProviderName.Text = "";
			txtContactLastName.Text = "";
			txtContactName.Text = "";
			txtProviderContact.Text = "";
			txtProviderCompany.Text = "";
			cmdSave.Enabled = false;
			cmdAddProducts.Enabled = false;
			txtNotes.Text = "";
			// txtProviderName.SetFocus
			ReCalculateTotals(0, 0);
			editingData = false;
		}

		private void txtFreightCharge_TextChanged(object sender, System.EventArgs e)
		{
			currentFreightCharge = modFunctions.DoubleValue(txtFreightCharge.Text);
			ReCalculateTotals(0, 0);
			editingData = true;
		}

		private void txtFreightCharge_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Keys KeyAscii = (Keys)Strings.Asc(e.KeyChar);

			
			if (KeyAscii>=Keys.D0 && KeyAscii<=Keys.D9)
			{
			}
			else if ((KeyAscii==Keys.Back) || (KeyAscii==Keys.Clear) || (KeyAscii==Keys.Delete))
			{
			}
			else if ((KeyAscii==Keys.Left) || (KeyAscii==Keys.Right) || (KeyAscii==Keys.Up) || (KeyAscii==Keys.Down) || (KeyAscii==Keys.Tab))
			{
			}
			else 
			{
				KeyAscii = 0;
				Interaction.Beep();
			}

			e.KeyChar = Strings.Chr((int)KeyAscii); if (KeyAscii == 0) e.Handled = true;
		}

		private void txtContactLastName_TextChanged(object sender, System.EventArgs e)
		{
			editingData = true;
		}


		private void txtSalesTax_TextChanged(object sender, System.EventArgs e)
		{
			currentTax = modFunctions.DoubleValue(txtSalesTax.Text);
			ReCalculateTotals(0, 0);
			editingData = true;
		}

		private void txtSalesTax_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Keys KeyAscii = (Keys)Strings.Asc(e.KeyChar);

			
			if (KeyAscii>=Keys.D0 && KeyAscii<=Keys.D9)
			{
			}
			else if ((KeyAscii==Keys.Back) || (KeyAscii==Keys.Clear) || (KeyAscii==Keys.Delete))
			{
			}
			else if ((KeyAscii==Keys.Left) || (KeyAscii==Keys.Right) || (KeyAscii==Keys.Up) || (KeyAscii==Keys.Down) || (KeyAscii==Keys.Tab))
			{
			}
			else 
			{
				KeyAscii = 0;
				Interaction.Beep();
			}

			e.KeyChar = Strings.Chr((int)KeyAscii); if (KeyAscii == 0) e.Handled = true;
		}

	}
}