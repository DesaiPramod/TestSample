using System;
using System.Windows.Forms;
using Microsoft.VisualBasic.Compatibility.VB6;
using ADODB;

namespace SKS
{
	/// <summary>
	/// Summary description for frmProducts.
	/// </summary>
	public class frmProducts : System.Windows.Forms.Form
	{
		public Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray txtField;
		public System.Windows.Forms.GroupBox Frame1;
		public System.Windows.Forms.TextBox txtField_6;
		public System.Windows.Forms.TextBox txtField_0;
		public System.Windows.Forms.TextBox txtField_5;
		public System.Windows.Forms.TextBox txtCategory;
		public System.Windows.Forms.ComboBox cmbCategory;
		public System.Windows.Forms.TextBox txtField_4;
		public System.Windows.Forms.TextBox txtField_3;
		public System.Windows.Forms.TextBox txtField_2;
		public System.Windows.Forms.TextBox txtField_1;
		public System.Windows.Forms.CheckBox Check1;
		public System.Windows.Forms.Label Label7;
		public System.Windows.Forms.Label Label3;
		public System.Windows.Forms.Label Label2;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.Label Label4;
		public System.Windows.Forms.Label Label5;
		public System.Windows.Forms.Label Label6;
		public System.Windows.Forms.Label Label11;
		public System.Windows.Forms.Label Label15;
		public Microsoft.VisualBasic.Compatibility.VB6.ADODC dcProducts;
		public System.Windows.Forms.ImageList ImageList1;
		public System.Windows.Forms.ToolBar Toolbar1;
		private System.Windows.Forms.ToolBarButton Button1;
		private System.Windows.Forms.ToolBarButton Button2;
		private System.Windows.Forms.ToolBarButton Button3;
		private System.Windows.Forms.ToolBarButton Button4;
		private System.Windows.Forms.ToolBarButton Button5;
		private System.Windows.Forms.ToolBarButton Button6;
		private System.Windows.Forms.ToolTip ToolTip1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmProducts()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmProducts InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmProducts();
				return _InstancePtr;
			}
		}
		protected static frmProducts _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmProducts));
			this.components = new System.ComponentModel.Container();
			this.txtField = new Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray();
			this.Frame1 = new System.Windows.Forms.GroupBox();
			this.txtField_6 = new System.Windows.Forms.TextBox();
			this.txtField_0 = new System.Windows.Forms.TextBox();
			this.txtField_5 = new System.Windows.Forms.TextBox();
			this.txtCategory = new System.Windows.Forms.TextBox();
			this.cmbCategory = new System.Windows.Forms.ComboBox();
			this.txtField_4 = new System.Windows.Forms.TextBox();
			this.txtField_3 = new System.Windows.Forms.TextBox();
			this.txtField_2 = new System.Windows.Forms.TextBox();
			this.txtField_1 = new System.Windows.Forms.TextBox();
			this.Check1 = new System.Windows.Forms.CheckBox();
			this.Label7 = new System.Windows.Forms.Label();
			this.Label3 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.Label4 = new System.Windows.Forms.Label();
			this.Label5 = new System.Windows.Forms.Label();
			this.Label6 = new System.Windows.Forms.Label();
			this.Label11 = new System.Windows.Forms.Label();
			this.Label15 = new System.Windows.Forms.Label();
			this.dcProducts = new Microsoft.VisualBasic.Compatibility.VB6.ADODC();
			this.ImageList1 = new System.Windows.Forms.ImageList();
			this.Toolbar1 = new System.Windows.Forms.ToolBar();
			this.Button1 = new System.Windows.Forms.ToolBarButton();
			this.Button2 = new System.Windows.Forms.ToolBarButton();
			this.Button3 = new System.Windows.Forms.ToolBarButton();
			this.Button4 = new System.Windows.Forms.ToolBarButton();
			this.Button5 = new System.Windows.Forms.ToolBarButton();
			this.Button6 = new System.Windows.Forms.ToolBarButton();
			this.ToolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtField)).BeginInit();
			//
			// Frame1
			//
			this.Frame1.Controls.Add(this.txtField_6);
			this.Frame1.Controls.Add(this.txtField_0);
			this.Frame1.Controls.Add(this.txtField_5);
			this.Frame1.Controls.Add(this.txtCategory);
			this.Frame1.Controls.Add(this.cmbCategory);
			this.Frame1.Controls.Add(this.txtField_4);
			this.Frame1.Controls.Add(this.txtField_3);
			this.Frame1.Controls.Add(this.txtField_2);
			this.Frame1.Controls.Add(this.txtField_1);
			this.Frame1.Controls.Add(this.Check1);
			this.Frame1.Controls.Add(this.Label7);
			this.Frame1.Controls.Add(this.Label3);
			this.Frame1.Controls.Add(this.Label2);
			this.Frame1.Controls.Add(this.Label1);
			this.Frame1.Controls.Add(this.Label4);
			this.Frame1.Controls.Add(this.Label5);
			this.Frame1.Controls.Add(this.Label6);
			this.Frame1.Controls.Add(this.Label11);
			this.Frame1.Controls.Add(this.Label15);
			this.Frame1.Name = "Frame1";
			this.Frame1.TabIndex = 9;
			this.Frame1.Location = new System.Drawing.Point(8, 49);
			this.Frame1.Size = new System.Drawing.Size(438, 284);
			this.Frame1.Text = "Product information";
			this.Frame1.BackColor = System.Drawing.SystemColors.Control;
			this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// txtField_6
			//
			this.txtField_6.Name = "txtField_6";
			this.txtField_6.TabIndex = 20;
			this.txtField_6.Location = new System.Drawing.Point(259, 243);
			this.txtField_6.Size = new System.Drawing.Size(106, 20);
			this.txtField_6.Text = "";
			this.txtField_6.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_6.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_0
			//
			this.txtField_0.Name = "txtField_0";
			this.txtField_0.TabIndex = 0;
			this.txtField_0.Location = new System.Drawing.Point(105, 24);
			this.txtField_0.Size = new System.Drawing.Size(114, 20);
			this.txtField_0.Text = "";
			this.txtField_0.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_0.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtField_0.MaxLength = 20;
			//
			// txtField_5
			//
			this.txtField_5.Name = "txtField_5";
			this.txtField_5.TabIndex = 7;
			this.txtField_5.Location = new System.Drawing.Point(105, 243);
			this.txtField_5.Size = new System.Drawing.Size(106, 20);
			this.txtField_5.Text = "";
			this.txtField_5.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_5.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtCategory
			//
			this.txtCategory.Name = "txtCategory";
			this.txtCategory.TabStop = false;
			this.txtCategory.TabIndex = 16;
			this.txtCategory.Location = new System.Drawing.Point(267, 121);
			this.txtCategory.Size = new System.Drawing.Size(114, 19);
			this.txtCategory.Text = "";
			this.txtCategory.BackColor = System.Drawing.SystemColors.Window;
			this.txtCategory.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtCategory.TextChanged += new System.EventHandler(this.txtCategory_TextChanged);
			//
			// cmbCategory
			//
			this.cmbCategory.Name = "cmbCategory";
			this.cmbCategory.TabIndex = 3;
			this.cmbCategory.Location = new System.Drawing.Point(105, 118);
			this.cmbCategory.Size = new System.Drawing.Size(122, 21);
			this.cmbCategory.Text = "";
			this.cmbCategory.BackColor = System.Drawing.SystemColors.Window;
			this.cmbCategory.ForeColor = System.Drawing.SystemColors.WindowText;
			this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbCategory.SelectedIndexChanged += new System.EventHandler(this.cmbCategory_SelectedIndexChanged);
			//
			// txtField_4
			//
			this.txtField_4.Name = "txtField_4";
			this.txtField_4.TabIndex = 6;
			this.txtField_4.Location = new System.Drawing.Point(105, 212);
			this.txtField_4.Size = new System.Drawing.Size(106, 20);
			this.txtField_4.Text = "";
			this.txtField_4.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_4.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_3
			//
			this.txtField_3.Name = "txtField_3";
			this.txtField_3.TabIndex = 4;
			this.txtField_3.Location = new System.Drawing.Point(105, 150);
			this.txtField_3.Size = new System.Drawing.Size(122, 20);
			this.txtField_3.Text = "";
			this.txtField_3.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_3.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_2
			//
			this.txtField_2.Name = "txtField_2";
			this.txtField_2.TabIndex = 2;
			this.txtField_2.Location = new System.Drawing.Point(105, 89);
			this.txtField_2.Size = new System.Drawing.Size(308, 20);
			this.txtField_2.Text = "";
			this.txtField_2.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_2.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtField_2.MaxLength = 255;
			//
			// txtField_1
			//
			this.txtField_1.Name = "txtField_1";
			this.txtField_1.TabIndex = 1;
			this.txtField_1.Location = new System.Drawing.Point(105, 57);
			this.txtField_1.Size = new System.Drawing.Size(195, 20);
			this.txtField_1.Text = "";
			this.txtField_1.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_1.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtField_1.MaxLength = 50;
			//
			// Check1
			//
			this.Check1.Name = "Check1";
			this.Check1.TabIndex = 5;
			this.Check1.Location = new System.Drawing.Point(105, 183);
			this.Check1.Size = new System.Drawing.Size(25, 17);
			this.Check1.Text = "";
			this.Check1.BackColor = System.Drawing.SystemColors.Control;
			this.Check1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label7
			//
			this.Label7.Name = "Label7";
			this.Label7.TabIndex = 19;
			this.Label7.Location = new System.Drawing.Point(218, 243);
			this.Label7.Size = new System.Drawing.Size(58, 17);
			this.Label7.Text = "Unit:";
			this.Label7.BackColor = System.Drawing.SystemColors.Control;
			this.Label7.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label3
			//
			this.Label3.Name = "Label3";
			this.Label3.TabIndex = 18;
			this.Label3.Location = new System.Drawing.Point(16, 24);
			this.Label3.Size = new System.Drawing.Size(90, 17);
			this.Label3.Text = "Product Code:";
			this.Label3.BackColor = System.Drawing.SystemColors.Control;
			this.Label3.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label2
			//
			this.Label2.Name = "Label2";
			this.Label2.TabIndex = 17;
			this.Label2.Location = new System.Drawing.Point(16, 243);
			this.Label2.Size = new System.Drawing.Size(82, 17);
			this.Label2.Text = "Quantity per unit:";
			this.Label2.BackColor = System.Drawing.SystemColors.Control;
			this.Label2.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label1
			//
			this.Label1.Name = "Label1";
			this.Label1.TabIndex = 15;
			this.Label1.Location = new System.Drawing.Point(16, 57);
			this.Label1.Size = new System.Drawing.Size(90, 17);
			this.Label1.Text = "Product Name:";
			this.Label1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label4
			//
			this.Label4.Name = "Label4";
			this.Label4.TabIndex = 14;
			this.Label4.Location = new System.Drawing.Point(16, 88);
			this.Label4.Size = new System.Drawing.Size(90, 17);
			this.Label4.Text = "Description:";
			this.Label4.BackColor = System.Drawing.SystemColors.Control;
			this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label5
			//
			this.Label5.Name = "Label5";
			this.Label5.TabIndex = 13;
			this.Label5.Location = new System.Drawing.Point(16, 150);
			this.Label5.Size = new System.Drawing.Size(90, 17);
			this.Label5.Text = "Serial number:";
			this.Label5.BackColor = System.Drawing.SystemColors.Control;
			this.Label5.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label6
			//
			this.Label6.Name = "Label6";
			this.Label6.TabIndex = 12;
			this.Label6.Location = new System.Drawing.Point(16, 212);
			this.Label6.Size = new System.Drawing.Size(82, 17);
			this.Label6.Text = "Unit price:";
			this.Label6.BackColor = System.Drawing.SystemColors.Control;
			this.Label6.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label11
			//
			this.Label11.Name = "Label11";
			this.Label11.TabIndex = 11;
			this.Label11.Location = new System.Drawing.Point(16, 119);
			this.Label11.Size = new System.Drawing.Size(90, 17);
			this.Label11.Text = "Category:";
			this.Label11.BackColor = System.Drawing.SystemColors.Control;
			this.Label11.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label15
			//
			this.Label15.Name = "Label15";
			this.Label15.TabIndex = 10;
			this.Label15.Location = new System.Drawing.Point(16, 181);
			this.Label15.Size = new System.Drawing.Size(90, 17);
			this.Label15.Text = "Discontinued:";
			this.Label15.BackColor = System.Drawing.SystemColors.Control;
			this.Label15.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// dcProducts
			//
			this.dcProducts.Name = "dcProducts";
			this.dcProducts.Enabled = true;
			this.dcProducts.Location = new System.Drawing.Point(8, 340);
			this.dcProducts.Size = new System.Drawing.Size(179, 22);
			this.dcProducts.Text = "Products";
			this.dcProducts.BackColor = System.Drawing.SystemColors.Window;
			this.dcProducts.ForeColor = System.Drawing.SystemColors.WindowText;
			this.dcProducts.Orientation = ADODC.OrientationEnum.adHorizontal;
			this.dcProducts.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
			this.dcProducts.ConnectionTimeout = 15;
			this.dcProducts.CommandTimeout = 30;
			this.dcProducts.CursorType = ADODB.CursorTypeEnum.adOpenDynamic;
			this.dcProducts.LockType = ADODB.LockTypeEnum.adLockPessimistic;//VBto.Stub_ADODB_LockTypeEnum_adLockPessimistic;
			this.dcProducts.CommandType = ADODB.CommandTypeEnum.adCmdTable;
			this.dcProducts.CacheSize = 50;
			this.dcProducts.MaxRecords = 0;
			this.dcProducts.BOFAction = ADODC.BOFActionEnum.adDoMoveFirst;
			this.dcProducts.EOFAction = ADODC.EOFActionEnum.adDoMoveLast;
			this.dcProducts.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Orders.mdb;Persist Security Info=False";
			this.dcProducts.UserName = "";
			this.dcProducts.RecordSource = "Products";
			this.dcProducts.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Regular), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// ImageList1
			//
			this.ImageList1.ImageSize = new System.Drawing.Size(16, 16);
			this.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.ImageList1.TransparentColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(255)));
			this.ImageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageList1.ImageStream")));
			//
			// Toolbar1
			//
			this.Toolbar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {this.Button1, this.Button2, this.Button3, this.Button4, this.Button5, this.Button6});
			this.Toolbar1.Name = "Toolbar1";
			this.Toolbar1.TabIndex = 8;
			this.Toolbar1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.Toolbar1.ButtonSize = new System.Drawing.Size(16, 16);
			this.Toolbar1.ImageList = this.ImageList1;
			this.Toolbar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.Toolbar1_ButtonClick);
			//
			// Button1
			//
			this.Button1.Name = "Button1";
			this.Button1.ImageIndex = 0;
			this.Button1.Text = "Add";
			this.Button1.ToolTipText = "Create a new record";
			this.Button1.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button2
			//
			this.Button2.Name = "Button2";
			this.Button2.ImageIndex = 1;
			this.Button2.Text = "Edit";
			this.Button2.ToolTipText = "Edit this record";
			this.Button2.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button3
			//
			this.Button3.Name = "Button3";
			this.Button3.ImageIndex = 2;
			this.Button3.Text = "Save";
			this.Button3.ToolTipText = "Save the current changes";
			this.Button3.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button4
			//
			this.Button4.Name = "Button4";
			this.Button4.ImageIndex = 3;
			this.Button4.Text = "Delete";
			this.Button4.ToolTipText = "Delete the current record";
			this.Button4.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button5
			//
			this.Button5.Name = "Button5";
			this.Button5.ImageIndex = 4;
			this.Button5.Text = "Search";
			this.Button5.ToolTipText = "Search for a record";
			this.Button5.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button6
			//
			this.Button6.Name = "Button6";
			this.Button6.Text = "Cancel";
			this.Button6.ToolTipText = "Cancel edited changes";
			this.Button6.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// frmProducts
			//
			this.ClientSize = new System.Drawing.Size(453, 383);
			this.Controls.Add(this.Frame1);
			this.Controls.Add(this.dcProducts);
			this.Controls.Add(this.Toolbar1);
			this.Name = "frmProducts";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.ShowInTaskbar = false;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProducts_FormClosing);
			this.Load += new System.EventHandler(this.frmProducts_Load);
			this.Text = "Products";
			this.txtField.SetIndex( txtField_6, System.Convert.ToInt16( 6 ) );
			this.txtField.SetIndex( txtField_0, System.Convert.ToInt16( 0 ) );
			this.txtField.SetIndex( txtField_5, System.Convert.ToInt16( 5 ) );
			this.txtField.SetIndex( txtField_4, System.Convert.ToInt16( 4 ) );
			this.txtField.SetIndex( txtField_3, System.Convert.ToInt16( 3 ) );
			this.txtField.SetIndex( txtField_2, System.Convert.ToInt16( 2 ) );
			this.txtField.SetIndex( txtField_1, System.Convert.ToInt16( 1 ) );
			((System.ComponentModel.ISupportInitialize)(this.txtField)).EndInit();
			this.Frame1.ResumeLayout(false);
			this.Toolbar1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================
		private bool NewMode;
		private bool EditMode;
		private bool CancellingMode;
		public string CurrentProductID = "";

		// SKS Demo TODO: Go the the designer and change the data binding of _txtField_4 like this:
		// _txtField_4.DataBindings.Add("Text", dcProducts, "UnitPrice", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged, null, "C2");


		private void cmbCategory_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (cmbCategory.Items.Count==0 || cmbCategory.SelectedIndex==-1) {
				return;
			}
			txtCategory.Text = Convert.ToString(Support.GetItemData(cmbCategory, cmbCategory.SelectedIndex));
		}

		private void Form_Unload(ref short Cancel)
		{
			CurrentProductID = Convert.ToString(dcProducts.Recordset.Fields["ProductId"].Value);
		}

		private void frmProducts_FormClosing(object sender, FormClosingEventArgs e)
		{
			short Cancel = 0;
			Form_Unload(ref Cancel);
			if (Cancel != 0) e.Cancel = true;
		}

		private void txtCategory_TextChanged(object sender, System.EventArgs e)
		{
			if (cmbCategory.Items.Count==0) {
				modFunctions.LoadCombo("Categories", cmbCategory, "CategoryName", "CategoryID");
			}
			if (txtCategory.Text==String.Empty) {
				cmbCategory.SelectedIndex = -1;
				return;
			}
			int Index;
			Index = -1;
			for(modMain.i=0; modMain.i<=cmbCategory.Items.Count; modMain.i++) {
				if (Support.GetItemData(cmbCategory, modMain.i) == Convert.ToDouble(txtCategory.Text)) {
					Index = modMain.i;
					break;
				}
			}
			cmbCategory.SelectedIndex = modMain.i;
		}

		private void frmProducts_Load(object sender, System.EventArgs e)
		{
			txtCategory.Visible = false;
			dcProducts.ConnectionString = modMain.ConnectionString;
			NewMode = false;
			EditMode = false;
			CancellingMode = false;
			if (cmbCategory.Items.Count==0) {
				modFunctions.LoadCombo("Categories", cmbCategory, "CategoryName", "CategoryID");
			}
		}

		private void Toolbar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			ToolBarButton Button = e.Button;

			object x/*unused?*/;
			// SKS Demo TODO: dcProducts.SetFocus()
			switch (Button.Text) {
				
				case "Add":
				{
					// Add new record
					NewMode = true;
					dcProducts.Recordset.AddNew();
					dcProducts.Recordset.Fields["UnitsInStock"].Value = 0;
					dcProducts.Recordset.Fields["UnitsOnOrder"].Value = 0;
					break;
				}
				case "Edit":
				{
					// Edit mode
					EditMode = true;
					// dcProducts.Recordset.EditMode =
					break;
				}
				case "Save":
				{
					// Save data
					dcProducts.Recordset.Update();
					EditMode = false;
					NewMode = false;
					break;
				}
				case "Delete":
				{
					// Delete record
					if (MessageBox.Show("Are you sure you want to delete this record?", "Delete record", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes) {
						dcProducts.Recordset.Delete();
						dcProducts.Recordset.Requery();
					}
					break;
				}
				case "Search":
				{
					// Search for records
					modFunctions.SearchShow("Products", "ProductName", "product");
					break;
				}
				case "Cancel":
				{
					CancellingMode = true;
					// Cancel edited changes
					EditMode = false;
					NewMode = false;
					dcProducts.Recordset.CancelUpdate();
					dcProducts.Recordset.Requery();
					CancellingMode = false;
					Close();
					break;
				}
			} //end switch
		}

		// Private Sub txtField_KeyPress(Index As Integer, KeyAscii As Integer)
		// If Index = 0 Then
		// KeyAscii = Asc(UCase(Chr(KeyAscii)))
		// ElseIf Index = 4 Or Index = 5 Then
		// Select Case KeyAscii
		// Case vbKey0 To vbKey9
		// Case vbKeyBack, vbKeyClear, vbKeyDelete
		// Case vbKeyLeft, vbKeyRight, vbKeyUp, vbKeyDown, vbKeyTab
		// Case Else
		// KeyAscii = 0
		// Beep
		// End Select
		// End If
		// End Sub

	}
}