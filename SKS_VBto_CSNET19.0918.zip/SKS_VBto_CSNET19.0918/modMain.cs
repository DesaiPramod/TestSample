using System;
using System.Windows.Forms;

namespace SKS
{
	public class modMain
	{

		//=========================================================

		public static bool CurrentUserAdmin;
		public static string UserFullname;
		public static string UserLevel;
		public static string UserId = "";

		public static string ConnectionString = "";

		public static int DetectionType;
		public static double n; public static int i; public static string s; public static DateTime d;
		public static string msg;
		public static string ImgName, ImgSrc;




		[STAThread]
		public static void Main()
		{
			ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Orders.mdb;Persist Security Info=False";

			modConnection.OpenConnection();
			CurrentUserAdmin = true;
			UserFullname = "Allan Cantillo";
			UserLevel = "Administrator";
			UserId = "acantillo";
			frmMain.InstancePtr.ShowDialog();
			
		}

		// VBto upgrade warning: frm As Form	OnWrite(Form, frmAdjustStockManual, frmOrderRequest, frmAddStockManual, frmOrderReception, frmAddProductTo, frmReceptionApproval, frmActionOrderReception, frmActionOrderRequest, frmRequestApproval)
		public static void LogStatus(string message, Form frm = null)
		{
			StatusBar sb;
			sb = null;
			frmMain.InstancePtr.sbStatusBar.Panels[1 - 1].Text = message;
			if (!(frm==null)) {
				if (frm == frmAdjustStockManual.InstancePtr) {
					sb = frmAdjustStockManual.InstancePtr.sbStatusBar;
				} else if (frm == frmActionOrderReception.InstancePtr) {
					sb = frmActionOrderReception.InstancePtr.sbStatusBar;
				} else if (frm == frmActionOrderRequest.InstancePtr) {
					sb = frmActionOrderRequest.InstancePtr.sbStatusBar;
				} else if (frm == frmAddStockManual.InstancePtr) {
					sb = frmAddStockManual.InstancePtr.sbStatusBar;
				} else if (frm == frmReceptionApproval.InstancePtr) {
					sb = frmReceptionApproval.InstancePtr.sbStatusBar;
				} else if (frm == frmOrderReception.InstancePtr) {
					sb = frmOrderReception.InstancePtr.sbStatusBar;
				} else if (frm == frmOrderRequest.InstancePtr) {
					sb = frmOrderRequest.InstancePtr.sbStatusBar;
				} else if (frm == frmRequestApproval.InstancePtr) {
					sb = frmRequestApproval.InstancePtr.sbStatusBar;
				}
				if (!(sb==null)) {
					if (!(sb.Panels[1 - 1]==null)) {
						sb.Panels[1 - 1].Text = message;
					}
				}
			}
		}

		// VBto upgrade warning: frm As Form	OnWrite(frmAdjustStockManual, frmAddStockManual)
		public static void ClearLogStatus(Form frm = null)
		{
			LogStatus("", frm);
		}




	}
}