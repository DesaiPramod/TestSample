using VBto;

namespace SKS
{
	public class modConnection
	{

		//=========================================================

		public static VBtoConnection CurrentConnection = new VBtoConnection();
		public static VBtoRecordSet rs = new VBtoRecordSet();
		public static VBtoRecordSet rs2 = new VBtoRecordSet();

		public static void OpenConnection()
		{
			CurrentConnection = new VBtoConnection();
			CurrentConnection.ConnectionString = modMain.ConnectionString; CurrentConnection.Open();
		}

		public static void ExecuteSql(string Statement)
		{
			rs = new VBtoRecordSet();
			rs.Open(Statement, CurrentConnection /*- , VBto.CursorTypeEnum.adOpenKeyset, VBto.Stub_ADODB_LockTypeEnum_adLockPessimistic */);
		}

		public static void ExecuteSql2(string Statement)
		{
			rs2 = new VBtoRecordSet();
			rs2.Open(Statement, CurrentConnection /*- , VBto.CursorTypeEnum.adOpenKeyset, VBto.Stub_ADODB_LockTypeEnum_adLockPessimistic */);
		}






	}
}