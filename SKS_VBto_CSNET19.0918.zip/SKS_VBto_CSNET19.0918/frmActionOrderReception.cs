using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace SKS
{
	/// <summary>
	/// Summary description for frmActionOrderReception.
	/// </summary>
	public class frmActionOrderReception : System.Windows.Forms.Form
	{
		public System.Windows.Forms.TextBox txtReceivedBy;
		public System.Windows.Forms.Button cmdApprove;
		public System.Windows.Forms.TextBox txtStatus;
		public System.Windows.Forms.TextBox txtReceived;
		public System.Windows.Forms.TextBox txtChangedBy;
		public System.Windows.Forms.TextBox txtChanged;
		public System.Windows.Forms.TextBox txtOrderID;
		public System.Windows.Forms.TextBox txtNotes;
		public System.Windows.Forms.TextBox txtSubTotal;
		public System.Windows.Forms.TextBox txtTotal;
		public System.Windows.Forms.TextBox txtTotalTax;
		public System.Windows.Forms.TextBox txtFreightCharge;
		public System.Windows.Forms.TextBox txtSalesTax;
		public System.Windows.Forms.TextBox txtEntry;
		public AxMSFlexGridLib.AxMSFlexGrid fgDetails;
		public System.Windows.Forms.StatusBar sbStatusBar;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel1;
		public System.Windows.Forms.Button cmdCancel;
		public System.Windows.Forms.Button cmdClose;
		public System.Windows.Forms.GroupBox Frame2;
		public System.Windows.Forms.TextBox txtProviderContact;
		public System.Windows.Forms.TextBox txtProviderCompany;
		public System.Windows.Forms.Label Label5;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.Label Label7;
		public System.Windows.Forms.Label Label3;
		public System.Windows.Forms.Label Label19;
		public System.Windows.Forms.Label lblChangedBy;
		public System.Windows.Forms.Label Label4;
		public System.Windows.Forms.Label lblChanged;
		public System.Windows.Forms.Label Label12;
		public System.Windows.Forms.Label Label11;
		public System.Windows.Forms.Label Label10;
		public System.Windows.Forms.Label Label9;
		public System.Windows.Forms.Label Label8;
		public System.Windows.Forms.Label Label6;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmActionOrderReception()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmActionOrderReception InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmActionOrderReception();
				return _InstancePtr;
			}
		}
		protected static frmActionOrderReception _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmActionOrderReception));
			this.txtReceivedBy = new System.Windows.Forms.TextBox();
			this.cmdApprove = new System.Windows.Forms.Button();
			this.txtStatus = new System.Windows.Forms.TextBox();
			this.txtReceived = new System.Windows.Forms.TextBox();
			this.txtChangedBy = new System.Windows.Forms.TextBox();
			this.txtChanged = new System.Windows.Forms.TextBox();
			this.txtOrderID = new System.Windows.Forms.TextBox();
			this.txtNotes = new System.Windows.Forms.TextBox();
			this.txtSubTotal = new System.Windows.Forms.TextBox();
			this.txtTotal = new System.Windows.Forms.TextBox();
			this.txtTotalTax = new System.Windows.Forms.TextBox();
			this.txtFreightCharge = new System.Windows.Forms.TextBox();
			this.txtSalesTax = new System.Windows.Forms.TextBox();
			this.txtEntry = new System.Windows.Forms.TextBox();
			this.fgDetails = new AxMSFlexGridLib.AxMSFlexGrid();
			this.sbStatusBar = new System.Windows.Forms.StatusBar();
			this.sbStatusBar_Panel1 = new System.Windows.Forms.StatusBarPanel();
			this.cmdCancel = new System.Windows.Forms.Button();
			this.cmdClose = new System.Windows.Forms.Button();
			this.Frame2 = new System.Windows.Forms.GroupBox();
			this.txtProviderContact = new System.Windows.Forms.TextBox();
			this.txtProviderCompany = new System.Windows.Forms.TextBox();
			this.Label5 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.Label7 = new System.Windows.Forms.Label();
			this.Label3 = new System.Windows.Forms.Label();
			this.Label19 = new System.Windows.Forms.Label();
			this.lblChangedBy = new System.Windows.Forms.Label();
			this.Label4 = new System.Windows.Forms.Label();
			this.lblChanged = new System.Windows.Forms.Label();
			this.Label12 = new System.Windows.Forms.Label();
			this.Label11 = new System.Windows.Forms.Label();
			this.Label10 = new System.Windows.Forms.Label();
			this.Label9 = new System.Windows.Forms.Label();
			this.Label8 = new System.Windows.Forms.Label();
			this.Label6 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			//
			// txtReceivedBy
			//
			this.txtReceivedBy.Name = "txtReceivedBy";
			this.txtReceivedBy.TabIndex = 33;
			this.txtReceivedBy.Location = new System.Drawing.Point(97, 65);
			this.txtReceivedBy.Size = new System.Drawing.Size(106, 20);
			this.txtReceivedBy.Text = "";
			this.txtReceivedBy.BackColor = System.Drawing.SystemColors.Menu;
			this.txtReceivedBy.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtReceivedBy.ReadOnly = true;
			//
			// cmdApprove
			//
			this.cmdApprove.Name = "cmdApprove";
			this.cmdApprove.TabIndex = 0;
			this.cmdApprove.Location = new System.Drawing.Point(235, 461);
			this.cmdApprove.Size = new System.Drawing.Size(90, 25);
			this.cmdApprove.Text = "&Add to Stock";
			this.cmdApprove.BackColor = System.Drawing.SystemColors.Control;
			this.cmdApprove.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdApprove.Click += new System.EventHandler(this.cmdApprove_Click);
			//
			// txtStatus
			//
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.TabIndex = 31;
			this.txtStatus.Location = new System.Drawing.Point(413, 8);
			this.txtStatus.Size = new System.Drawing.Size(106, 20);
			this.txtStatus.Text = "";
			this.txtStatus.BackColor = System.Drawing.SystemColors.Menu;
			this.txtStatus.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtStatus.ReadOnly = true;
			//
			// txtReceived
			//
			this.txtReceived.Name = "txtReceived";
			this.txtReceived.TabIndex = 29;
			this.txtReceived.Location = new System.Drawing.Point(97, 36);
			this.txtReceived.Size = new System.Drawing.Size(106, 20);
			this.txtReceived.Text = "";
			this.txtReceived.BackColor = System.Drawing.SystemColors.Menu;
			this.txtReceived.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtReceived.ReadOnly = true;
			//
			// txtChangedBy
			//
			this.txtChangedBy.Name = "txtChangedBy";
			this.txtChangedBy.TabIndex = 25;
			this.txtChangedBy.Location = new System.Drawing.Point(413, 65);
			this.txtChangedBy.Size = new System.Drawing.Size(106, 20);
			this.txtChangedBy.Text = "";
			this.txtChangedBy.BackColor = System.Drawing.SystemColors.Menu;
			this.txtChangedBy.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtChangedBy.ReadOnly = true;
			//
			// txtChanged
			//
			this.txtChanged.Name = "txtChanged";
			this.txtChanged.TabIndex = 24;
			this.txtChanged.Location = new System.Drawing.Point(413, 36);
			this.txtChanged.Size = new System.Drawing.Size(106, 20);
			this.txtChanged.Text = "";
			this.txtChanged.BackColor = System.Drawing.SystemColors.Menu;
			this.txtChanged.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtChanged.ReadOnly = true;
			//
			// txtOrderID
			//
			this.txtOrderID.Name = "txtOrderID";
			this.txtOrderID.TabIndex = 23;
			this.txtOrderID.Location = new System.Drawing.Point(97, 8);
			this.txtOrderID.Size = new System.Drawing.Size(106, 20);
			this.txtOrderID.Text = "";
			this.txtOrderID.BackColor = System.Drawing.SystemColors.Menu;
			this.txtOrderID.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtOrderID.ReadOnly = true;
			//
			// txtNotes
			//
			this.txtNotes.Name = "txtNotes";
			this.txtNotes.TabIndex = 3;
			this.txtNotes.Location = new System.Drawing.Point(57, 154);
			this.txtNotes.Size = new System.Drawing.Size(462, 44);
			this.txtNotes.Text = "";
			this.txtNotes.BackColor = System.Drawing.SystemColors.Menu;
			this.txtNotes.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtNotes.Multiline = true;
			this.txtNotes.ReadOnly = true;
			//
			// txtSubTotal
			//
			this.txtSubTotal.Name = "txtSubTotal";
			this.txtSubTotal.TabStop = false;
			this.txtSubTotal.TabIndex = 21;
			this.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtSubTotal.Location = new System.Drawing.Point(372, 413);
			this.txtSubTotal.Size = new System.Drawing.Size(147, 20);
			this.txtSubTotal.Text = "";
			this.txtSubTotal.BackColor = System.Drawing.SystemColors.Menu;
			this.txtSubTotal.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtSubTotal.ReadOnly = true;
			//
			// txtTotal
			//
			this.txtTotal.Name = "txtTotal";
			this.txtTotal.TabStop = false;
			this.txtTotal.TabIndex = 19;
			this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtTotal.Location = new System.Drawing.Point(89, 437);
			this.txtTotal.Size = new System.Drawing.Size(147, 20);
			this.txtTotal.Text = "";
			this.txtTotal.BackColor = System.Drawing.SystemColors.Menu;
			this.txtTotal.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtTotal.ReadOnly = true;
			//
			// txtTotalTax
			//
			this.txtTotalTax.Name = "txtTotalTax";
			this.txtTotalTax.TabStop = false;
			this.txtTotalTax.TabIndex = 17;
			this.txtTotalTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtTotalTax.Location = new System.Drawing.Point(372, 388);
			this.txtTotalTax.Size = new System.Drawing.Size(147, 20);
			this.txtTotalTax.Text = "";
			this.txtTotalTax.BackColor = System.Drawing.SystemColors.Menu;
			this.txtTotalTax.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtTotalTax.ReadOnly = true;
			//
			// txtFreightCharge
			//
			this.txtFreightCharge.Name = "txtFreightCharge";
			this.txtFreightCharge.TabIndex = 6;
			this.txtFreightCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtFreightCharge.Location = new System.Drawing.Point(89, 413);
			this.txtFreightCharge.Size = new System.Drawing.Size(147, 20);
			this.txtFreightCharge.Text = "";
			this.txtFreightCharge.BackColor = System.Drawing.SystemColors.Menu;
			this.txtFreightCharge.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtFreightCharge.ReadOnly = true;
			//
			// txtSalesTax
			//
			this.txtSalesTax.Name = "txtSalesTax";
			this.txtSalesTax.TabIndex = 5;
			this.txtSalesTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtSalesTax.Location = new System.Drawing.Point(89, 388);
			this.txtSalesTax.Size = new System.Drawing.Size(147, 20);
			this.txtSalesTax.Text = "";
			this.txtSalesTax.BackColor = System.Drawing.SystemColors.Menu;
			this.txtSalesTax.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtSalesTax.ReadOnly = true;
			//
			// txtEntry
			//
			this.txtEntry.Name = "txtEntry";
			this.txtEntry.Visible = false;
			this.txtEntry.TabIndex = 14;
			this.txtEntry.Location = new System.Drawing.Point(421, 316);
			this.txtEntry.Size = new System.Drawing.Size(74, 19);
			this.txtEntry.Text = "";
			this.txtEntry.BackColor = System.Drawing.SystemColors.Window;
			this.txtEntry.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtEntry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtEntry.BorderStyle = System.Windows.Forms.BorderStyle.None;
			//
			// fgDetails
			//
			this.fgDetails.Name = "fgDetails";
			this.fgDetails.TabIndex = 4;
			this.fgDetails.Location = new System.Drawing.Point(8, 202);
			this.fgDetails.Size = new System.Drawing.Size(511, 179);
			this.fgDetails.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("fgDetails.OcxState")));
			//
			// sbStatusBar
			//
			this.sbStatusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {this.sbStatusBar_Panel1});
			this.sbStatusBar.Name = "sbStatusBar";
			this.sbStatusBar.TabIndex = 13;
			this.sbStatusBar.Location = new System.Drawing.Point(0, 500);
			this.sbStatusBar.Size = new System.Drawing.Size(529, 25);
			this.sbStatusBar.ShowPanels = true;
			this.sbStatusBar.SizingGrip = false;
			//
			// Panel1
			//
			this.sbStatusBar_Panel1.Text = "";
			this.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbStatusBar_Panel1.Width = 509;
			//
			// cmdCancel
			//
			this.cmdCancel.Name = "cmdCancel";
			this.cmdCancel.TabIndex = 1;
			this.cmdCancel.Location = new System.Drawing.Point(332, 461);
			this.cmdCancel.Size = new System.Drawing.Size(90, 25);
			this.cmdCancel.Text = "&Cancel Order";
			this.cmdCancel.BackColor = System.Drawing.SystemColors.Control;
			this.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
			//
			// cmdClose
			//
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.TabIndex = 2;
			this.cmdClose.Location = new System.Drawing.Point(429, 461);
			this.cmdClose.Size = new System.Drawing.Size(90, 25);
			this.cmdClose.Text = "&Close";
			this.cmdClose.BackColor = System.Drawing.SystemColors.Control;
			this.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			//
			// Frame2
			//
			this.Frame2.Controls.Add(this.txtProviderContact);
			this.Frame2.Controls.Add(this.txtProviderCompany);
			this.Frame2.Controls.Add(this.Label5);
			this.Frame2.Controls.Add(this.Label1);
			this.Frame2.Name = "Frame2";
			this.Frame2.TabIndex = 7;
			this.Frame2.Location = new System.Drawing.Point(8, 97);
			this.Frame2.Size = new System.Drawing.Size(511, 50);
			this.Frame2.Text = "Supplier";
			this.Frame2.BackColor = System.Drawing.SystemColors.Control;
			this.Frame2.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// txtProviderContact
			//
			this.txtProviderContact.Name = "txtProviderContact";
			this.txtProviderContact.TabStop = false;
			this.txtProviderContact.TabIndex = 11;
			this.txtProviderContact.Location = new System.Drawing.Point(291, 16);
			this.txtProviderContact.Size = new System.Drawing.Size(211, 20);
			this.txtProviderContact.Text = "";
			this.txtProviderContact.BackColor = System.Drawing.SystemColors.Menu;
			this.txtProviderContact.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtProviderContact.ReadOnly = true;
			//
			// txtProviderCompany
			//
			this.txtProviderCompany.Name = "txtProviderCompany";
			this.txtProviderCompany.TabStop = false;
			this.txtProviderCompany.TabIndex = 10;
			this.txtProviderCompany.Location = new System.Drawing.Point(73, 16);
			this.txtProviderCompany.Size = new System.Drawing.Size(147, 20);
			this.txtProviderCompany.Text = "";
			this.txtProviderCompany.BackColor = System.Drawing.SystemColors.Menu;
			this.txtProviderCompany.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtProviderCompany.ReadOnly = true;
			//
			// Label5
			//
			this.Label5.Name = "Label5";
			this.Label5.TabIndex = 9;
			this.Label5.Location = new System.Drawing.Point(8, 16);
			this.Label5.Size = new System.Drawing.Size(58, 17);
			this.Label5.Text = "Name:";
			this.Label5.BackColor = System.Drawing.SystemColors.Control;
			this.Label5.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label1
			//
			this.Label1.Name = "Label1";
			this.Label1.TabIndex = 8;
			this.Label1.Location = new System.Drawing.Point(235, 16);
			this.Label1.Size = new System.Drawing.Size(58, 17);
			this.Label1.Text = "Contact:";
			this.Label1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label7
			//
			this.Label7.Name = "Label7";
			this.Label7.TabIndex = 34;
			this.Label7.Location = new System.Drawing.Point(8, 65);
			this.Label7.Size = new System.Drawing.Size(74, 17);
			this.Label7.Text = "Received by:";
			this.Label7.BackColor = System.Drawing.SystemColors.Control;
			this.Label7.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label3
			//
			this.Label3.Name = "Label3";
			this.Label3.TabIndex = 32;
			this.Label3.Location = new System.Drawing.Point(324, 8);
			this.Label3.Size = new System.Drawing.Size(50, 17);
			this.Label3.Text = "Status:";
			this.Label3.BackColor = System.Drawing.SystemColors.Control;
			this.Label3.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label19
			//
			this.Label19.Name = "Label19";
			this.Label19.TabIndex = 30;
			this.Label19.Location = new System.Drawing.Point(8, 32);
			this.Label19.Size = new System.Drawing.Size(58, 17);
			this.Label19.Text = "Received:";
			this.Label19.BackColor = System.Drawing.SystemColors.Control;
			this.Label19.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// lblChangedBy
			//
			this.lblChangedBy.Name = "lblChangedBy";
			this.lblChangedBy.TabIndex = 28;
			this.lblChangedBy.Location = new System.Drawing.Point(324, 65);
			this.lblChangedBy.Size = new System.Drawing.Size(90, 17);
			this.lblChangedBy.Text = "Changed by:";
			this.lblChangedBy.BackColor = System.Drawing.SystemColors.Control;
			this.lblChangedBy.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label4
			//
			this.Label4.Name = "Label4";
			this.Label4.TabIndex = 27;
			this.Label4.Location = new System.Drawing.Point(12, 8);
			this.Label4.Size = new System.Drawing.Size(50, 17);
			this.Label4.Text = "Order Id:";
			this.Label4.BackColor = System.Drawing.SystemColors.Control;
			this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// lblChanged
			//
			this.lblChanged.Name = "lblChanged";
			this.lblChanged.TabIndex = 26;
			this.lblChanged.Location = new System.Drawing.Point(324, 36);
			this.lblChanged.Size = new System.Drawing.Size(90, 17);
			this.lblChanged.Text = "Changed:";
			this.lblChanged.BackColor = System.Drawing.SystemColors.Control;
			this.lblChanged.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label12
			//
			this.Label12.Name = "Label12";
			this.Label12.TabIndex = 22;
			this.Label12.Location = new System.Drawing.Point(8, 413);
			this.Label12.Size = new System.Drawing.Size(90, 17);
			this.Label12.Text = "Freight Charge:";
			this.Label12.BackColor = System.Drawing.SystemColors.Control;
			this.Label12.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label11
			//
			this.Label11.Name = "Label11";
			this.Label11.TabIndex = 20;
			this.Label11.Location = new System.Drawing.Point(8, 437);
			this.Label11.Size = new System.Drawing.Size(90, 17);
			this.Label11.Text = "Total:";
			this.Label11.BackColor = System.Drawing.SystemColors.Control;
			this.Label11.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label10
			//
			this.Label10.Name = "Label10";
			this.Label10.TabIndex = 18;
			this.Label10.Location = new System.Drawing.Point(291, 388);
			this.Label10.Size = new System.Drawing.Size(90, 17);
			this.Label10.Text = "Total Tax:";
			this.Label10.BackColor = System.Drawing.SystemColors.Control;
			this.Label10.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label9
			//
			this.Label9.Name = "Label9";
			this.Label9.TabIndex = 16;
			this.Label9.Location = new System.Drawing.Point(291, 413);
			this.Label9.Size = new System.Drawing.Size(90, 17);
			this.Label9.Text = "Sub Total:";
			this.Label9.BackColor = System.Drawing.SystemColors.Control;
			this.Label9.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label8
			//
			this.Label8.Name = "Label8";
			this.Label8.TabIndex = 15;
			this.Label8.Location = new System.Drawing.Point(8, 388);
			this.Label8.Size = new System.Drawing.Size(90, 17);
			this.Label8.Text = "Sales Tax:";
			this.Label8.BackColor = System.Drawing.SystemColors.Control;
			this.Label8.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label6
			//
			this.Label6.Name = "Label6";
			this.Label6.TabIndex = 12;
			this.Label6.Location = new System.Drawing.Point(8, 162);
			this.Label6.Size = new System.Drawing.Size(33, 17);
			this.Label6.Text = "Notes:";
			this.Label6.BackColor = System.Drawing.SystemColors.Control;
			this.Label6.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// frmActionOrderReception
			//
			this.ClientSize = new System.Drawing.Size(529, 525);
			this.Controls.Add(this.txtReceivedBy);
			this.Controls.Add(this.cmdApprove);
			this.Controls.Add(this.txtStatus);
			this.Controls.Add(this.txtReceived);
			this.Controls.Add(this.txtChangedBy);
			this.Controls.Add(this.txtChanged);
			this.Controls.Add(this.txtOrderID);
			this.Controls.Add(this.txtNotes);
			this.Controls.Add(this.txtSubTotal);
			this.Controls.Add(this.txtTotal);
			this.Controls.Add(this.txtTotalTax);
			this.Controls.Add(this.txtFreightCharge);
			this.Controls.Add(this.txtSalesTax);
			this.Controls.Add(this.txtEntry);
			this.Controls.Add(this.fgDetails);
			this.Controls.Add(this.sbStatusBar);
			this.Controls.Add(this.cmdCancel);
			this.Controls.Add(this.cmdClose);
			this.Controls.Add(this.Frame2);
			this.Controls.Add(this.Label7);
			this.Controls.Add(this.Label3);
			this.Controls.Add(this.Label19);
			this.Controls.Add(this.lblChangedBy);
			this.Controls.Add(this.Label4);
			this.Controls.Add(this.lblChanged);
			this.Controls.Add(this.Label12);
			this.Controls.Add(this.Label11);
			this.Controls.Add(this.Label10);
			this.Controls.Add(this.Label9);
			this.Controls.Add(this.Label8);
			this.Controls.Add(this.Label6);
			this.Name = "frmActionOrderReception";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
			this.Load += new System.EventHandler(this.frmActionOrderReception_Load);
			this.Text = "Add Stock to Inventory";
			((System.ComponentModel.ISupportInitialize)(this.fgDetails)).EndInit();
			this.Frame2.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================

		private double currentSubTotal;
		private double currentTotal;
		private double currentTax;
		private double currentFreightCharge;
		private double currentTotalTax;

		public int Action;

		public int OrderId;

		private void cmdApprove_Click(object sender, System.EventArgs e)
		{
			try
			{	// On Error GoTo HandleError
				if (Strings.UCase(txtStatus.Text)=="APPROVED") {
					modMain.LogStatus("Order is already approved, not need to be approved again", this);
					return;
				}

				if (Strings.UCase(txtStatus.Text)=="CANCELLED") {
					modMain.LogStatus("Order was already approved by "+txtChangedBy.Text+" on "+txtChanged.Text+", it cannot be approved", this);
					return;
				}


				// UPDATE
				modConnection.ExecuteSql("Update OrderReceptions Set Status = 'APPROVED', ChangedBy = '"+modMain.UserId+"', ChangedDate = #"+DateTime.Today.ToShortDateString()+"#"+" Where OrderId = "+Convert.ToString(OrderId));

				modConnection.ExecuteSql("Select ProductId, Quantity, UnitPrice, LineTotal "+"From OrderReceptionDetails Where OrderID = "+Convert.ToString(OrderId));


				while (!modConnection.rs.EOF) {

					modConnection.ExecuteSql2("Insert Into Stocks "+"(ProductID, Stock, InitialStock, DateStarted, DateModified, User, UnitPrice, StockPrice) Values "+"('"+Convert.ToString(modConnection.rs.Fields["ProductId"].Value)+"',"+Convert.ToString(modConnection.rs.Fields["Quantity"].Value)+","+Convert.ToString(modConnection.rs.Fields["Quantity"].Value)+", #"+DateTime.Today.ToShortDateString()+"#, #"+DateTime.Today.ToShortDateString()+"#, '"+modMain.UserId+"', "+Convert.ToString(modConnection.rs.Fields["UnitPrice"].Value)+","+Convert.ToString(modConnection.rs.Fields["LineTotal"].Value)+")");

					modConnection.ExecuteSql2("Select Max(StockID) as NewId From Stocks");
					int newId;
					newId = Convert.ToInt32(modConnection.rs2.Fields["NewId"].Value);

					modConnection.ExecuteSql2("Insert Into StockLogs "+"(DocID, DocType, StockID, ProductId, Quantity, StockPrice, Date, User) Values "+"("+Convert.ToString(modConnection.rs.Fields["ProductId"].Value)+","+Convert.ToString(modConnection.rs.Fields["ProductId"].Value)+","+","+Convert.ToString(modConnection.rs.Fields["ProductId"].Value)+","+","+Convert.ToString(modConnection.rs.Fields["ProductId"].Value)+","+","+Convert.ToString(modConnection.rs.Fields["ProductId"].Value)+","+","+Convert.ToString(modConnection.rs.Fields["ProductId"].Value)+",#"+DateTime.Today.ToShortDateString()+"#, '"+modMain.UserId+"')");

					modConnection.rs.MoveNext();
				}


				modConnection.ExecuteSql("Insert Into Stocks "+"(ProductID, Stock, InitialStock, DateStarted, DateModified, User, UnitPrice, StockPrice) "+"Select ProductId, Quantity, Quantity, #"+DateTime.Today.ToShortDateString()+"#, #"+DateTime.Today.ToShortDateString()+"#, '"+modMain.UserId+"', UnitPrice, LineTotal "+"From OrderReceptionDetails "+"Where OrderID = "+Convert.ToString(OrderId));

				modConnection.ExecuteSql("Update Products as p Set UnitsInStock = UnitsInStock + "+" ( Select Sum(Quantity) From OrderReceptionDetails Where OrderId = "+Convert.ToString(OrderId)+" and ProductId = p.ProductId) "+" Where ProductId in Select ProductId From OrderReceptionDetails Where OrderId = "+Convert.ToString(OrderId));

				return;
			}
			catch
			{	// HandleError:
				// ...
			}
			MessageBox.Show("An error has occurred adding the data. Error: ("+Convert.ToString(Information.Err().Number)+") "+Information.Err().Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);

		}
		public void cmdApprove_Click()
		{
			cmdApprove_Click(cmdApprove, new System.EventArgs());
		}

		private void cmdCancel_Click(object sender, System.EventArgs e)
		{
			try
			{	// On Error GoTo HandleError
				if (Strings.UCase(txtStatus.Text)=="CANCELLED") {
					modMain.LogStatus("Order was already cancelled, not need to be cancelled again", this);
					return;
				}
				if (Strings.UCase(txtStatus.Text)=="APPROVED") {
					modMain.LogStatus("Order was already cancelled by "+txtChangedBy.Text+" on "+txtChanged.Text+", it cannot be canceled", this);
					return;
				}


				if (MessageBox.Show("Do you want to cancel the order reception?", "Confirm cancellation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)!=DialogResult.Yes) {
					return;
				}

				// UPDATE
				modConnection.ExecuteSql("Update OrderReceptions Set Status = 'CANCELLED', ChangedBy = '"+modMain.UserId+"', ChangedDate = #"+DateTime.Today.ToShortDateString()+"#"+" Where OrderId = "+Convert.ToString(OrderId));

				LoadData();
				MessageBox.Show("The order was successfully cancelled");
				Close();

				return;
			}
			catch
			{	// HandleError:
				// ...
			}
			MessageBox.Show("An error has occurred adding the data. Error: ("+Convert.ToString(Information.Err().Number)+") "+Information.Err().Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);

		}
		public void cmdCancel_Click()
		{
			cmdCancel_Click(cmdCancel, new System.EventArgs());
		}

		private void frmActionOrderReception_Load(object sender, System.EventArgs e)
		{
			// LoadData
			if (Action!=0) {

				switch (Action) {
					
					case 1:
					{
						cmdApprove_Click();
						break;
					}
					case 2:
					{
						cmdCancel_Click();
						break;
					}
				} //end switch
			}
		}

		public void LoadData()
		{
			currentSubTotal = 0;
			currentTotalTax = 0;
			modConnection.ExecuteSql("Select o.OrderDate, u.Fullname, o.Status, p.ProviderName, p.ContactFirstName + ' ' + p.ContactLastName as Contact, o.ChangedDate, o.ChangedBy, o.FreightCharge, o.SalesTaxRate, o.Notes "+"From OrderReceptions as o, Users as u, Providers as p "+"Where o.OrderID = "+Convert.ToString(OrderId)+" And u.Username = o.ReceivedBy And p.ProviderId = o.ProviderId");
			if (modConnection.rs.EOF) {
				modMain.LogStatus("The order with the ID '"+Convert.ToString(OrderId)+"' does not exist", this);
				return;
			}
			txtOrderID.Text = Convert.ToString(OrderId);
			txtReceived.Text = Convert.ToString(modConnection.rs.Fields["OrderDate"].Value);
			txtReceivedBy.Text = Convert.ToString(modConnection.rs.Fields["Fullname"].Value);
			if (modConnection.rs.Fields["Notes"].Value!=null) txtNotes.Text = Convert.ToString(modConnection.rs.Fields["Notes"].Value);
			txtFreightCharge.Text = Convert.ToString(modConnection.rs.Fields["FreightCharge"].Value);
			currentFreightCharge = VBto.ObjectToDouble(modConnection.rs.Fields["FreightCharge"].Value);
			txtSalesTax.Text = Convert.ToString(modConnection.rs.Fields["SalesTaxRate"].Value);
			currentTax = VBto.ObjectToDouble(modConnection.rs.Fields["SalesTaxRate"].Value);
			txtProviderCompany.Text = Convert.ToString(modConnection.rs.Fields["ProviderName"].Value);
			txtProviderContact.Text = Convert.ToString(modConnection.rs.Fields["Contact"].Value);
			txtStatus.Text = Convert.ToString(modConnection.rs.Fields["Status"].Value);
			if (modConnection.rs.Fields["ChangedDate"].Value!=null) txtChanged.Text = Convert.ToString(modConnection.rs.Fields["ChangedDate"].Value);
			if (modConnection.rs.Fields["ChangedBy"].Value!=null) txtChangedBy.Text = Convert.ToString(modConnection.rs.Fields["ChangedBy"].Value);

			bool isReceived;
			isReceived = txtStatus.Text=="RECEIVED";
			lblChanged.Visible = !isReceived;
			lblChangedBy.Visible = !isReceived;
			txtChanged.Visible = !isReceived;
			txtChangedBy.Visible = !isReceived;
			cmdApprove.Enabled = true; // Received
			cmdCancel.Enabled = true; // Received

			if (txtStatus.Text=="APPROVED") {
				lblChanged.Text = "Approved Date:";
				lblChangedBy.Text = "Approved By:";
			} else {
				lblChanged.Text = "Cancelled Date:";
				lblChangedBy.Text = "Cancelled By:";
			}
			LoadDetails();
			DisplayTotals();
		}

		private void DisplayTotals()
		{
			currentTotal = currentFreightCharge+currentSubTotal+currentTotalTax;
			txtSubTotal.Text = VBto.vbFormat(currentSubTotal, "#,##0.00");
			txtTotalTax.Text = VBto.vbFormat(currentTotalTax, "#,##0.00");
			txtTotal.Text = VBto.vbFormat(currentTotal, "#,##0.00");
		}


		// VBto upgrade warning: current As double	OnWrite(VBtoField)
		private void AddToTotals(double current)
		{
			currentSubTotal += current;
			currentTotalTax = currentSubTotal*currentTax;
			currentTotal = currentFreightCharge+currentSubTotal+currentTotalTax;
			txtSubTotal.Text = VBto.vbFormat(currentSubTotal, "#,##0.00");
			txtTotalTax.Text = VBto.vbFormat(currentTotalTax, "#,##0.00");
			txtTotal.Text = VBto.vbFormat(currentTotal, "#,##0.00");
		}


		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void LoadDetails()
		{

			modConnection.ExecuteSql("Select d.Quantity, p.ProductID, p.ProductName, d.UnitPrice, d.SalePrice, p.UnitsInStock, p.UnitsOnOrder, Str(p.QuantityPerUnit) + p.Unit, d.LineTotal From Products as p, OrderReceptionDetails as d "+"Where d.OrderID = "+Convert.ToString(OrderId)+" And d.ProductId = p.ProductId");

			int lng/*unused?*/;
			int intLoopCount/*unused?*/;

			fgDetails.Rows = 0;
			fgDetails.Cols = 9;
			fgDetails.FixedCols = 0;
			fgDetails.AddItem("Quantity"+"\t"+"Code"+"\t"+"Product"+"\t"+"UnitPrice"+"\t"+"Price"+"\t"+"Existence"+"\t"+"Ordered"+"\t"+"Quantity per unit"+"\t"+"Line Total");
			fgDetails.Rows = modConnection.rs.RecordCount+1;
			if (fgDetails.Rows==1) fgDetails.FixedRows = 0; else  fgDetails.FixedRows = 1;
			int i;
			int j;
			i = 1;
			while (!modConnection.rs.EOF) {
				for(j=1; j<=modConnection.rs.ColumnCount; j++) {
					if (!VBto.IsEmpty(modConnection.rs.Fields[i].Value)) {
						fgDetails.set_TextMatrix(i, j-1, Convert.ToString(modConnection.rs.Fields[j-1].Value));
					}
				} // j
				AddToTotals(VBto.ObjectToDouble(modConnection.rs.Fields["LineTotal"].Value));
				modConnection.rs.MoveNext();
				i += 1;
			}


		}


	}
}