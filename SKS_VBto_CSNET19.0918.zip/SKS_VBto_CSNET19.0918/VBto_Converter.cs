using System;
using System.Windows.Forms;
using System.Drawing;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.Compatibility.VB6;

namespace SKS
{
	/// <summary>
	/// This is a part of the VBto Converter (www.vbto.net). Copyright (C) 2005-2018 StressSoft Company Ltd. All rights reserved.
	/// </summary>
	public class VBto
	{
		public static string vbFormat(object Expression, string Style)
		{
			return Support.Format(Expression, Style, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1);
		}

		public static double ObjectToDouble(object v)
		{
			double d;

			if (v is string)
			{
				string s = (string)v;
				d = Conversion.Val(s);
				return d;
			}

			if (v is DateTime)
			{
				DateTime dt = (DateTime)v;
				d = dt.ToOADate();
				return d;
			}

			d = Convert.ToDouble(v);
			return d;
		}

		public static string ObjectToString(object v)
		{
			if (v == null) return "";
			if (v is string) return (string)v;
			if (v is Color)
			{
				int iCol = ColorTranslator.ToOle((Color)v);
				return iCol.ToString();
			}

			string s = v.ToString();
			return s;
		}

		public static int Int(Decimal dc)
		{
			return (int)Math.Floor(dc);
		}
		public static int Int(double dValue)
		{
			return (int)Math.Floor(dValue);
		}
		public static int Int(string sValue)
		{
			//double d = Convert.ToDouble(sValue);
			double d = double.Parse(sValue);
			return (int)Math.Round(d);
		}

		public static void SubItemsSetText(ListViewItem itm, int SubItemIndex, string SubItemText)
		{
			int nAdd = SubItemIndex - itm.SubItems.Count;
			if (nAdd >= 0)
			{
				while(nAdd-->0) itm.SubItems.Add("");
				itm.SubItems.Add(SubItemText);
			}
			else
				itm.SubItems[SubItemIndex].Text = SubItemText;
		}

		public static bool IsEmpty(object obj)
		{
			return obj == null;
		}

		public static string GetAppTitle()
		{
			return Application.OpenForms[0].Text;
		}

		static public void ShowAsMdiChild(Form pMdiChild, Form pMdiParent)
		{
			pMdiChild.MdiParent = pMdiParent;
			pMdiChild.Show();
			pMdiChild.BringToFront();
		}
		static Form FindMDIContainer()
		{
			foreach (Form f in Application.OpenForms)
				if (f.IsMdiContainer) return f;
			return null;
		}
		static Form pMdiParent = null;
		static public void ShowAsMdiChild(Form pMdiChild)
		{
			if (pMdiParent == null)
				pMdiParent = FindMDIContainer();
			if (pMdiParent != null)
				ShowAsMdiChild(pMdiChild, pMdiParent);
			else pMdiChild.Show();	//?
		}


		public static void SetLeft(Control obj, double L)
		{
			int l = Convert.ToInt32(Support.TwipsToPixelsX(L));
			obj.SetBounds(l, 0, 0, 0, BoundsSpecified.X);
		}
		public static void SetLeftTop(Control obj, double L, double T)
		{
			int l = Convert.ToInt32(Support.TwipsToPixelsX(L));
			int t = Convert.ToInt32(Support.TwipsToPixelsY(T));
			obj.SetBounds(l, t, 0, 0, BoundsSpecified.Location);
		}
		public static void SetLeftTopWidth(Control obj, double L, double T, double W)
		{
			int l = Convert.ToInt32(Support.TwipsToPixelsX(L));
			int t = Convert.ToInt32(Support.TwipsToPixelsY(T));
			int w = Convert.ToInt32(Support.TwipsToPixelsX(W));
			obj.SetBounds(l, t, w, 0, BoundsSpecified.Location | BoundsSpecified.Width);
		}
		public static void SetBounds(Control obj, double X, double Y, double W, double H)
		{
			int x = Convert.ToInt32(Support.TwipsToPixelsX(X));
			int y = Convert.ToInt32(Support.TwipsToPixelsY(Y));
			int w = Convert.ToInt32(Support.TwipsToPixelsX(W));
			int h = Convert.ToInt32(Support.TwipsToPixelsY(H));
			obj.SetBounds(x, y, w, h);
		}

		public static bool stringCompare(string sL, string sOperation, string sR)
		{
			int iRet = string.Compare(sL, sR);
			switch (sOperation)
			{
				case ">": return iRet > 0;
				case "<": return iRet < 0;
				case ">=": return iRet >= 0;
				case "<=": return iRet <= 0;
				case "<>": return iRet != 0;
				case "=": return iRet == 0;
			}
			//???
			return false;
		}


		// === External Constants: ===
		public const int Stub_ADODB_LockTypeEnum_adLockPessimistic = 2;
		public const int Stub_ADODB_LockTypeEnum_adLockOptimistic = 3;

	}
}
