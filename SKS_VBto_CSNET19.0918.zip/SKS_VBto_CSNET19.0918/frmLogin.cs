using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace SKS
{
	/// <summary>
	/// Summary description for frmLogin.
	/// </summary>
	public class frmLogin : System.Windows.Forms.Form
	{
		public Microsoft.VisualBasic.Compatibility.VB6.LabelArray lblLabels;
		public System.Windows.Forms.TextBox txtUserName;
		public System.Windows.Forms.Button cmdCancel;
		public System.Windows.Forms.TextBox txtPassword;
		public System.Windows.Forms.Button cmdOK;
		public System.Windows.Forms.Label lblLabels_0;
		public System.Windows.Forms.Label lblLabels_1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmLogin()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLogin));
			this.components = new System.ComponentModel.Container();
			this.lblLabels = new Microsoft.VisualBasic.Compatibility.VB6.LabelArray();
			this.txtUserName = new System.Windows.Forms.TextBox();
			this.cmdCancel = new System.Windows.Forms.Button();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.cmdOK = new System.Windows.Forms.Button();
			this.lblLabels_0 = new System.Windows.Forms.Label();
			this.lblLabels_1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.lblLabels)).BeginInit();
			//
			// txtUserName
			//
			this.txtUserName.Name = "txtUserName";
			this.txtUserName.TabIndex = 1;
			this.txtUserName.Location = new System.Drawing.Point(119, 25);
			this.txtUserName.Size = new System.Drawing.Size(157, 23);
			this.txtUserName.Text = "";
			this.txtUserName.BackColor = System.Drawing.SystemColors.Window;
			this.txtUserName.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// cmdCancel
			//
			this.cmdCancel.Name = "cmdCancel";
			this.cmdCancel.TabIndex = 5;
			this.cmdCancel.Location = new System.Drawing.Point(198, 101);
			this.cmdCancel.Size = new System.Drawing.Size(77, 26);
			this.cmdCancel.Text = "Cancel";
			this.cmdCancel.BackColor = System.Drawing.SystemColors.Control;
			this.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
			//
			// txtPassword
			//
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.TabIndex = 3;
			this.txtPassword.Location = new System.Drawing.Point(119, 52);
			this.txtPassword.Size = new System.Drawing.Size(157, 23);
			this.txtPassword.Text = "";
			this.txtPassword.BackColor = System.Drawing.SystemColors.Window;
			this.txtPassword.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// cmdOK
			//
			this.cmdOK.Name = "cmdOK";
			this.cmdOK.TabIndex = 4;
			this.cmdOK.Location = new System.Drawing.Point(90, 101);
			this.cmdOK.Size = new System.Drawing.Size(77, 26);
			this.cmdOK.Text = "OK";
			this.cmdOK.BackColor = System.Drawing.SystemColors.Control;
			this.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
			//
			// lblLabels_0
			//
			this.lblLabels_0.Name = "lblLabels_0";
			this.lblLabels_0.TabIndex = 0;
			this.lblLabels_0.Location = new System.Drawing.Point(39, 26);
			this.lblLabels_0.Size = new System.Drawing.Size(73, 18);
			this.lblLabels_0.Text = "&User Name:";
			this.lblLabels_0.BackColor = System.Drawing.SystemColors.Control;
			this.lblLabels_0.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// lblLabels_1
			//
			this.lblLabels_1.Name = "lblLabels_1";
			this.lblLabels_1.TabIndex = 2;
			this.lblLabels_1.Location = new System.Drawing.Point(39, 53);
			this.lblLabels_1.Size = new System.Drawing.Size(73, 18);
			this.lblLabels_1.Text = "&Password:";
			this.lblLabels_1.BackColor = System.Drawing.SystemColors.Control;
			this.lblLabels_1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// frmLogin
			//
			this.ClientSize = new System.Drawing.Size(292, 139);
			this.Controls.Add(this.txtUserName);
			this.Controls.Add(this.cmdCancel);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.cmdOK);
			this.Controls.Add(this.lblLabels_0);
			this.Controls.Add(this.lblLabels_1);
			this.Name = "frmLogin";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.ShowInTaskbar = false;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("frmLogin.Icon")));
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Login";
			this.CancelButton = cmdCancel;
			this.AcceptButton = cmdOK;
			this.lblLabels.SetIndex( lblLabels_0, System.Convert.ToInt16( 0 ) );
			this.lblLabels.SetIndex( lblLabels_1, System.Convert.ToInt16( 1 ) );
			((System.ComponentModel.ISupportInitialize)(this.lblLabels)).EndInit();
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================

		public bool LoginSucceeded;

		private void cmdCancel_Click(object sender, System.EventArgs e)
		{
			LoginSucceeded = false;
			Close();
		}

		private void cmdOK_Click(object sender, System.EventArgs e)
		{
			modConnection.ExecuteSql("SELECT * FROM Users WHERE username = '"+txtUserName.Text+"' and password = '"+txtPassword.Text+"'");
			if (modConnection.rs.EOF) {
				MessageBox.Show("Invalid 'Username' or 'Password', please try again!", null, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				txtUserName.Focus();
				modFunctions.SelectAll(txtUserName);
				return;
			}
			modMain.UserFullname = Convert.ToString(modConnection.rs.Fields["Fullname"].Value);
			modMain.UserLevel = Convert.ToString(modConnection.rs.Fields["Level"].Value);
			modMain.CurrentUserAdmin = (modMain.UserLevel=="Administrator");
			this.Cursor = Cursors.Default;
			LoginSucceeded = true;
			modMain.LogStatus("User : "+modMain.UserFullname+" logged at "+Convert.ToString(DateTime.Now.Date)+","+Convert.ToString(DateAndTime.TimeValue(Convert.ToString(DateTime.Now))));
			Close();
		}

	}
}