
namespace SKS
{
	/// <summary>
	/// Summary description for frmAbout.
	/// </summary>
	public class frmAbout : System.Windows.Forms.Form
	{
		public VBtoFigures.LineArray Line1;
		public System.Windows.Forms.PictureBox picIcon;
		public System.Windows.Forms.Button cmdOK;
		public VBtoFigures.Line Line1_1;
		public System.Windows.Forms.Label lblDescription;
		public System.Windows.Forms.Label lblTitle;
		public VBtoFigures.Line Line1_0;
		public System.Windows.Forms.Label lblVersion;
		public System.Windows.Forms.Label lblDisclaimer;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmAbout()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmAbout InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmAbout();
				return _InstancePtr;
			}
		}
		protected static frmAbout _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAbout));
			this.components = new System.ComponentModel.Container();
			this.Line1 = new VBtoFigures.LineArray();
			this.picIcon = new System.Windows.Forms.PictureBox();
			this.cmdOK = new System.Windows.Forms.Button();
			this.Line1_1 = new VBtoFigures.Line();
			this.lblDescription = new System.Windows.Forms.Label();
			this.lblTitle = new System.Windows.Forms.Label();
			this.Line1_0 = new VBtoFigures.Line();
			this.lblVersion = new System.Windows.Forms.Label();
			this.lblDisclaimer = new System.Windows.Forms.Label();
			this.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.Line1)).BeginInit();
			//
			// picIcon
			//
			this.picIcon.Name = "picIcon";
			this.picIcon.TabIndex = 1;
			this.picIcon.Location = new System.Drawing.Point(16, 16);
			this.picIcon.Size = new System.Drawing.Size(133, 133);
			this.picIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.picIcon.BackColor = System.Drawing.SystemColors.Control;
			this.picIcon.Image = ((System.Drawing.Image)(resources.GetObject("picIcon.Image")));
			this.picIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			//
			// cmdOK
			//
			this.cmdOK.Name = "cmdOK";
			this.cmdOK.TabIndex = 0;
			this.cmdOK.Location = new System.Drawing.Point(275, 210);
			this.cmdOK.Size = new System.Drawing.Size(109, 23);
			this.cmdOK.Text = "OK";
			this.cmdOK.BackColor = System.Drawing.SystemColors.Control;
			this.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
			//
			// Line1_1
			//
			this.Line1_1.Name = "Line1_1";
			this.Line1_1.LineColor = System.Drawing.Color.FromArgb(((System.Byte)(128)), ((System.Byte)(128)), ((System.Byte)(128)));
			this.Line1_1.X1 = 6;
			this.Line1_1.Y1 = 165;
			this.Line1_1.X2 = 380;
			this.Line1_1.Y2 = 165;
			this.Line1_1.Location = new System.Drawing.Point(6, 165);
			this.Line1_1.Size = new System.Drawing.Size(374, 1);
			//
			// lblDescription
			//
			this.lblDescription.Name = "lblDescription";
			this.lblDescription.TabIndex = 2;
			this.lblDescription.AutoSize = true;
			this.lblDescription.Location = new System.Drawing.Point(165, 81);
			this.lblDescription.Size = new System.Drawing.Size(201, 13);
			this.lblDescription.Text = "Order Processing Software by Mobilize.net";
			this.lblDescription.BackColor = System.Drawing.SystemColors.Control;
			this.lblDescription.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(0)), ((System.Byte)(0)));
			//
			// lblTitle
			//
			this.lblTitle.Name = "lblTitle";
			this.lblTitle.TabIndex = 4;
			this.lblTitle.AutoSize = true;
			this.lblTitle.Location = new System.Drawing.Point(165, 24);
			this.lblTitle.Size = new System.Drawing.Size(123, 13);
			this.lblTitle.Text = "Salmon King Seafood";
			this.lblTitle.BackColor = System.Drawing.SystemColors.Control;
			this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(0)), ((System.Byte)(0)));
			this.lblTitle.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// Line1_0
			//
			this.Line1_0.Name = "Line1_0";
			this.Line1_0.LineColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(255)));
			this.Line1_0.LineWidth = 2;
			this.Line1_0.X1 = 7;
			this.Line1_0.Y1 = 166;
			this.Line1_0.X2 = 380;
			this.Line1_0.Y2 = 166;
			this.Line1_0.Location = new System.Drawing.Point(7, 166);
			this.Line1_0.Size = new System.Drawing.Size(373, 2);
			//
			// lblVersion
			//
			this.lblVersion.Name = "lblVersion";
			this.lblVersion.TabIndex = 5;
			this.lblVersion.AutoSize = true;
			this.lblVersion.Location = new System.Drawing.Point(165, 57);
			this.lblVersion.Size = new System.Drawing.Size(139, 13);
			this.lblVersion.Text = "Version: Mobilize - WebMAP ";
			this.lblVersion.BackColor = System.Drawing.SystemColors.Control;
			this.lblVersion.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// lblDisclaimer
			//
			this.lblDisclaimer.Name = "lblDisclaimer";
			this.lblDisclaimer.TabIndex = 3;
			this.lblDisclaimer.AutoSize = true;
			this.lblDisclaimer.Location = new System.Drawing.Point(17, 177);
			this.lblDisclaimer.Size = new System.Drawing.Size(277, 13);
			this.lblDisclaimer.Text = "Warning: This product is protected by copyright laws 2016";
			this.lblDisclaimer.BackColor = System.Drawing.SystemColors.Control;
			this.lblDisclaimer.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(0)), ((System.Byte)(0)));
			//
			// frmAbout
			//
			this.ClientSize = new System.Drawing.Size(398, 240);
			this.Controls.Add(this.picIcon);
			this.Controls.Add(this.cmdOK);
			this.Controls.Add(this.Line1_1);
			this.Controls.Add(this.lblDescription);
			this.Controls.Add(this.lblTitle);
			this.Controls.Add(this.Line1_0);
			this.Controls.Add(this.lblVersion);
			this.Controls.Add(this.lblDisclaimer);
			this.Name = "frmAbout";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.ShowInTaskbar = false;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Load += new System.EventHandler(this.frmAbout_Load);
			this.Text = "About SKS Sales agent";
			this.AcceptButton = cmdOK;
			this.Line1.SetIndex( Line1_1, System.Convert.ToInt16( 1 ) );
			this.Line1.SetIndex( Line1_0, System.Convert.ToInt16( 0 ) );
			((System.ComponentModel.ISupportInitialize)(this.Line1)).EndInit();
			this.lblTitle.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================

		// Reg Key Security Options...
		const int READ_CONTROL = 0x20000;
		const short KEY_QUERY_VALUE = 0x1;
		const short KEY_SET_VALUE = 0x2;
		const short KEY_CREATE_SUB_KEY = 0x4;
		const short KEY_ENUMERATE_SUB_KEYS = 0x8;
		const short KEY_NOTIFY = 0x10;
		const short KEY_CREATE_LINK = 0x20;
		const int KEY_ALL_ACCESS = KEY_QUERY_VALUE+KEY_SET_VALUE+KEY_CREATE_SUB_KEY+KEY_ENUMERATE_SUB_KEYS+KEY_NOTIFY+KEY_CREATE_LINK+READ_CONTROL;

		// Reg Key ROOT Types...
		const uint HKEY_LOCAL_MACHINE = 0x80000002;
		const short ERROR_SUCCESS = 0;
		const short REG_SZ = 1; // Unicode nul terminated string
		const short REG_DWORD = 4; // 32-bit number


		private void cmdOK_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void frmAbout_Load(object sender, System.EventArgs e)
		{
			this.Text = "About "+VBto.GetAppTitle();
			// lblVersion.Caption = "Version " & App.Major & "." & App.Minor & "." & App.Revision
			lblTitle.Text = VBto.GetAppTitle();
		}


	}
}