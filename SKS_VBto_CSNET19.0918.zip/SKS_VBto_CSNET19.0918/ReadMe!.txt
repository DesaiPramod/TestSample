
At the beginning of the work, you must Rebuild the auxiliary project VBto.
Then you can continue to work with the main project SKS.

VBto Converter 2.89 beta2-Debug (www.vbto.net) generate this Solution.
Date: 18.09.2021  12:32:05
