using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.Compatibility.VB6;

namespace SKS
{
	public class modFunctions
	{

		//=========================================================

		public static void AppendAND(ref string filter)
		{
			if (filter!=String.Empty) {
				filter += " AND ";
			}
		}

		public static bool AddToCollection(Collection col, string Item)
		{
			bool AddToCollection;
			AddToCollection = false;
			if (!Exists(col, Item)) {
				col.Add(Item, Item, null, null);
				AddToCollection = true;
			}
			return AddToCollection;
		}

		public static bool Exists(Collection col, string Index)
		{
			bool Exists;
			// VBto upgrade warning: o As object	OnWrite(CollectionItem)
			object o = null;
			try
			{	// On Error GoTo Error
				o = col[Index];
			}
			catch
			{	// Error:
				// ...
			}
			Exists = o!=null;
			return Exists;
		}


		// VBto upgrade warning: 'Return' As Variant --> As double	OnWrite(double, short)
		public static double DoubleValue(string strValue)
		{
			double DoubleValue;
			if (strValue.Length!=0) {
				DoubleValue = Convert.ToDouble(double.Parse(strValue));
			} else {
				DoubleValue = 0;
			}
			return DoubleValue;
		}

		// VBto upgrade warning: parentForm As Form	OnWrite(frmOrderRequest, frmOrderReception)
		// VBto upgrade warning: 'Return' As Variant --> As bool
		public static bool ValidateTextBoxDouble(TextBox txBox, Form parentForm)
		{
			bool ValidateTextBoxDouble = false;
			try
			{	// On Error GoTo err
				DoubleValue(txBox.Text);
				ValidateTextBoxDouble = true;
				return ValidateTextBoxDouble;
			}
			catch
			{	// err:
				// ...
			}
			modMain.LogStatus("The value inserted is not valid", parentForm);
			txBox.Text = "";
			txBox.Focus();
			ValidateTextBoxDouble = false;
			return ValidateTextBoxDouble;
		}

		// VBto upgrade warning: parentForm As Form	OnWrite(frmOrderRequest, frmOrderReception)
		// VBto upgrade warning: 'Return' As Variant --> As bool
		public static bool ValidateTextDouble(string text, Form parentForm)
		{
			bool ValidateTextDouble = false;
			try
			{	// On Error GoTo err
				DoubleValue(text);
				ValidateTextDouble = true;
				return ValidateTextDouble;
			}
			catch
			{	// err:
				// ...
			}
			modMain.LogStatus("The value inserted is not valid", parentForm);
			ValidateTextDouble = false;
			return ValidateTextDouble;
		}

		public static void SelectAll(TextBox txtBox)
		{
			txtBox.SelectionStart = 0;
			txtBox.SelectionLength = Marshal.SizeOf(txtBox);
		}

#if defUse_UpCase
		// VBto upgrade warning: 'Return' As Variant --> As int
		public static int UpCase(int KeyAscii)
		{
			int UpCase;
			UpCase = Strings.Asc(Strings.UCase(Convert.ToString(Convert.ToChar(KeyAscii))));
			return UpCase;
		}
#endif


		// 
		// Combobox related functions '''
		// 

		public static void LoadCombo(string Table, ComboBox combo, string field, string valueField = "")
		{
			modConnection.ExecuteSql("Select * From "+Table);
			combo.Items.Clear();
			if (valueField!=String.Empty) {
				while (!modConnection.rs.EOF) {
					combo.Items.Add(Convert.ToString(modConnection.rs.Fields[field].Value));
					Support.SetItemData(combo, (combo.Items.Count-1), Convert.ToInt32(modConnection.rs.Fields[valueField].Value));
					modConnection.rs.MoveNext();
				}
			} else {
				while (!modConnection.rs.EOF) {
					combo.Items.Add(Convert.ToString(modConnection.rs.Fields[field].Value));
					modConnection.rs.MoveNext();
				}
			}
			// If strDefault <> Empty Then
			// combo = strDefault
			// End If
		}


		public static bool ComboEmpty(ComboBox combo, object strip = null, int Index = 0)
		{
			bool ComboEmpty;
			if (combo.SelectedIndex==-1) {
				ComboEmpty = true;
				MessageBox.Show("Please select an option from the list", null, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				if (Index!=0) {
					// strip.SelectedItem = strip.Tabs(Index)
				}
				combo.Focus();
			} else {
				ComboEmpty = false;
			}
			return ComboEmpty;
		}

		public static bool NoRecords(ListView lstView, string Prompt = "")
		{
			bool NoRecords;
			if (lstView.Items.Count==0 || lstView.FocusedItem==null) {
				if (Prompt!=String.Empty) {
					MessageBox.Show(Prompt, null, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				NoRecords = true;
			} else {
				NoRecords = false;
			}
			return NoRecords;
		}

#if defUse_RcrdId
		// VBto upgrade warning: 'Return' As string	OnWrite(string, int)
		public static string RcrdId_3(string Table, string FldNo = "") { return RcrdId(Table, "", FldNo); }
		public static string RcrdId(string Table, string Identifier = "", string FldNo = "")
		{
			string RcrdId;
			// VBto upgrade warning: RcrdNo As short --> As int	OnWrite(double, short)
			int RcrdNo;
			modConnection.ExecuteSql("Select * from "+Table+" order by "+FldNo+" ASC");
			if (modConnection.rs.EOF==false) {
				modConnection.rs.MoveLast();
				RcrdNo = Convert.ToInt32(VBto.ObjectToDouble(modConnection.rs.Fields[FldNo].Value)+1);
			} else {
				RcrdNo = 1;
			}
			if (Identifier!=String.Empty) {
				RcrdId = Identifier+Convert.ToString(RcrdNo)+VBto.vbFormat(DateTime.Today, "mm");
			} else {
				RcrdId = Convert.ToString(RcrdNo);
			}
			return RcrdId;
		}
#endif



		// 
		public static void SearchShow(string Table, string fieldToSearch, string itemToSearch)
		{

			frmSearch.InstancePtr.Search(Table, fieldToSearch, itemToSearch);
			frmSearch.InstancePtr.ShowDialog();

		}

#if defUse_ValBox
		public static double ValBox(string Prompt, PictureBox Icon, string Title = "", double Default = 0, string Header = "Value Box")
		{
			double ValBox = 0;
			// With frmValue
			// If Title <> Empty Then
			// .Caption = Title
			// Else
			// .Caption = App.Title
			// End If
			// .lblHeader.Caption = StrConv(Header, vbUpperCase)
			// .imgIcon.Picture = Icon.Picture
			// .lblPrompt.Caption = Prompt
			// .Default Val(Default)
			// .Show vbModal
			// ValBox = Val(.txtValue.Text)
			// Unload frmValue
			// End With
			return ValBox;
		}
#endif


		public static bool TextBoxEmpty(TextBox stext, object TabObject = null, int TabIndex = 0)
		{
			bool TextBoxEmpty;
			if (Strings.Trim(stext.Text)==String.Empty || stext.Text=="  /  /    ") {
				TextBoxEmpty = true;
				MessageBox.Show("You need to fill in all required fields", null, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				if (TabIndex!=0) {
					// TabObject.SelectedItem = TabObject.Tabs(TabIndex)
				}
				stext.Focus();
			} else {
				TextBoxEmpty = false;
			}
			return TextBoxEmpty;
		}

#if defUse_TextBoxNumberEmpty
		public static bool TextBoxNumberEmpty(TextBox textbox)
		{
			bool TextBoxNumberEmpty;
			// if the input is not a numeric then true
			if (Information.IsNumeric(textbox.Text)==false) {
				TextBoxNumberEmpty = true;
				MessageBox.Show("The field requires a numeric value.", null, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				textbox.Focus();
				SelectAll(textbox);
			} else {
				TextBoxNumberEmpty = false;
			}
			return TextBoxNumberEmpty;
		}
#endif



#if defUse_SaveDetection
		private static void SaveDetection(string Reference, string Title, string Description, string Table)
		{
			modConnection.ExecuteSql2("Select * from "+Table);
			modConnection.rs2.AddNew();
			modConnection.rs2.Fields["record_no"].Value = Conversion.Val(RcrdId_3(Table, "record_no"));
			modConnection.rs2.Fields["Reference"].Value = Reference;
			modConnection.rs2.Fields["war_type"].Value = Title;
			modConnection.rs2.Fields["Description"].Value = Description;
			modConnection.rs2.Update();
		}
#endif



#if defUse_ExecErr
		public static string ExecErr(string Prompt, string PromptFld = "", string Table = "", string RcrdFld = "", string RcrdStr = "")
		{
			string ExecErr;
			string Rcrds = "";
			if (Table!=String.Empty) {
				modConnection.ExecuteSql("Select * from "+Table+" where "+RcrdFld+" = '"+RcrdStr+"'");
				while (!modConnection.rs.EOF) {
					Rcrds += Convert.ToString(modConnection.rs.Fields[PromptFld].Value)+"; ";
					modConnection.rs.MoveNext();
				}
				ExecErr = "Error: "+Prompt+"\n"+"\n"+"Related Records: "+Rcrds;
			} else {
				ExecErr = Prompt;
			}
			return ExecErr;
		}
#endif


	}
}