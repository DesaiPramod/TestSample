using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace SKS
{
	/// <summary>
	/// Summary description for frmAddProductTo.
	/// </summary>
	public class frmAddProductTo : System.Windows.Forms.Form
	{
		public System.Windows.Forms.CheckBox chkAll;
		public System.Windows.Forms.Button cmdRemove;
		public System.Windows.Forms.StatusBar sbStatusBar;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel1;
		public System.Windows.Forms.Button cmdClose;
		public System.Windows.Forms.Button cmdSave;
		public System.Windows.Forms.GroupBox Frame1;
		public System.Windows.Forms.Button cmdProducts;
		public System.Windows.Forms.TextBox txtName;
		public System.Windows.Forms.TextBox txtCode;
		public System.Windows.Forms.ListView lvProducts;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader0;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader1;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader2;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader3;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader4;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader5;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader6;
		public System.Windows.Forms.Label Label4;
		public System.Windows.Forms.Label Label5;
		public System.Windows.Forms.ListView lvProductsBy;
		private System.Windows.Forms.ColumnHeader lvProductsByColumnHeader0;
		private System.Windows.Forms.ColumnHeader lvProductsByColumnHeader1;
		private System.Windows.Forms.ColumnHeader lvProductsByColumnHeader2;
		private System.Windows.Forms.ColumnHeader lvProductsByColumnHeader3;
		public System.Windows.Forms.Label lblProductsRelated;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmAddProductTo()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmAddProductTo InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmAddProductTo();
				return _InstancePtr;
			}
		}
		protected static frmAddProductTo _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAddProductTo));
			this.chkAll = new System.Windows.Forms.CheckBox();
			this.cmdRemove = new System.Windows.Forms.Button();
			this.sbStatusBar = new System.Windows.Forms.StatusBar();
			this.sbStatusBar_Panel1 = new System.Windows.Forms.StatusBarPanel();
			this.cmdClose = new System.Windows.Forms.Button();
			this.cmdSave = new System.Windows.Forms.Button();
			this.Frame1 = new System.Windows.Forms.GroupBox();
			this.cmdProducts = new System.Windows.Forms.Button();
			this.txtName = new System.Windows.Forms.TextBox();
			this.txtCode = new System.Windows.Forms.TextBox();
			this.lvProducts = new System.Windows.Forms.ListView();
			this.lvProductsColumnHeader0 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader5 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader6 = new System.Windows.Forms.ColumnHeader();
			this.Label4 = new System.Windows.Forms.Label();
			this.Label5 = new System.Windows.Forms.Label();
			this.lvProductsBy = new System.Windows.Forms.ListView();
			this.lvProductsByColumnHeader0 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsByColumnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsByColumnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsByColumnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.lblProductsRelated = new System.Windows.Forms.Label();
			this.SuspendLayout();
			//
			// chkAll
			//
			this.chkAll.Name = "chkAll";
			this.chkAll.TabStop = false;
			this.chkAll.TabIndex = 13;
			this.chkAll.Location = new System.Drawing.Point(113, 458);
			this.chkAll.Size = new System.Drawing.Size(82, 17);
			this.chkAll.Text = "Check All";
			this.chkAll.BackColor = System.Drawing.SystemColors.Control;
			this.chkAll.ForeColor = System.Drawing.SystemColors.ControlText;
			this.chkAll.Click += new System.EventHandler(this.chkAll_Click);
			//
			// cmdRemove
			//
			this.cmdRemove.Name = "cmdRemove";
			this.cmdRemove.TabStop = false;
			this.cmdRemove.TabIndex = 12;
			this.cmdRemove.Location = new System.Drawing.Point(8, 453);
			this.cmdRemove.Size = new System.Drawing.Size(98, 25);
			this.cmdRemove.Text = "&Remove Checked";
			this.cmdRemove.BackColor = System.Drawing.SystemColors.Control;
			this.cmdRemove.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdRemove.Click += new System.EventHandler(this.cmdRemove_Click);
			//
			// sbStatusBar
			//
			this.sbStatusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {this.sbStatusBar_Panel1});
			this.sbStatusBar.Name = "sbStatusBar";
			this.sbStatusBar.TabIndex = 11;
			this.sbStatusBar.Location = new System.Drawing.Point(0, 493);
			this.sbStatusBar.Size = new System.Drawing.Size(429, 23);
			this.sbStatusBar.ShowPanels = true;
			this.sbStatusBar.SizingGrip = false;
			//
			// Panel1
			//
			this.sbStatusBar_Panel1.Text = "";
			this.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbStatusBar_Panel1.Width = 427;
			//
			// cmdClose
			//
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.TabIndex = 7;
			this.cmdClose.Location = new System.Drawing.Point(332, 453);
			this.cmdClose.Size = new System.Drawing.Size(90, 25);
			this.cmdClose.Text = "&Close";
			this.cmdClose.BackColor = System.Drawing.SystemColors.Control;
			this.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			//
			// cmdSave
			//
			this.cmdSave.Name = "cmdSave";
			this.cmdSave.TabIndex = 6;
			this.cmdSave.Location = new System.Drawing.Point(227, 453);
			this.cmdSave.Size = new System.Drawing.Size(90, 25);
			this.cmdSave.Text = "&Save";
			this.cmdSave.BackColor = System.Drawing.SystemColors.Control;
			this.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
			//
			// Frame1
			//
			this.Frame1.Controls.Add(this.cmdProducts);
			this.Frame1.Controls.Add(this.txtName);
			this.Frame1.Controls.Add(this.txtCode);
			this.Frame1.Controls.Add(this.lvProducts);
			this.Frame1.Controls.Add(this.Label4);
			this.Frame1.Controls.Add(this.Label5);
			this.Frame1.Name = "Frame1";
			this.Frame1.TabIndex = 4;
			this.Frame1.Location = new System.Drawing.Point(8, 8);
			this.Frame1.Size = new System.Drawing.Size(414, 236);
			this.Frame1.Text = "Search product ";
			this.Frame1.BackColor = System.Drawing.SystemColors.Control;
			this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// cmdProducts
			//
			this.cmdProducts.Name = "cmdProducts";
			this.cmdProducts.TabStop = false;
			this.cmdProducts.TabIndex = 5;
			this.cmdProducts.Location = new System.Drawing.Point(364, 16);
			this.cmdProducts.Size = new System.Drawing.Size(25, 23);
			this.cmdProducts.Text = "...";
			this.cmdProducts.BackColor = System.Drawing.SystemColors.Control;
			this.cmdProducts.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdProducts.Click += new System.EventHandler(this.cmdProducts_Click);
			//
			// txtName
			//
			this.txtName.Name = "txtName";
			this.txtName.TabIndex = 1;
			this.txtName.Location = new System.Drawing.Point(113, 40);
			this.txtName.Size = new System.Drawing.Size(147, 20);
			this.txtName.Text = "";
			this.txtName.BackColor = System.Drawing.SystemColors.Window;
			this.txtName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
			//
			// txtCode
			//
			this.txtCode.Name = "txtCode";
			this.txtCode.TabIndex = 0;
			this.txtCode.Location = new System.Drawing.Point(113, 16);
			this.txtCode.Size = new System.Drawing.Size(98, 20);
			this.txtCode.Text = "";
			this.txtCode.BackColor = System.Drawing.SystemColors.Window;
			this.txtCode.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtCode.TextChanged += new System.EventHandler(this.txtCode_TextChanged);
			this.txtCode.Leave += new System.EventHandler(this.txtCode_Leave);
			//
			// lvProducts
			//
			this.lvProducts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {this.lvProductsColumnHeader0, this.lvProductsColumnHeader1, this.lvProductsColumnHeader2, this.lvProductsColumnHeader3, this.lvProductsColumnHeader4, this.lvProductsColumnHeader5, this.lvProductsColumnHeader6});
			this.lvProducts.Name = "lvProducts";
			this.lvProducts.TabIndex = 2;
			this.lvProducts.Location = new System.Drawing.Point(8, 65);
			this.lvProducts.Size = new System.Drawing.Size(397, 163);
			this.lvProducts.BackColor = System.Drawing.SystemColors.Window;
			this.lvProducts.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lvProducts.View = System.Windows.Forms.View.Details;
			this.lvProducts.MultiSelect = false;
			this.lvProducts.GridLines = true;
			this.lvProducts.FullRowSelect = true;
			this.lvProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lvProducts.HideSelection = false;
			this.lvProducts.SelectedIndexChanged += new System.EventHandler(this.lvProducts_SelectedIndexChanged);
			//
			// ColumnHeader(1)
			//
			this.lvProductsColumnHeader0.Text = "Code";
			this.lvProductsColumnHeader0.Width = 98;
			//
			// ColumnHeader(2)
			//
			this.lvProductsColumnHeader1.Text = "Name";
			this.lvProductsColumnHeader1.Width = 98;
			//
			// ColumnHeader(3)
			//
			this.lvProductsColumnHeader2.Text = "Price";
			this.lvProductsColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader2.Width = 98;
			//
			// ColumnHeader(4)
			//
			this.lvProductsColumnHeader3.Text = "Existence";
			this.lvProductsColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader3.Width = 98;
			//
			// ColumnHeader(5)
			//
			this.lvProductsColumnHeader4.Text = "Ordered";
			this.lvProductsColumnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader4.Width = 98;
			//
			// ColumnHeader(6)
			//
			this.lvProductsColumnHeader5.Text = "Quantity per Unit";
			this.lvProductsColumnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader5.Width = 98;
			//
			// ColumnHeader(7)
			//
			this.lvProductsColumnHeader6.Text = "Unit";
			this.lvProductsColumnHeader6.Width = 98;
			//
			// Label4
			//
			this.Label4.Name = "Label4";
			this.Label4.TabIndex = 9;
			this.Label4.Location = new System.Drawing.Point(16, 40);
			this.Label4.Size = new System.Drawing.Size(90, 17);
			this.Label4.Text = "Product name:";
			this.Label4.BackColor = System.Drawing.SystemColors.Control;
			this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label5
			//
			this.Label5.Name = "Label5";
			this.Label5.TabIndex = 8;
			this.Label5.Location = new System.Drawing.Point(16, 16);
			this.Label5.Size = new System.Drawing.Size(90, 17);
			this.Label5.Text = "Product code:";
			this.Label5.BackColor = System.Drawing.SystemColors.Control;
			this.Label5.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// lvProductsBy
			//
			this.lvProductsBy.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {this.lvProductsByColumnHeader0, this.lvProductsByColumnHeader1, this.lvProductsByColumnHeader2, this.lvProductsByColumnHeader3});
			this.lvProductsBy.Name = "lvProductsBy";
			this.lvProductsBy.TabIndex = 3;
			this.lvProductsBy.Location = new System.Drawing.Point(8, 275);
			this.lvProductsBy.Size = new System.Drawing.Size(414, 171);
			this.lvProductsBy.BackColor = System.Drawing.SystemColors.Window;
			this.lvProductsBy.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lvProductsBy.View = System.Windows.Forms.View.Details;
			this.lvProductsBy.MultiSelect = false;
			this.lvProductsBy.GridLines = true;
			this.lvProductsBy.FullRowSelect = true;
			this.lvProductsBy.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lvProductsBy.CheckBoxes = true;
			this.lvProductsBy.HideSelection = false;
			//
			// ColumnHeader(1)
			//
			this.lvProductsByColumnHeader0.Text = "Code";
			this.lvProductsByColumnHeader0.Width = 98;
			//
			// ColumnHeader(2)
			//
			this.lvProductsByColumnHeader1.Text = "Name";
			this.lvProductsByColumnHeader1.Width = 98;
			//
			// ColumnHeader(3)
			//
			this.lvProductsByColumnHeader2.Text = "Price";
			this.lvProductsByColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsByColumnHeader2.Width = 61;
			//
			// ColumnHeader(4)
			//
			this.lvProductsByColumnHeader3.Text = "Quantity per Unit";
			this.lvProductsByColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsByColumnHeader3.Width = 95;
			//
			// lblProductsRelated
			//
			this.lblProductsRelated.Name = "lblProductsRelated";
			this.lblProductsRelated.TabIndex = 10;
			this.lblProductsRelated.Location = new System.Drawing.Point(8, 251);
			this.lblProductsRelated.Size = new System.Drawing.Size(414, 17);
			this.lblProductsRelated.Text = "Products";
			this.lblProductsRelated.BackColor = System.Drawing.SystemColors.Control;
			this.lblProductsRelated.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// frmAddProductTo
			//
			this.ClientSize = new System.Drawing.Size(429, 517);
			this.Controls.Add(this.chkAll);
			this.Controls.Add(this.cmdRemove);
			this.Controls.Add(this.sbStatusBar);
			this.Controls.Add(this.cmdClose);
			this.Controls.Add(this.cmdSave);
			this.Controls.Add(this.Frame1);
			this.Controls.Add(this.lvProductsBy);
			this.Controls.Add(this.lblProductsRelated);
			this.Name = "frmAddProductTo";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAddProductTo_FormClosing);
			this.Text = "Create New Product Item";
			this.Frame1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================

		public int Id;
		public string ObjectReferred = "";
		public string Table = "";
		public string ColumnName = "";

		public bool SavedChanges;
		private Collection productsStored;
		private Collection productsToDelete;
		private Collection productsToAdd;
		private bool editingData;
		private string currentIdProduct = "";

		private bool codeGeneratedChange;

		private void chkAll_Click(object sender, System.EventArgs e)
		{
			bool check;
			check = chkAll.CheckState==CheckState.Checked;
			for(modMain.i=1; modMain.i<=lvProductsBy.Items.Count; modMain.i++) {
				lvProductsBy.Items[modMain.i - 1].Checked = check; lvProductsBy.Items[modMain.i - 1].Focused = true;
			} // i
		}

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void cmdProducts_Click(object sender, System.EventArgs e)
		{
			frmProducts.InstancePtr.ShowDialog();
			txtCode.Text = frmProducts.InstancePtr.CurrentProductID;
			txtName.Text = "";
			DoSearchProduct();
		}

		private void cmdRemove_Click(object sender, System.EventArgs e)
		{
			string productIdToDelete;
			for(modMain.i=lvProductsBy.Items.Count; modMain.i>=1; modMain.i--) {
				if (lvProductsBy.Items[modMain.i - 1].Checked) {
					productIdToDelete = lvProductsBy.Items[modMain.i - 1].Text;

					if (modFunctions.Exists(productsStored, productIdToDelete)) {
						if (modFunctions.Exists(productsToAdd, productIdToDelete)) {
							productsToDelete.Remove(productIdToDelete);
						} else {
							modFunctions.AddToCollection(productsToDelete, productIdToDelete);
						}
					} else {
						if (modFunctions.Exists(productsToAdd, currentIdProduct)) {
							productsToAdd.Remove(currentIdProduct);
						}
					}

					lvProductsBy.Items.RemoveAt(modMain.i - 1);
					editingData = true;
				}
			} // i
		}

		private void cmdSave_Click(object sender, System.EventArgs e)
		{

			if (productsToAdd.Count==0 && productsToDelete.Count==0) {
				editingData = true;
				MessageBox.Show("No data to be saved", "No data modified", MessageBoxButtons.OK, MessageBoxIcon.Information);
				Close();
				return;
			}
			SavedChanges = true;
			object productCode;
			foreach (object productCode_foreach in productsToAdd) {
				productCode = productCode_foreach;
				modConnection.ExecuteSql("Insert into "+Table+"("+ColumnName+", ProductID) Values ("+Convert.ToString(Id)+", '"+VBto.ObjectToString(productCode)+"')");
				productCode = null;
			}
			foreach (object productCode_foreach in productsToDelete) {
				productCode = productCode_foreach;
				modConnection.ExecuteSql("Delete from "+Table+" Where "+ColumnName+" = "+Convert.ToString(Id)+" And ProductID = '"+VBto.ObjectToString(productCode)+"'");
				productCode = null;
			}

			editingData = false;
			MessageBox.Show("Data was succesfully saved", "New data", MessageBoxButtons.OK, MessageBoxIcon.Information);
			Close();
			return;
		HandleError:
			MessageBox.Show("An error has occurred adding the data. Error: ("+Convert.ToString(Information.Err().Number)+") "+Information.Err().Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		public void cmdSave_Click()
		{
			cmdSave_Click(cmdSave, new System.EventArgs());
		}

		public void LoadData()
		{
			editingData = false;
			editingData = false;
			codeGeneratedChange = false;
			this.Text = "Add product(s) to "+ObjectReferred;
			lblProductsRelated.Text = "Products related to "+ObjectReferred;
			productsStored = new Collection();
			productsToDelete = new Collection();
			productsToAdd = new Collection();
			LoadProductsById();
		}

		// VBto upgrade warning: Cancel As short	OnWrite(bool)
		private void Form_QueryUnload(ref short Cancel, int UnloadMode)
		{
			if (editingData) {
				DialogResult res;
				res = MessageBox.Show("Do you want to save the edited data?", "Save data", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
				if (res==DialogResult.Yes) {
					cmdSave_Click();
				} else if (res!=DialogResult.No) {
					Cancel = Convert.ToInt16(true);
				}
			}
		}

		private void frmAddProductTo_FormClosing(object sender, FormClosingEventArgs e)
		{
			short Cancel = 0;
			Form_QueryUnload(ref Cancel, 0);
			if (Cancel != 0)
			{
				e.Cancel = true;
				return;
			}
		}

		private void lvProducts_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ListViewItem Item = ((ListView)sender).FocusedItem;
			if (Item==null) return;

			AddProductToSet();
		}

		private void txtCode_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchProduct();
		}

		// Private Sub txtCode_KeyPress(KeyAscii As Integer)
		// KeyAscii = UpCase(KeyAscii)
		// End Sub

		private void txtCode_Leave(object sender, System.EventArgs e)
		{
			if (lvProducts.Items.Count==1) {
				AddProductToSet();
			}
		}

		private void txtName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchProduct();
		}

		private void LoadProductsById()
		{
			string productCode;
			modConnection.ExecuteSql("Select p.ProductID, p.ProductName, p.UnitPrice, p.QuantityPerUnit, p.Unit from Products as p, "+Table+" as pb Where pb."+ColumnName+" = "+Convert.ToString(Id)+" And pb.ProductId = p.ProductId");

			modMain.LogStatus("There are "+Convert.ToString(modConnection.rs.RecordCount)+" records with the selected criteria", this);
			if (modConnection.rs.RecordCount>0) {
				ListViewItem x;
				while (!modConnection.rs.EOF) {
					// productCode = CStr(rs.Fields(0).value)
					productCode = Convert.ToString(modConnection.rs.Fields[0].Value);
					modFunctions.AddToCollection(productsStored, productCode);
					x = lvProductsBy.Items.Add(productCode);
					for(modMain.i=1; modMain.i<=2; modMain.i++) {
						if (!VBto.IsEmpty(modConnection.rs.Fields[modMain.i].Value)) {
							VBto.SubItemsSetText(x, modMain.i, Convert.ToString(modConnection.rs.Fields[modMain.i].Value));
						}
					} // i
					VBto.SubItemsSetText(x, 3, Convert.ToString(modConnection.rs.Fields[3].Value)+Convert.ToString(modConnection.rs.Fields[4].Value));
					modConnection.rs.MoveNext();
				}
			}
		}

		private void DoSearchProduct()
		{
			string filter;
			filter = "";
			if (txtCode.Text!=String.Empty) {
				filter = "ProductId LIKE '%"+txtCode.Text+"%'";
			}
			if (txtName.Text!=String.Empty) {
				if (filter!=String.Empty) {
					filter += " AND ";
				}
				filter += "ProductName LIKE '%"+txtName.Text+"%'";
			}
			if (filter!=String.Empty) {
				filter = "Where "+filter;
			}
			modConnection.ExecuteSql("Select ProductID, ProductName, UnitPrice, UnitsInStock, UnitsOnOrder, QuantityPerUnit, Unit from Products "+filter);
			lvProducts.Items.Clear();
			modMain.LogStatus("There are "+Convert.ToString(modConnection.rs.RecordCount)+" records with the selected criteria", this);
			if (modConnection.rs.RecordCount>0) {
				ListViewItem x;
				while (!modConnection.rs.EOF) {
					x = lvProducts.Items.Add(Convert.ToString(modConnection.rs.Fields[0].Value));
					for(modMain.i=1; modMain.i<=(modConnection.rs.ColumnCount-1); modMain.i++) {
						if (!VBto.IsEmpty(modConnection.rs.Fields[modMain.i].Value)) {
							VBto.SubItemsSetText(x, modMain.i, Convert.ToString(modConnection.rs.Fields[modMain.i].Value));
						}
					} // i
					modConnection.rs.MoveNext();
				}
				if (lvProducts.Items.Count==1) {
					lvProducts.FocusedItem = lvProducts.Items[1 - 1]; lvProducts.FocusedItem.Selected = true;
				}
			}
		}

		private void AddProductToSet()
		{

			if (lvProducts.FocusedItem.Text!=String.Empty) {
				ListViewItem y;
				y = lvProducts.FocusedItem;
				currentIdProduct = lvProducts.FocusedItem.Text;
				int i;
				bool found;
				found = false;
				for(i=1; i<=lvProductsBy.Items.Count; i++) {
					if (lvProductsBy.Items[i - 1].Text==currentIdProduct) {
						lvProductsBy.FocusedItem = lvProductsBy.Items[i - 1]; lvProductsBy.FocusedItem.Selected = true;
						found = true;
						break;
					} else if (VBto.stringCompare(lvProductsBy.Items[i - 1].Text, ">", currentIdProduct)) {
						break;
					}
				} // i
				if (!found) {
					editingData = true;
					if (!modFunctions.Exists(productsStored, currentIdProduct)) {
						if (modFunctions.Exists(productsToDelete, currentIdProduct)) {
							productsToDelete.Remove(currentIdProduct);
						} else {
							modFunctions.AddToCollection(productsToAdd, currentIdProduct);
						}
					} else {
						if (modFunctions.Exists(productsToDelete, currentIdProduct)) {
							productsToDelete.Remove(currentIdProduct);
						}
					}
					ListViewItem x;
					x = lvProductsBy.Items.Insert(i - 1, currentIdProduct);
					VBto.SubItemsSetText(x, 1, y.SubItems[1].Text);
					VBto.SubItemsSetText(x, 2, y.SubItems[2].Text);
					VBto.SubItemsSetText(x, 3, y.SubItems[5].Text+y.SubItems[6].Text);
				}
			}
		}

#if defUse_ClearFields
		private void ClearFields()
		{
			codeGeneratedChange = true;
			txtCode.Text = "";
			txtName.Text = "";
			lvProducts.Items.Clear();
			lvProductsBy.Items.Clear();
			txtCode.Focus();
			editingData = false;
			codeGeneratedChange = false;
		}
#endif

	}
}