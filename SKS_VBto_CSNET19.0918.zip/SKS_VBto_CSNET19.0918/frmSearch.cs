using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace SKS
{
	/// <summary>
	/// Summary description for frmSearch.
	/// </summary>
	public class frmSearch : System.Windows.Forms.Form
	{
		public System.Windows.Forms.Button cmdClose;
		public System.Windows.Forms.Button cmdSearch;
		public System.Windows.Forms.PictureBox ctrlLiner1;
		public System.Windows.Forms.ComboBox cboSrchBy;
		public System.Windows.Forms.TextBox txtSrchStr;
		public System.Windows.Forms.PictureBox Image3;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.Label lblSrchBy;
		public System.Windows.Forms.Label Label20;
		public System.Windows.Forms.Label Label19;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmSearch()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmSearch InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmSearch();
				return _InstancePtr;
			}
		}
		protected static frmSearch _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSearch));
			this.cmdClose = new System.Windows.Forms.Button();
			this.cmdSearch = new System.Windows.Forms.Button();
			this.ctrlLiner1 = new System.Windows.Forms.PictureBox();
			this.cboSrchBy = new System.Windows.Forms.ComboBox();
			this.txtSrchStr = new System.Windows.Forms.TextBox();
			this.Image3 = new System.Windows.Forms.PictureBox();
			this.Label1 = new System.Windows.Forms.Label();
			this.lblSrchBy = new System.Windows.Forms.Label();
			this.Label20 = new System.Windows.Forms.Label();
			this.Label19 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			//
			// cmdClose
			//
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.TabIndex = 8;
			this.cmdClose.Location = new System.Drawing.Point(275, 105);
			this.cmdClose.Size = new System.Drawing.Size(82, 25);
			this.cmdClose.Text = "&Close";
			this.cmdClose.BackColor = System.Drawing.SystemColors.Control;
			this.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			//
			// cmdSearch
			//
			this.cmdSearch.Name = "cmdSearch";
			this.cmdSearch.TabIndex = 7;
			this.cmdSearch.Location = new System.Drawing.Point(186, 105);
			this.cmdSearch.Size = new System.Drawing.Size(82, 25);
			this.cmdSearch.Text = "&Search";
			this.cmdSearch.BackColor = System.Drawing.SystemColors.Control;
			this.cmdSearch.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdSearch.Click += new System.EventHandler(this.cmdSearch_Click);
			//
			// ctrlLiner1
			//
			this.ctrlLiner1.Name = "ctrlLiner1";
			this.ctrlLiner1.TabIndex = 6;
			this.ctrlLiner1.Location = new System.Drawing.Point(0, 57);
			this.ctrlLiner1.Size = new System.Drawing.Size(389, 2);
			this.ctrlLiner1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.ctrlLiner1.BackColor = System.Drawing.SystemColors.Control;
			//
			// cboSrchBy
			//
			this.cboSrchBy.Name = "cboSrchBy";
			this.cboSrchBy.TabIndex = 3;
			this.cboSrchBy.Location = new System.Drawing.Point(210, 146);
			this.cboSrchBy.Size = new System.Drawing.Size(147, 21);
			this.cboSrchBy.Text = "";
			this.cboSrchBy.BackColor = System.Drawing.SystemColors.Window;
			this.cboSrchBy.ForeColor = System.Drawing.SystemColors.WindowText;
			this.cboSrchBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboSrchBy.SelectedIndexChanged += new System.EventHandler(this.cboSrchBy_SelectedIndexChanged);
			//
			// txtSrchStr
			//
			this.txtSrchStr.Name = "txtSrchStr";
			this.txtSrchStr.TabIndex = 0;
			this.txtSrchStr.Location = new System.Drawing.Point(138, 73);
			this.txtSrchStr.Size = new System.Drawing.Size(219, 19);
			this.txtSrchStr.Text = "";
			this.txtSrchStr.BackColor = System.Drawing.SystemColors.Window;
			this.txtSrchStr.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// Image3
			//
			this.Image3.Name = "Image3";
			this.Image3.Location = new System.Drawing.Point(8, 8);
			this.Image3.Size = new System.Drawing.Size(16, 16);
			this.Image3.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.Image3.BackColor = System.Drawing.SystemColors.Control;
			this.Image3.Image = ((System.Drawing.Image)(resources.GetObject("Image3.Image")));
			//
			// Label1
			//
			this.Label1.Name = "Label1";
			this.Label1.TabIndex = 2;
			this.Label1.AutoSize = true;
			this.Label1.Location = new System.Drawing.Point(126, 146);
			this.Label1.Size = new System.Drawing.Size(63, 13);
			this.Label1.Text = "Search by:";
			this.Label1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.Label1.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// lblSrchBy
			//
			this.lblSrchBy.Name = "lblSrchBy";
			this.lblSrchBy.TabIndex = 1;
			this.lblSrchBy.AutoSize = true;
			this.lblSrchBy.Location = new System.Drawing.Point(7, 73);
			this.lblSrchBy.Size = new System.Drawing.Size(117, 13);
			this.lblSrchBy.Text = "Field";
			this.lblSrchBy.BackColor = System.Drawing.SystemColors.Control;
			this.lblSrchBy.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.lblSrchBy.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.lblSrchBy.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// Label20
			//
			this.Label20.Name = "Label20";
			this.Label20.TabIndex = 5;
			this.Label20.AutoSize = true;
			this.Label20.Location = new System.Drawing.Point(50, 32);
			this.Label20.Size = new System.Drawing.Size(120, 13);
			this.Label20.Text = "Search for a specific item";
			this.Label20.BackColor = System.Drawing.Color.Transparent;
			this.Label20.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			//
			// Label19
			//
			this.Label19.Name = "Label19";
			this.Label19.TabIndex = 4;
			this.Label19.AutoSize = true;
			this.Label19.Location = new System.Drawing.Point(50, 8);
			this.Label19.Size = new System.Drawing.Size(51, 16);
			this.Label19.Text = "Search";
			this.Label19.BackColor = System.Drawing.Color.Transparent;
			this.Label19.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.Label19.Font = new System.Drawing.Font("MS Sans Serif", 9.75F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// frmSearch
			//
			this.ClientSize = new System.Drawing.Size(382, 175);
			this.Controls.Add(this.cmdClose);
			this.Controls.Add(this.cmdSearch);
			this.Controls.Add(this.ctrlLiner1);
			this.Controls.Add(this.cboSrchBy);
			this.Controls.Add(this.txtSrchStr);
			this.Controls.Add(this.Image3);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.lblSrchBy);
			this.Controls.Add(this.Label20);
			this.Controls.Add(this.Label19);
			this.Name = "frmSearch";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.ShowInTaskbar = false;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("frmSearch.Icon")));
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Search";
			this.Label1.ResumeLayout(false);
			this.lblSrchBy.ResumeLayout(false);
			this.Label19.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================
		string SearchTable = "";
		private void cboSrchBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			lblSrchBy.Text = cboSrchBy.Text;
		}

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}


		public void Search(string Table, string fieldToSearch, string itemToSearch)
		{
			if (itemToSearch!=String.Empty) {
				Label20.Text = "Search for a "+itemToSearch;
			}
			SearchTable = Table;
			modConnection.ExecuteSql("Select Top 1 * from "+Table);
			for(modMain.i=0; modMain.i<=(modConnection.rs.ColumnCount-1); modMain.i++) {
				cboSrchBy.Items.Add(modConnection.rs.Fields[modMain.i].Name);
			} // i
			cboSrchBy.Text = fieldToSearch;
		}

		private void cmdSearch_Click(object sender, System.EventArgs e)
		{
			if (Strings.Right(txtSrchStr.Text, 1)=="'") {
				txtSrchStr.Text = String.Empty;
			}
			string txtToSearch;

			if (Strings.Trim(txtSrchStr.Text)!=String.Empty) {
				txtToSearch = txtSrchStr.Text;
			} else {
				txtToSearch = "%";
			}
			if (SearchTable=="Customers") {
				SearchCriteriaCustomers(lblSrchBy.Text, txtToSearch);
			} else if (SearchTable=="Products") {
				SearchCriteriaProducts(lblSrchBy.Text, txtToSearch);
			} else if (SearchTable=="Providers") {
				SearchCriteriaProviders(lblSrchBy.Text, txtToSearch);
			}
		}

		// 
		public void SearchCriteriaCustomers(string field, string mvalue)
		{
			modConnection.ExecuteSql("Select * from Customers where "+field+" LIKE '"+mvalue+"%'");
			if (modConnection.rs.RecordCount==0) {
				MessageBox.Show("There are no records with the selected criteria", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
			} else {
				modMain.LogStatus("There are "+Convert.ToString(modConnection.rs.RecordCount)+" that meet with the selected criteria");
				frmCustomers.InstancePtr.dcCustomers.Recordset = (ADODB.Recordset)modConnection.rs;
			}
		}

		public void SearchCriteriaProducts(string field, string mvalue)
		{
			modConnection.ExecuteSql("Select * from Products where "+field+" LIKE '"+mvalue+"%'");
			if (modConnection.rs.RecordCount==0) {
				MessageBox.Show("There are no records with the selected criteria", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
			} else {
				frmProducts.InstancePtr.dcProducts.Recordset =(ADODB.Recordset) modConnection.rs;
			}
		}

		public void SearchCriteriaProviders(string field, string mvalue)
		{
			modConnection.ExecuteSql("Select * from Providers where "+field+" LIKE '"+mvalue+"%'");
			if (modConnection.rs.RecordCount==0) {
				MessageBox.Show("There are no records with the selected criteria", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
			} else {
				modMain.LogStatus("There are "+Convert.ToString(modConnection.rs.RecordCount)+" that meet with the selected criteria");
				frmProviders.InstancePtr.dcProviders.Recordset = (ADODB.Recordset)modConnection.rs;
			}
		}

	}
}