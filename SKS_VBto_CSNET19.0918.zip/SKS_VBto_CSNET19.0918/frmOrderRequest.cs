using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace SKS
{
	/// <summary>
	/// Summary description for frmOrderRequest.
	/// </summary>
	public class frmOrderRequest : System.Windows.Forms.Form
	{
		public System.Windows.Forms.TextBox txtSubTotal;
		public System.Windows.Forms.TextBox txtTotal;
		public System.Windows.Forms.TextBox txtTotalTax;
		public System.Windows.Forms.TextBox txtFreightCharge;
		public System.Windows.Forms.TextBox txtSalesTax;
		public System.Windows.Forms.TextBox txtEntry;
		public AxMSFlexGridLib.AxMSFlexGrid fgProducts;
		public System.Windows.Forms.StatusBar sbStatusBar;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel1;
		public System.Windows.Forms.DateTimePicker dtRequired;
		public System.Windows.Forms.Button cmdSave;
		public System.Windows.Forms.Button cmdAddProducts;
		public System.Windows.Forms.Button cmdClose;
		public System.Windows.Forms.GroupBox Frame1;
		public System.Windows.Forms.TextBox txtContactLastName;
		public System.Windows.Forms.TextBox txtContactName;
		public System.Windows.Forms.Button cmdCustomers;
		public System.Windows.Forms.TextBox txtCompanyName;
		public System.Windows.Forms.ListView lvCustomers;
		private System.Windows.Forms.ColumnHeader lvCustomersColumnHeader0;
		private System.Windows.Forms.ColumnHeader lvCustomersColumnHeader1;
		private System.Windows.Forms.ColumnHeader lvCustomersColumnHeader2;
		private System.Windows.Forms.ColumnHeader lvCustomersColumnHeader3;
		private System.Windows.Forms.ColumnHeader lvCustomersColumnHeader4;
		private System.Windows.Forms.ColumnHeader lvCustomersColumnHeader5;
		private System.Windows.Forms.ColumnHeader lvCustomersColumnHeader6;
		public System.Windows.Forms.Label Label3;
		public System.Windows.Forms.Label Label4;
		public System.Windows.Forms.Label Label2;
		public System.Windows.Forms.GroupBox Frame2;
		public System.Windows.Forms.TextBox txtCustomerContact;
		public System.Windows.Forms.TextBox txtCustomerCompany;
		public System.Windows.Forms.Label Label5;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.DateTimePicker dtPromised;
		public System.Windows.Forms.Label Label13;
		public System.Windows.Forms.Label Label12;
		public System.Windows.Forms.Label Label11;
		public System.Windows.Forms.Label Label10;
		public System.Windows.Forms.Label Label9;
		public System.Windows.Forms.Label Label8;
		public System.Windows.Forms.Label Label7;
		public System.Windows.Forms.Label Label6;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmOrderRequest()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmOrderRequest InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmOrderRequest();
				return _InstancePtr;
			}
		}
		protected static frmOrderRequest _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOrderRequest));
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtTotalTax = new System.Windows.Forms.TextBox();
            this.txtFreightCharge = new System.Windows.Forms.TextBox();
            this.txtSalesTax = new System.Windows.Forms.TextBox();
            this.txtEntry = new System.Windows.Forms.TextBox();
            this.fgProducts = new AxMSFlexGridLib.AxMSFlexGrid();
            this.sbStatusBar = new System.Windows.Forms.StatusBar();
            this.sbStatusBar_Panel1 = new System.Windows.Forms.StatusBarPanel();
            this.dtRequired = new System.Windows.Forms.DateTimePicker();
            this.cmdSave = new System.Windows.Forms.Button();
            this.cmdAddProducts = new System.Windows.Forms.Button();
            this.cmdClose = new System.Windows.Forms.Button();
            this.Frame1 = new System.Windows.Forms.GroupBox();
            this.txtContactLastName = new System.Windows.Forms.TextBox();
            this.txtContactName = new System.Windows.Forms.TextBox();
            this.cmdCustomers = new System.Windows.Forms.Button();
            this.txtCompanyName = new System.Windows.Forms.TextBox();
            this.lvCustomers = new System.Windows.Forms.ListView();
            this.lvCustomersColumnHeader0 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvCustomersColumnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvCustomersColumnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvCustomersColumnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvCustomersColumnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvCustomersColumnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvCustomersColumnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Label3 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Frame2 = new System.Windows.Forms.GroupBox();
            this.txtCustomerContact = new System.Windows.Forms.TextBox();
            this.txtCustomerCompany = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.dtPromised = new System.Windows.Forms.DateTimePicker();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fgProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbStatusBar_Panel1)).BeginInit();
            this.Frame1.SuspendLayout();
            this.Frame2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.BackColor = System.Drawing.SystemColors.Menu;
            this.txtSubTotal.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtSubTotal.Location = new System.Drawing.Point(356, 623);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.ReadOnly = true;
            this.txtSubTotal.Size = new System.Drawing.Size(147, 20);
            this.txtSubTotal.TabIndex = 31;
            this.txtSubTotal.TabStop = false;
            this.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.SystemColors.Menu;
            this.txtTotal.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtTotal.Location = new System.Drawing.Point(97, 623);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(147, 20);
            this.txtTotal.TabIndex = 29;
            this.txtTotal.TabStop = false;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotalTax
            // 
            this.txtTotalTax.BackColor = System.Drawing.SystemColors.Menu;
            this.txtTotalTax.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtTotalTax.Location = new System.Drawing.Point(356, 599);
            this.txtTotalTax.Name = "txtTotalTax";
            this.txtTotalTax.ReadOnly = true;
            this.txtTotalTax.Size = new System.Drawing.Size(147, 20);
            this.txtTotalTax.TabIndex = 27;
            this.txtTotalTax.TabStop = false;
            this.txtTotalTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtFreightCharge
            // 
            this.txtFreightCharge.BackColor = System.Drawing.SystemColors.Window;
            this.txtFreightCharge.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtFreightCharge.Location = new System.Drawing.Point(97, 599);
            this.txtFreightCharge.Name = "txtFreightCharge";
            this.txtFreightCharge.Size = new System.Drawing.Size(147, 20);
            this.txtFreightCharge.TabIndex = 8;
            this.txtFreightCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFreightCharge.TextChanged += new System.EventHandler(this.txtFreightCharge_TextChanged);
            this.txtFreightCharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFreightCharge_KeyPress);
            // 
            // txtSalesTax
            // 
            this.txtSalesTax.BackColor = System.Drawing.SystemColors.Window;
            this.txtSalesTax.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtSalesTax.Location = new System.Drawing.Point(97, 574);
            this.txtSalesTax.Name = "txtSalesTax";
            this.txtSalesTax.Size = new System.Drawing.Size(147, 20);
            this.txtSalesTax.TabIndex = 7;
            this.txtSalesTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSalesTax.TextChanged += new System.EventHandler(this.txtSalesTax_TextChanged);
            this.txtSalesTax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSalesTax_KeyPress);
            // 
            // txtEntry
            // 
            this.txtEntry.BackColor = System.Drawing.SystemColors.Window;
            this.txtEntry.Enabled = false;
            this.txtEntry.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtEntry.Location = new System.Drawing.Point(97, 550);
            this.txtEntry.Name = "txtEntry";
            this.txtEntry.Size = new System.Drawing.Size(147, 20);
            this.txtEntry.TabIndex = 24;
            this.txtEntry.Leave += new System.EventHandler(this.txtEntry_Leave);
            // 
            // fgProducts
            // 
            this.fgProducts.Location = new System.Drawing.Point(8, 364);
            this.fgProducts.Name = "fgProducts";
            this.fgProducts.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("fgProducts.OcxState")));
            this.fgProducts.Size = new System.Drawing.Size(511, 179);
            this.fgProducts.TabIndex = 6;
            this.fgProducts.ClickEvent += new System.EventHandler(this.fgProducts_ClickEvent);
            this.fgProducts.KeyPressEvent += new AxMSFlexGridLib.DMSFlexGridEvents_KeyPressEventHandler(this.fgProducts_KeyPressEvent);
            this.fgProducts.EnterCell += new System.EventHandler(this.fgProducts_EnterCell);
            this.fgProducts.LeaveCell += new System.EventHandler(this.fgProducts_LeaveCell);
            // 
            // sbStatusBar
            // 
            this.sbStatusBar.Location = new System.Drawing.Point(0, 686);
            this.sbStatusBar.Name = "sbStatusBar";
            this.sbStatusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.sbStatusBar_Panel1});
            this.sbStatusBar.ShowPanels = true;
            this.sbStatusBar.Size = new System.Drawing.Size(529, 25);
            this.sbStatusBar.SizingGrip = false;
            this.sbStatusBar.TabIndex = 23;
            // 
            // sbStatusBar_Panel1
            // 
            this.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
            this.sbStatusBar_Panel1.Name = "sbStatusBar_Panel1";
            this.sbStatusBar_Panel1.Width = 529;
            // 
            // dtRequired
            // 
            this.dtRequired.Location = new System.Drawing.Point(121, 324);
            this.dtRequired.Name = "dtRequired";
            this.dtRequired.Size = new System.Drawing.Size(98, 20);
            this.dtRequired.TabIndex = 4;
            this.dtRequired.ValueChanged += new System.EventHandler(this.dtRequired_ValueChanged);
            // 
            // cmdSave
            // 
            this.cmdSave.BackColor = System.Drawing.SystemColors.Control;
            this.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmdSave.Location = new System.Drawing.Point(324, 655);
            this.cmdSave.Name = "cmdSave";
            this.cmdSave.Size = new System.Drawing.Size(90, 25);
            this.cmdSave.TabIndex = 9;
            this.cmdSave.Text = "&Save";
            this.cmdSave.UseVisualStyleBackColor = false;
            this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
            // 
            // cmdAddProducts
            // 
            this.cmdAddProducts.BackColor = System.Drawing.SystemColors.Control;
            this.cmdAddProducts.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmdAddProducts.Location = new System.Drawing.Point(493, 340);
            this.cmdAddProducts.Name = "cmdAddProducts";
            this.cmdAddProducts.Size = new System.Drawing.Size(25, 23);
            this.cmdAddProducts.TabIndex = 21;
            this.cmdAddProducts.TabStop = false;
            this.cmdAddProducts.Text = "...";
            this.cmdAddProducts.UseVisualStyleBackColor = false;
            this.cmdAddProducts.Click += new System.EventHandler(this.cmdAddProducts_Click);
            // 
            // cmdClose
            // 
            this.cmdClose.BackColor = System.Drawing.SystemColors.Control;
            this.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmdClose.Location = new System.Drawing.Point(421, 655);
            this.cmdClose.Name = "cmdClose";
            this.cmdClose.Size = new System.Drawing.Size(90, 25);
            this.cmdClose.TabIndex = 10;
            this.cmdClose.Text = "&Close";
            this.cmdClose.UseVisualStyleBackColor = false;
            this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
            // 
            // Frame1
            // 
            this.Frame1.BackColor = System.Drawing.SystemColors.Control;
            this.Frame1.Controls.Add(this.txtContactLastName);
            this.Frame1.Controls.Add(this.txtContactName);
            this.Frame1.Controls.Add(this.cmdCustomers);
            this.Frame1.Controls.Add(this.txtCompanyName);
            this.Frame1.Controls.Add(this.lvCustomers);
            this.Frame1.Controls.Add(this.Label3);
            this.Frame1.Controls.Add(this.Label4);
            this.Frame1.Controls.Add(this.Label2);
            this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Frame1.Location = new System.Drawing.Point(8, 8);
            this.Frame1.Name = "Frame1";
            this.Frame1.Size = new System.Drawing.Size(511, 252);
            this.Frame1.TabIndex = 12;
            this.Frame1.TabStop = false;
            this.Frame1.Text = "Search customer";
            // 
            // txtContactLastName
            // 
            this.txtContactLastName.BackColor = System.Drawing.SystemColors.Window;
            this.txtContactLastName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtContactLastName.Location = new System.Drawing.Point(340, 49);
            this.txtContactLastName.Name = "txtContactLastName";
            this.txtContactLastName.Size = new System.Drawing.Size(147, 20);
            this.txtContactLastName.TabIndex = 2;
            this.txtContactLastName.TextChanged += new System.EventHandler(this.txtContactLastName_TextChanged);
            // 
            // txtContactName
            // 
            this.txtContactName.BackColor = System.Drawing.SystemColors.Window;
            this.txtContactName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtContactName.Location = new System.Drawing.Point(89, 49);
            this.txtContactName.Name = "txtContactName";
            this.txtContactName.Size = new System.Drawing.Size(147, 20);
            this.txtContactName.TabIndex = 1;
            this.txtContactName.TextChanged += new System.EventHandler(this.txtContactName_TextChanged);
            // 
            // cmdCustomers
            // 
            this.cmdCustomers.BackColor = System.Drawing.SystemColors.Control;
            this.cmdCustomers.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmdCustomers.Location = new System.Drawing.Point(461, 16);
            this.cmdCustomers.Name = "cmdCustomers";
            this.cmdCustomers.Size = new System.Drawing.Size(25, 23);
            this.cmdCustomers.TabIndex = 13;
            this.cmdCustomers.TabStop = false;
            this.cmdCustomers.Text = "...";
            this.cmdCustomers.UseVisualStyleBackColor = false;
            this.cmdCustomers.Click += new System.EventHandler(this.cmdCustomers_Click);
            // 
            // txtCompanyName
            // 
            this.txtCompanyName.BackColor = System.Drawing.SystemColors.Window;
            this.txtCompanyName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtCompanyName.Location = new System.Drawing.Point(89, 16);
            this.txtCompanyName.Name = "txtCompanyName";
            this.txtCompanyName.Size = new System.Drawing.Size(147, 20);
            this.txtCompanyName.TabIndex = 0;
            this.txtCompanyName.TextChanged += new System.EventHandler(this.txtCompanyName_TextChanged);
            // 
            // lvCustomers
            // 
            this.lvCustomers.BackColor = System.Drawing.SystemColors.Window;
            this.lvCustomers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lvCustomersColumnHeader0,
            this.lvCustomersColumnHeader1,
            this.lvCustomersColumnHeader2,
            this.lvCustomersColumnHeader3,
            this.lvCustomersColumnHeader4,
            this.lvCustomersColumnHeader5,
            this.lvCustomersColumnHeader6});
            this.lvCustomers.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lvCustomers.FullRowSelect = true;
            this.lvCustomers.GridLines = true;
            this.lvCustomers.HideSelection = false;
            this.lvCustomers.Location = new System.Drawing.Point(8, 81);
            this.lvCustomers.MultiSelect = false;
            this.lvCustomers.Name = "lvCustomers";
            this.lvCustomers.Size = new System.Drawing.Size(494, 163);
            this.lvCustomers.TabIndex = 3;
            this.lvCustomers.UseCompatibleStateImageBehavior = false;
            this.lvCustomers.View = System.Windows.Forms.View.Details;
            this.lvCustomers.SelectedIndexChanged += new System.EventHandler(this.lvCustomers_SelectedIndexChanged);
            // 
            // lvCustomersColumnHeader0
            // 
            this.lvCustomersColumnHeader0.Text = "Customer ID";
            this.lvCustomersColumnHeader0.Width = 98;
            // 
            // lvCustomersColumnHeader1
            // 
            this.lvCustomersColumnHeader1.Text = "Company Name";
            this.lvCustomersColumnHeader1.Width = 98;
            // 
            // lvCustomersColumnHeader2
            // 
            this.lvCustomersColumnHeader2.Text = "Contact Name";
            this.lvCustomersColumnHeader2.Width = 98;
            // 
            // lvCustomersColumnHeader3
            // 
            this.lvCustomersColumnHeader3.Text = "Contact Last Name";
            this.lvCustomersColumnHeader3.Width = 98;
            // 
            // lvCustomersColumnHeader4
            // 
            this.lvCustomersColumnHeader4.Text = "City";
            this.lvCustomersColumnHeader4.Width = 98;
            // 
            // lvCustomersColumnHeader5
            // 
            this.lvCustomersColumnHeader5.Text = "State";
            this.lvCustomersColumnHeader5.Width = 98;
            // 
            // lvCustomersColumnHeader6
            // 
            this.lvCustomersColumnHeader6.Text = "Country";
            this.lvCustomersColumnHeader6.Width = 98;
            // 
            // Label3
            // 
            this.Label3.BackColor = System.Drawing.SystemColors.Control;
            this.Label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label3.Location = new System.Drawing.Point(243, 49);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(98, 17);
            this.Label3.TabIndex = 16;
            this.Label3.Text = "Contact last name:";
            // 
            // Label4
            // 
            this.Label4.BackColor = System.Drawing.SystemColors.Control;
            this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label4.Location = new System.Drawing.Point(8, 16);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(90, 17);
            this.Label4.TabIndex = 15;
            this.Label4.Text = "Company name:";
            // 
            // Label2
            // 
            this.Label2.BackColor = System.Drawing.SystemColors.Control;
            this.Label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label2.Location = new System.Drawing.Point(8, 49);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(90, 17);
            this.Label2.TabIndex = 14;
            this.Label2.Text = "Contact name:";
            // 
            // Frame2
            // 
            this.Frame2.BackColor = System.Drawing.SystemColors.Control;
            this.Frame2.Controls.Add(this.txtCustomerContact);
            this.Frame2.Controls.Add(this.txtCustomerCompany);
            this.Frame2.Controls.Add(this.Label5);
            this.Frame2.Controls.Add(this.Label1);
            this.Frame2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Frame2.Location = new System.Drawing.Point(8, 259);
            this.Frame2.Name = "Frame2";
            this.Frame2.Size = new System.Drawing.Size(511, 50);
            this.Frame2.TabIndex = 11;
            this.Frame2.TabStop = false;
            this.Frame2.Text = "Customer";
            // 
            // txtCustomerContact
            // 
            this.txtCustomerContact.BackColor = System.Drawing.SystemColors.Menu;
            this.txtCustomerContact.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtCustomerContact.Location = new System.Drawing.Point(291, 16);
            this.txtCustomerContact.Name = "txtCustomerContact";
            this.txtCustomerContact.ReadOnly = true;
            this.txtCustomerContact.Size = new System.Drawing.Size(211, 20);
            this.txtCustomerContact.TabIndex = 20;
            this.txtCustomerContact.TabStop = false;
            // 
            // txtCustomerCompany
            // 
            this.txtCustomerCompany.BackColor = System.Drawing.SystemColors.Menu;
            this.txtCustomerCompany.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtCustomerCompany.Location = new System.Drawing.Point(73, 16);
            this.txtCustomerCompany.Name = "txtCustomerCompany";
            this.txtCustomerCompany.ReadOnly = true;
            this.txtCustomerCompany.Size = new System.Drawing.Size(147, 20);
            this.txtCustomerCompany.TabIndex = 19;
            this.txtCustomerCompany.TabStop = false;
            // 
            // Label5
            // 
            this.Label5.BackColor = System.Drawing.SystemColors.Control;
            this.Label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label5.Location = new System.Drawing.Point(8, 16);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(58, 17);
            this.Label5.TabIndex = 18;
            this.Label5.Text = "Company:";
            // 
            // Label1
            // 
            this.Label1.BackColor = System.Drawing.SystemColors.Control;
            this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label1.Location = new System.Drawing.Point(235, 16);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(58, 17);
            this.Label1.TabIndex = 17;
            this.Label1.Text = "Contact:";
            // 
            // dtPromised
            // 
            this.dtPromised.Location = new System.Drawing.Point(356, 324);
            this.dtPromised.Name = "dtPromised";
            this.dtPromised.Size = new System.Drawing.Size(98, 20);
            this.dtPromised.TabIndex = 5;
            this.dtPromised.ValueChanged += new System.EventHandler(this.dtPromised_ValueChanged);
            // 
            // Label13
            // 
            this.Label13.BackColor = System.Drawing.SystemColors.Control;
            this.Label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label13.Location = new System.Drawing.Point(8, 550);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(90, 17);
            this.Label13.TabIndex = 33;
            this.Label13.Text = "Line quantity:";
            // 
            // Label12
            // 
            this.Label12.BackColor = System.Drawing.SystemColors.Control;
            this.Label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label12.Location = new System.Drawing.Point(8, 599);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(90, 17);
            this.Label12.TabIndex = 32;
            this.Label12.Text = "Freight Charge:";
            // 
            // Label11
            // 
            this.Label11.BackColor = System.Drawing.SystemColors.Control;
            this.Label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label11.Location = new System.Drawing.Point(8, 623);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(90, 17);
            this.Label11.TabIndex = 30;
            this.Label11.Text = "Total:";
            // 
            // Label10
            // 
            this.Label10.BackColor = System.Drawing.SystemColors.Control;
            this.Label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label10.Location = new System.Drawing.Point(275, 599);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(90, 17);
            this.Label10.TabIndex = 28;
            this.Label10.Text = "Total Tax:";
            // 
            // Label9
            // 
            this.Label9.BackColor = System.Drawing.SystemColors.Control;
            this.Label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label9.Location = new System.Drawing.Point(275, 623);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(90, 17);
            this.Label9.TabIndex = 26;
            this.Label9.Text = "Sub Total:";
            // 
            // Label8
            // 
            this.Label8.BackColor = System.Drawing.SystemColors.Control;
            this.Label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label8.Location = new System.Drawing.Point(8, 574);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(90, 17);
            this.Label8.TabIndex = 25;
            this.Label8.Text = "Sales Tax:";
            // 
            // Label7
            // 
            this.Label7.BackColor = System.Drawing.SystemColors.Control;
            this.Label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label7.Location = new System.Drawing.Point(259, 324);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(106, 17);
            this.Label7.TabIndex = 22;
            this.Label7.Text = "Promised by date:";
            // 
            // Label6
            // 
            this.Label6.BackColor = System.Drawing.SystemColors.Control;
            this.Label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label6.Location = new System.Drawing.Point(8, 324);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(106, 17);
            this.Label6.TabIndex = 34;
            this.Label6.Text = "Required by date:";
            // 
            // frmOrderRequest
            // 
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(529, 711);
            this.Controls.Add(this.txtSubTotal);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtTotalTax);
            this.Controls.Add(this.txtFreightCharge);
            this.Controls.Add(this.txtSalesTax);
            this.Controls.Add(this.txtEntry);
            this.Controls.Add(this.fgProducts);
            this.Controls.Add(this.sbStatusBar);
            this.Controls.Add(this.dtRequired);
            this.Controls.Add(this.cmdSave);
            this.Controls.Add(this.cmdAddProducts);
            this.Controls.Add(this.cmdClose);
            this.Controls.Add(this.Frame1);
            this.Controls.Add(this.Frame2);
            this.Controls.Add(this.dtPromised);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Label6);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmOrderRequest";
            this.Text = "Create Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmOrderRequest_FormClosing);
            this.Load += new System.EventHandler(this.frmOrderRequest_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fgProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbStatusBar_Panel1)).EndInit();
            this.Frame1.ResumeLayout(false);
            this.Frame1.PerformLayout();
            this.Frame2.ResumeLayout(false);
            this.Frame2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion


		//=========================================================
		private string currentCompanyName;
		// VBto upgrade warning: currentIdCustomer As short --> As int	OnWrite(string)
		private int currentIdCustomer;
		private string currentContactName;
		private bool editingData;

		private double currentSubTotal;
		private double currentTotal;
		private double currentTax;
		private double currentFreightCharge;
		private double currentTotalTax;
		private bool editingQuantity;


		private void cmdAddProducts_Click(object sender, System.EventArgs e)
		{
			frmAddProductTo.InstancePtr.Id = currentIdCustomer;
			frmAddProductTo.InstancePtr.ObjectReferred = "Customer "+txtCustomerCompany.Text+"|"+txtCustomerContact.Text;
			frmAddProductTo.InstancePtr.Table = "ProductsByCustomer";
			frmAddProductTo.InstancePtr.ColumnName = "CustomerId";
			frmAddProductTo.InstancePtr.LoadData();
			frmAddProductTo.InstancePtr.ShowDialog();
			if (frmAddProductTo.InstancePtr.SavedChanges) {
				LoadProductsById();
			}
		}

#if defUse_txtName_Change
		private void txtName_Change()
		{
			DoSearchCustomer();
		}
#endif

		private void DoSearchCustomer(string Id = "")
		{
			string filter;
			filter = "";
			// If Not IsEmpty(Id) Then
			if (Id!="") {
				filter = "CustomerID = "+Id;
			}
			if (txtCompanyName.Text!=String.Empty) {
				if (filter!=String.Empty) {
					filter += " AND ";
				}
				filter = "CompanyName LIKE '%"+txtCompanyName.Text+"%'";
			}
			if (txtContactName.Text!=String.Empty) {
				if (filter!=String.Empty) {
					filter += " AND ";
				}
				filter += "ContactFirstName LIKE '%"+txtContactName.Text+"%'";
			}
			if (txtContactLastName.Text!=String.Empty) {
				if (filter!=String.Empty) {
					filter += " AND ";
				}
				filter += "ContactLastName LIKE '%"+txtContactLastName.Text+"%'";
			}

			if (filter!=String.Empty) {
				filter = "Where "+filter;
			}
			modConnection.ExecuteSql("Select CustomerID, CompanyName, ContactFirstName, ContactLastName, City, StateOrProvince, 'Country/Region' From Customers "+filter);
			lvCustomers.Items.Clear();
			if (modConnection.rs.RecordCount==0) {
				modMain.LogStatus("There are no records with the selected criteria", this);
			} else {
				ListViewItem x;
				while (!modConnection.rs.EOF) {
					x = lvCustomers.Items.Add(Convert.ToString(modConnection.rs.Fields[0].Value));
					for(modMain.i=1; modMain.i<=(modConnection.rs.ColumnCount-1); modMain.i++) {
						if (!VBto.IsEmpty(modConnection.rs.Fields[modMain.i].Value)) {
							VBto.SubItemsSetText(x, modMain.i, Convert.ToString(modConnection.rs.Fields[modMain.i].Value));
						}
					} // i
					modConnection.rs.MoveNext();
				}
				if (lvCustomers.Items.Count==1) {
					lvCustomers.FocusedItem = lvCustomers.Items[1 - 1]; lvCustomers.FocusedItem.Selected = true;
				}
			}
		}

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void cmdCustomers_Click(object sender, System.EventArgs e)
		{
			// On Error Resume Next
			frmCustomers.InstancePtr.ShowDialog();
			txtCompanyName.Text = "";
			txtContactLastName.Text = "";
			txtContactName.Text = "";
			DoSearchCustomer(frmCustomers.InstancePtr.CurrentCustomerID);
			frmCustomers.InstancePtr.Hide();
		}

		private void cmdSave_Click(object sender, System.EventArgs e)
		{
			int newOrderId;

			try
			{	// On Error GoTo HandleError
				modConnection.ExecuteSql("Select * from OrderRequests");
				modConnection.rs.AddNew();
				modConnection.rs.Fields["CustomerId"].Value = currentIdCustomer;
				modConnection.rs.Fields["EmployeeId"].Value = modMain.UserId;
				modConnection.rs.Fields["OrderDate"].Value = Convert.ToString(DateTime.Today);
				modConnection.rs.Fields["RequiredByDate"].Value = Convert.ToString(dtRequired.Value);
				modConnection.rs.Fields["PromisedByDate"].Value = Convert.ToString(dtPromised.Value);
				modConnection.rs.Fields["FreightCharge"].Value = currentFreightCharge;
				modConnection.rs.Fields["SalesTaxRate"].Value = currentTax*0.01;
				modConnection.rs.Fields["Status"].Value = "REQUESTED";
				modConnection.rs.Update();
				newOrderId = Convert.ToInt32(modConnection.rs.Fields["OrderID"].Value);


				for(modMain.i=1; modMain.i<=fgProducts.Rows-1; modMain.i++) {
					if (fgProducts.get_TextMatrix(modMain.i, 0)!="0") {
						modConnection.ExecuteSql("Insert into OrderRequestDetails (OrderID, ProductID, DateSold, Quantity, UnitPrice, SalePrice, LineTotal) Values ("+Convert.ToString(newOrderId)+", '"+fgProducts.get_TextMatrix(modMain.i, 1)+"', '"+VBto.vbFormat(DateTime.Today, "mm/dd/yyyy")+"',"+fgProducts.get_TextMatrix(modMain.i, 0)+","+fgProducts.get_TextMatrix(modMain.i, 3)+","+fgProducts.get_TextMatrix(modMain.i, 4)+","+fgProducts.get_TextMatrix(modMain.i, 4)+")");

						modConnection.ExecuteSql("Update Products Set UnitsOnOrder = UnitsOnOrder + "+fgProducts.get_TextMatrix(modMain.i, 0)+" Where ProductId = '"+fgProducts.get_TextMatrix(modMain.i, 1)+"'");

					}
				} // i

				editingData = false;
				if (MessageBox.Show("Order added successfully"+"\r\n"+"Would you like to add a new order?", "New data", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes) {
					ClearFields();
				} else {
					Close();
				}
				return;
			}
			catch
			{	// HandleError:
				// ...
			}
			MessageBox.Show("An error has occurred adding the data. Error: ("+Convert.ToString(Information.Err().Number)+") "+Information.Err().Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		public void cmdSave_Click()
		{
			cmdSave_Click(cmdSave, new System.EventArgs());
		}

		private void dtPromised_ValueChanged(object sender, System.EventArgs e)
		{
			editingData = true;
		}

		private void dtRequired_ValueChanged(object sender, System.EventArgs e)
		{
			// If dtPromised.value < dtRequired.value Then
			// dtPromised.value = dtRequired.value
			// End If
			editingData = true;
		}

		private void MakeTextBoxVisible(TextBox txtBox, AxMSFlexGridLib.AxMSFlexGrid grid)
		{

			if (grid.Row<0 || grid.Col<0) return;
			txtBox.Text = grid.get_TextMatrix(grid.Row, grid.Col);
			txtBox.Enabled = true;

			txtBox.Focus();
			Application.DoEvents();
			editingQuantity = true;

		}

		private void fgProducts_ClickEvent(object sender, System.EventArgs e)
		{
			if (fgProducts.Col!=0) return;
			MakeTextBoxVisible(txtEntry, fgProducts);
			modFunctions.SelectAll(txtEntry);
		}

		private void fgProducts_EnterCell(object sender, System.EventArgs e)
		{
			SaveEdits();
		}

		private void fgProducts_KeyPressEvent(object sender, AxMSFlexGridLib.DMSFlexGridEvents_KeyPressEvent e)
		{
			if (fgProducts.Col!=0) return;
			
			if ((e.keyAscii==46) || (e.keyAscii>=48 && e.keyAscii<=57))
			{
				// Case 45, 46, 47, 48 To 59, 65 To 90, 97 To 122
				MakeTextBoxVisible(txtEntry, fgProducts);
				txtEntry.Text = Convert.ToString(Convert.ToChar(e.keyAscii));
				txtEntry.SelectionStart = 1;
			}
		}

#if defUse_EditKeyCode
		// VBto upgrade warning: txtBox As TextBox	OnWrite(string)
		private void EditKeyCode(AxMSFlexGridLib.AxMSFlexGrid grid, ref TextBox txtBox, int KeyCode, int Shift)
		{
			switch (KeyCode) {
				
				case 27:
				{
					// ESC
					txtBox.Text = "";
					txtBox.Visible = false;
					grid.Focus();
					break;
				}
				case 13:
				{
					// Return
					grid.Focus();
					break;
				}
				case 37:
				{
					// Left Arrow
					grid.Focus();
					Application.DoEvents();
					if (grid.Col>grid.FixedCols) {
						grid.Col -= 1;
					}
					break;
				}
				case 38:
				{
					// Up Arrow
					grid.Focus();
					Application.DoEvents();
					if (grid.Row>grid.FixedRows) {
						grid.Row -= 1;
					}
					break;
				}
				case 39:
				{
					// Right Arrow
					grid.Focus();
					Application.DoEvents();
					if (grid.Col<(grid.Cols-1)) {
						grid.Col += 1;
					}
					break;
				}
				case 40:
				{
					// Down Arrow
					grid.Focus();
					Application.DoEvents();
					if (grid.Row<(grid.Rows-1)) {
						grid.Row += 1;
					}
					break;
				}
			} //end switch
		}
#endif

		private void txtEntry_Leave(object sender, System.EventArgs e)
		{
			SaveEdits();
		}


		private void fgProducts_LeaveCell(object sender, System.EventArgs e)
		{
			if (editingQuantity) {
				SaveEdits();
			}
		}

		private void SaveEdits()
		{
			double lineQuantity, lineUnitPrice, linePrice;
			double previousLinePrice;
			if (!editingQuantity || !modFunctions.ValidateTextBoxDouble(txtEntry, this) || !modFunctions.ValidateTextDouble(fgProducts.get_TextMatrix(fgProducts.Row, 4), this)) {
				return;
			}
			previousLinePrice = modFunctions.DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 4));
			fgProducts.set_TextMatrix(fgProducts.Row, fgProducts.Col, txtEntry.Text);
			lineQuantity = modFunctions.DoubleValue(txtEntry.Text);
			lineUnitPrice = modFunctions.DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 3));
			previousLinePrice = modFunctions.DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 4));
			linePrice = Convert.ToDouble(lineQuantity*lineUnitPrice);
			fgProducts.set_TextMatrix(fgProducts.Row, 4, Convert.ToString(linePrice));
			ReCalculateTotals(previousLinePrice, linePrice);
			editingQuantity = false;
			txtEntry.Enabled = false;
			txtEntry.Text = "";

			editingData = true;
		}

		private void ReCalculateTotals(double previous, double current)
		{
			currentSubTotal += -previous+current;
			currentTotalTax = currentSubTotal*currentTax*0.01;
			currentTotal = currentFreightCharge+currentSubTotal+currentTotalTax;
			txtSubTotal.Text = VBto.vbFormat(currentSubTotal, "#,##0.00");
			txtTotalTax.Text = VBto.vbFormat(currentTotalTax, "#,##0.00");
			txtTotal.Text = VBto.vbFormat(currentTotal, "#,##0.00");
		}

		// VBto upgrade warning: Cancel As short	OnWrite(bool)
		private void Form_QueryUnload(ref short Cancel, int UnloadMode)
		{
			if (editingData) {
				DialogResult res;
				res = MessageBox.Show("Do you want to save the edited data?", "Save data", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
				if (res==DialogResult.Yes) {
					cmdSave_Click();
				} else if (res!=DialogResult.No) {
					Cancel = Convert.ToInt16(true);
				}
			}
		}

		private void frmOrderRequest_FormClosing(object sender, FormClosingEventArgs e)
		{
			short Cancel = 0;
			Form_QueryUnload(ref Cancel, 0);
			if (Cancel != 0)
			{
				e.Cancel = true;
				return;
			}
		}

		private void frmOrderRequest_Load(object sender, System.EventArgs e)
		{
			editingData = false;
			ClearFields();
		}

		private void lvCustomers_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ListViewItem Item = ((ListView)sender).FocusedItem;
			if (Item==null) return;

			RetrieveDataCustomer();
		}

		private void RetrieveDataCustomer()
		{
			if (editingData) {
				if (MessageBox.Show("Do you want to cancel previous edited data?", "Data edition", MessageBoxButtons.YesNo, MessageBoxIcon.Question)!=DialogResult.Yes) {
					return;
				}
			}

			if (lvCustomers.FocusedItem.Text!=String.Empty) {

				currentIdCustomer = VBto.Int(lvCustomers.FocusedItem.Text);
				currentCompanyName = lvCustomers.FocusedItem.SubItems[1].Text;
				currentContactName = lvCustomers.FocusedItem.SubItems[2].Text+" "+lvCustomers.FocusedItem.SubItems[3].Text;

				txtCustomerCompany.Text = currentCompanyName;
				txtCustomerContact.Text = currentContactName;
				editingData = false;
			}
			LoadProductsById();
			cmdSave.Enabled = true;
			cmdAddProducts.Enabled = true;
			dtRequired.Enabled = true;
			dtPromised.Enabled = true;

		}

		private void LoadProductsById()
		{
			string Table;
			string ColumnName;
			int Id;
			Table = "ProductsByCustomer";
			ColumnName = "CustomerId";
			Id = currentIdCustomer;

			modConnection.ExecuteSql("Select p.ProductID, p.ProductName, p.UnitPrice, p.UnitsInStock, p.UnitsOnOrder, p.QuantityPerUnit, p.Unit from Products as p, "+Table+" as pb Where pb."+ColumnName+" = "+Convert.ToString(Id)+" And pb.ProductId = p.ProductId");

			// lvProducts.ListItems.Clear
			// If rs.RecordCount > 0 Then
			// With rs
			// While Not .EOF
			// Set x = lvProducts.ListItems.Add(, , 0)
			// For i = 1 To 5
			// If Not IsEmpty(.Fields(i - 1)) Then
			// x.SubItems(i) = .Fields(i - 1)
			// End If
			// Next i
			// x.SubItems(6) = .Fields(5) & .Fields(6)
			// .MoveNext
			// Wend
			// End With
			// End If

			int lng/*unused?*/;
			int intLoopCount/*unused?*/;
			const short SCROOL_WIDTH = 320;

			fgProducts.Cols = 8;
			fgProducts.FixedCols = 0;
			fgProducts.Rows = 0;
			fgProducts.AddItem("Quantity"+"\t"+"Code"+"\t"+"Product"+"\t"+"UnitPrice"+"\t"+"Price"+"\t"+"Existence"+"\t"+"Ordered"+"\t"+"Quantity per unit");
			fgProducts.Rows = modConnection.rs.RecordCount+1;
			if (fgProducts.Rows==1) fgProducts.FixedRows = 0; else  fgProducts.FixedRows = 1;
			int i;
			int j;
			i = 1;
			while (!modConnection.rs.EOF) {
				fgProducts.set_TextMatrix(i, 0, "0");
				for(j=1; j<=6; j++) {
					if (j==4) {
						fgProducts.set_TextMatrix(i, j, "0");
					} else if (j<4) {
						fgProducts.set_TextMatrix(i, j, Convert.ToString(modConnection.rs.Fields[j-1].Value));
					} else {
						fgProducts.set_TextMatrix(i, j, Convert.ToString(modConnection.rs.Fields[j-2].Value));
					}
				} // j
				fgProducts.set_TextMatrix(i, 7, Convert.ToString(modConnection.rs.Fields[5].Value)+Convert.ToString(modConnection.rs.Fields[6].Value));
				modConnection.rs.MoveNext();
				i += 1;
			}

		}

#if defUse_lvProducts_ItemCheck
		private void lvProducts_ItemCheck(ListViewItem Item)
		{
			if (Item.Checked) {
				Item.Text = "1";
			} else {
				Item.Text = "0";
			}
		}
#endif

		private void txtCompanyName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchCustomer();
		}

		private void txtContactLastName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchCustomer();
		}

		private void txtContactName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchCustomer();
		}

		private void ClearFields()
		{

			fgProducts.Rows = 0;
			fgProducts.Cols = 0;

			currentSubTotal = 0;
			currentTotal = 0;
			currentTax = 0;
			currentTotalTax = 0;
			currentFreightCharge = 0;

			txtSubTotal.Text = "";
			txtTotal.Text = "";
			txtTotalTax.Text = "";
			txtSalesTax.Text = "";
			txtFreightCharge.Text = "";

			txtCompanyName.Text = "";
			txtContactLastName.Text = "";
			txtContactName.Text = "";
			txtCustomerContact.Text = "";
			txtCustomerCompany.Text = "";
			cmdSave.Enabled = false;
			cmdAddProducts.Enabled = false;
			dtRequired.Enabled = false;
			dtPromised.Enabled = false;
			// txtCompanyName.SetFocus
			// txtCompanyName.SetFocus
			ReCalculateTotals(0, 0);
			editingData = false;
		}

		private void txtFreightCharge_TextChanged(object sender, System.EventArgs e)
		{
			currentFreightCharge = modFunctions.DoubleValue(txtFreightCharge.Text);
			ReCalculateTotals(0, 0);
			editingData = true;
		}

		private void txtFreightCharge_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Keys KeyAscii = (Keys)Strings.Asc(e.KeyChar);

			
			if (KeyAscii>=Keys.D0 && KeyAscii<=Keys.D9)
			{
			}
			else if ((KeyAscii==Keys.Back) || (KeyAscii==Keys.Clear) || (KeyAscii==Keys.Delete))
			{
			}
			else if ((KeyAscii==Keys.Left) || (KeyAscii==Keys.Right) || (KeyAscii==Keys.Up) || (KeyAscii==Keys.Down) || (KeyAscii==Keys.Tab))
			{
			}
			else 
			{
				KeyAscii = 0;
				Interaction.Beep();
			}

			e.KeyChar = Strings.Chr((int)KeyAscii); if (KeyAscii == 0) e.Handled = true;
		}

		private void txtSalesTax_TextChanged(object sender, System.EventArgs e)
		{
			currentTax = modFunctions.DoubleValue(txtSalesTax.Text);
			ReCalculateTotals(0, 0);
			editingData = true;
		}

		private void txtSalesTax_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Keys KeyAscii = (Keys)Strings.Asc(e.KeyChar);

			
			if (KeyAscii>=Keys.D0 && KeyAscii<=Keys.D9)
			{
			}
			else if ((KeyAscii==Keys.Back) || (KeyAscii==Keys.Clear) || (KeyAscii==Keys.Delete))
			{
			}
			else if ((KeyAscii==Keys.Left) || (KeyAscii==Keys.Right) || (KeyAscii==Keys.Up) || (KeyAscii==Keys.Down) || (KeyAscii==Keys.Tab))
			{
			}
			else 
			{
				KeyAscii = 0;
				Interaction.Beep();
			}

			e.KeyChar = Strings.Chr((int)KeyAscii); if (KeyAscii == 0) e.Handled = true;
		}

	}
}