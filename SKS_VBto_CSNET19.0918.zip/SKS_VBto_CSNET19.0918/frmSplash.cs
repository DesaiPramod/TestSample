using Microsoft.VisualBasic;

namespace SKS
{
	/// <summary>
	/// Summary description for frmSplash.
	/// </summary>
	public class frmSplash : System.Windows.Forms.Form
	{
		public System.Windows.Forms.Timer Timer1;
		public System.Windows.Forms.PictureBox Image1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmSplash()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmSplash InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmSplash();
				return _InstancePtr;
			}
		}
		protected static frmSplash _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSplash));
			this.Timer1 = new System.Windows.Forms.Timer();
			this.Image1 = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			//
			// Timer1
			//
			this.Timer1.Enabled = true;
			this.Timer1.Interval = 3000;
			this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick);
			//
			// Image1
			//
			this.Image1.Name = "Image1";
			this.Image1.Location = new System.Drawing.Point(0, 0);
			this.Image1.Size = new System.Drawing.Size(975, 649);
			this.Image1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.Image1.BackColor = System.Drawing.SystemColors.Control;
			this.Image1.Image = ((System.Drawing.Image)(resources.GetObject("Image1.Image")));
			this.Image1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			//
			// frmSplash
			//
			this.ClientSize = new System.Drawing.Size(954, 620);
			this.Controls.Add(this.Image1);
			this.Name = "frmSplash";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.KeyPreview = true;
			this.ShowInTaskbar = false;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmSplash_KeyPress);
			this.Text = "";
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================


		private void frmSplash_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Close();
		}

#if defUse_Frame1_Click
		private void Frame1_Click()
		{
			Close();
		}
#endif

		private void Timer1_Tick(object sender, System.EventArgs e)
		{
			Close();
		}

	}
}