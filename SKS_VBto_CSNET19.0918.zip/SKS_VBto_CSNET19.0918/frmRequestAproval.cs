using System;
using System.Windows.Forms;

namespace SKS
{
	/// <summary>
	/// Summary description for frmRequestApproval.
	/// </summary>
	public class frmRequestApproval : System.Windows.Forms.Form
	{
		public System.Windows.Forms.Button cmdApprove;
		public System.Windows.Forms.Button cmdInfo;
		public AxMSFlexGridLib.AxMSFlexGrid fgOrders;
		public System.Windows.Forms.StatusBar sbStatusBar;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel1;
		public System.Windows.Forms.Button cmdCancel;
		public System.Windows.Forms.Button cmdClose;
		public System.Windows.Forms.GroupBox Frame1;
		public System.Windows.Forms.ComboBox cmbStatus;
		public System.Windows.Forms.CheckBox chkTo;
		public System.Windows.Forms.CheckBox chkFrom;
		public System.Windows.Forms.TextBox txtProductID;
		public System.Windows.Forms.TextBox txtOrderID;
		public System.Windows.Forms.TextBox txtContactLastName;
		public System.Windows.Forms.TextBox txtContactName;
		public System.Windows.Forms.Button cmdCustomers;
		public System.Windows.Forms.TextBox txtCompanyName;
		public System.Windows.Forms.DateTimePicker dtFrom;
		public System.Windows.Forms.DateTimePicker dtTo;
		public System.Windows.Forms.Label Label5;
		public System.Windows.Forms.Label Label8;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.Label Label6;
		public System.Windows.Forms.Label Label3;
		public System.Windows.Forms.Label Label4;
		public System.Windows.Forms.Label Label2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmRequestApproval()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmRequestApproval InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmRequestApproval();
				return _InstancePtr;
			}
		}
		protected static frmRequestApproval _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRequestApproval));
			this.cmdApprove = new System.Windows.Forms.Button();
			this.cmdInfo = new System.Windows.Forms.Button();
			this.fgOrders = new AxMSFlexGridLib.AxMSFlexGrid();
			this.sbStatusBar = new System.Windows.Forms.StatusBar();
			this.sbStatusBar_Panel1 = new System.Windows.Forms.StatusBarPanel();
			this.cmdCancel = new System.Windows.Forms.Button();
			this.cmdClose = new System.Windows.Forms.Button();
			this.Frame1 = new System.Windows.Forms.GroupBox();
			this.cmbStatus = new System.Windows.Forms.ComboBox();
			this.chkTo = new System.Windows.Forms.CheckBox();
			this.chkFrom = new System.Windows.Forms.CheckBox();
			this.txtProductID = new System.Windows.Forms.TextBox();
			this.txtOrderID = new System.Windows.Forms.TextBox();
			this.txtContactLastName = new System.Windows.Forms.TextBox();
			this.txtContactName = new System.Windows.Forms.TextBox();
			this.cmdCustomers = new System.Windows.Forms.Button();
			this.txtCompanyName = new System.Windows.Forms.TextBox();
			this.dtFrom = new System.Windows.Forms.DateTimePicker();
			this.dtTo = new System.Windows.Forms.DateTimePicker();
			this.Label5 = new System.Windows.Forms.Label();
			this.Label8 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.Label6 = new System.Windows.Forms.Label();
			this.Label3 = new System.Windows.Forms.Label();
			this.Label4 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			//
			// cmdApprove
			//
			this.cmdApprove.Name = "cmdApprove";
			this.cmdApprove.TabIndex = 10;
			this.cmdApprove.Location = new System.Drawing.Point(235, 445);
			this.cmdApprove.Size = new System.Drawing.Size(90, 25);
			this.cmdApprove.Text = "&Create Invoice";
			this.cmdApprove.BackColor = System.Drawing.SystemColors.Control;
			this.cmdApprove.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdApprove.Click += new System.EventHandler(this.cmdApprove_Click);
			//
			// cmdInfo
			//
			this.cmdInfo.Name = "cmdInfo";
			this.cmdInfo.TabIndex = 9;
			this.cmdInfo.Location = new System.Drawing.Point(138, 445);
			this.cmdInfo.Size = new System.Drawing.Size(90, 25);
			this.cmdInfo.Text = "&Information";
			this.cmdInfo.BackColor = System.Drawing.SystemColors.Control;
			this.cmdInfo.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdInfo.Click += new System.EventHandler(this.cmdInfo_Click);
			//
			// fgOrders
			//
			this.fgOrders.Name = "fgOrders";
			this.fgOrders.TabIndex = 8;
			this.fgOrders.Location = new System.Drawing.Point(8, 170);
			this.fgOrders.Size = new System.Drawing.Size(511, 268);
			this.fgOrders.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("fgOrders.OcxState")));
			this.fgOrders.DblClick += new System.EventHandler(this.fgOrders_DblClick);
			//
			// sbStatusBar
			//
			this.sbStatusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {this.sbStatusBar_Panel1});
			this.sbStatusBar.Name = "sbStatusBar";
			this.sbStatusBar.TabIndex = 18;
			this.sbStatusBar.Location = new System.Drawing.Point(0, 476);
			this.sbStatusBar.Size = new System.Drawing.Size(529, 25);
			this.sbStatusBar.ShowPanels = true;
			this.sbStatusBar.SizingGrip = false;
			//
			// Panel1
			//
			this.sbStatusBar_Panel1.Text = "";
			this.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbStatusBar_Panel1.Width = 527;
			//
			// cmdCancel
			//
			this.cmdCancel.Name = "cmdCancel";
			this.cmdCancel.TabIndex = 11;
			this.cmdCancel.Location = new System.Drawing.Point(332, 445);
			this.cmdCancel.Size = new System.Drawing.Size(90, 25);
			this.cmdCancel.Text = "&Cancel Order";
			this.cmdCancel.BackColor = System.Drawing.SystemColors.Control;
			this.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
			//
			// cmdClose
			//
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.TabIndex = 12;
			this.cmdClose.Location = new System.Drawing.Point(429, 445);
			this.cmdClose.Size = new System.Drawing.Size(90, 25);
			this.cmdClose.Text = "&Close";
			this.cmdClose.BackColor = System.Drawing.SystemColors.Control;
			this.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			//
			// Frame1
			//
			this.Frame1.Controls.Add(this.cmbStatus);
			this.Frame1.Controls.Add(this.chkTo);
			this.Frame1.Controls.Add(this.chkFrom);
			this.Frame1.Controls.Add(this.txtProductID);
			this.Frame1.Controls.Add(this.txtOrderID);
			this.Frame1.Controls.Add(this.txtContactLastName);
			this.Frame1.Controls.Add(this.txtContactName);
			this.Frame1.Controls.Add(this.cmdCustomers);
			this.Frame1.Controls.Add(this.txtCompanyName);
			this.Frame1.Controls.Add(this.dtFrom);
			this.Frame1.Controls.Add(this.dtTo);
			this.Frame1.Controls.Add(this.Label5);
			this.Frame1.Controls.Add(this.Label8);
			this.Frame1.Controls.Add(this.Label1);
			this.Frame1.Controls.Add(this.Label6);
			this.Frame1.Controls.Add(this.Label3);
			this.Frame1.Controls.Add(this.Label4);
			this.Frame1.Controls.Add(this.Label2);
			this.Frame1.Name = "Frame1";
			this.Frame1.TabIndex = 13;
			this.Frame1.Location = new System.Drawing.Point(8, 8);
			this.Frame1.Size = new System.Drawing.Size(511, 155);
			this.Frame1.Text = "Search customer";
			this.Frame1.BackColor = System.Drawing.SystemColors.Control;
			this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// cmbStatus
			//
			this.cmbStatus.Name = "cmbStatus";
			this.cmbStatus.TabIndex = 1;
			this.cmbStatus.Location = new System.Drawing.Point(340, 16);
			this.cmbStatus.Size = new System.Drawing.Size(147, 21);
			this.cmbStatus.Text = "";
			this.cmbStatus.BackColor = System.Drawing.SystemColors.Window;
			this.cmbStatus.ForeColor = System.Drawing.SystemColors.WindowText;
			this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbStatus.Items.AddRange(new Object[] {"All", "Requested", "Cancelled", "Approved"});
			this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.cmbStatus_SelectedIndexChanged);
			//
			// chkTo
			//
			this.chkTo.Name = "chkTo";
			this.chkTo.TabStop = false;
			this.chkTo.TabIndex = 23;
			this.chkTo.Location = new System.Drawing.Point(340, 81);
			this.chkTo.Size = new System.Drawing.Size(41, 17);
			this.chkTo.Text = "To:";
			this.chkTo.BackColor = System.Drawing.SystemColors.Control;
			this.chkTo.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// chkFrom
			//
			this.chkFrom.Name = "chkFrom";
			this.chkFrom.TabStop = false;
			this.chkFrom.TabIndex = 22;
			this.chkFrom.Location = new System.Drawing.Point(89, 81);
			this.chkFrom.Size = new System.Drawing.Size(48, 17);
			this.chkFrom.Text = "From:";
			this.chkFrom.BackColor = System.Drawing.SystemColors.Control;
			this.chkFrom.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// txtProductID
			//
			this.txtProductID.Name = "txtProductID";
			this.txtProductID.TabIndex = 7;
			this.txtProductID.Location = new System.Drawing.Point(340, 113);
			this.txtProductID.Size = new System.Drawing.Size(147, 20);
			this.txtProductID.Text = "";
			this.txtProductID.BackColor = System.Drawing.SystemColors.Window;
			this.txtProductID.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtProductID.TextChanged += new System.EventHandler(this.txtProductID_TextChanged);
			//
			// txtOrderID
			//
			this.txtOrderID.Name = "txtOrderID";
			this.txtOrderID.TabIndex = 6;
			this.txtOrderID.Location = new System.Drawing.Point(89, 113);
			this.txtOrderID.Size = new System.Drawing.Size(147, 20);
			this.txtOrderID.Text = "";
			this.txtOrderID.BackColor = System.Drawing.SystemColors.Window;
			this.txtOrderID.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtOrderID.TextChanged += new System.EventHandler(this.txtOrderID_TextChanged);
			//
			// txtContactLastName
			//
			this.txtContactLastName.Name = "txtContactLastName";
			this.txtContactLastName.TabIndex = 3;
			this.txtContactLastName.Location = new System.Drawing.Point(340, 49);
			this.txtContactLastName.Size = new System.Drawing.Size(147, 20);
			this.txtContactLastName.Text = "";
			this.txtContactLastName.BackColor = System.Drawing.SystemColors.Window;
			this.txtContactLastName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtContactLastName.TextChanged += new System.EventHandler(this.txtContactLastName_TextChanged);
			//
			// txtContactName
			//
			this.txtContactName.Name = "txtContactName";
			this.txtContactName.TabIndex = 2;
			this.txtContactName.Location = new System.Drawing.Point(89, 49);
			this.txtContactName.Size = new System.Drawing.Size(147, 20);
			this.txtContactName.Text = "";
			this.txtContactName.BackColor = System.Drawing.SystemColors.Window;
			this.txtContactName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtContactName.TextChanged += new System.EventHandler(this.txtContactName_TextChanged);
			//
			// cmdCustomers
			//
			this.cmdCustomers.Name = "cmdCustomers";
			this.cmdCustomers.TabStop = false;
			this.cmdCustomers.TabIndex = 14;
			this.cmdCustomers.Location = new System.Drawing.Point(243, 16);
			this.cmdCustomers.Size = new System.Drawing.Size(25, 23);
			this.cmdCustomers.Text = "...";
			this.cmdCustomers.BackColor = System.Drawing.SystemColors.Control;
			this.cmdCustomers.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdCustomers.Click += new System.EventHandler(this.cmdCustomers_Click);
			//
			// txtCompanyName
			//
			this.txtCompanyName.Name = "txtCompanyName";
			this.txtCompanyName.TabIndex = 0;
			this.txtCompanyName.Location = new System.Drawing.Point(89, 16);
			this.txtCompanyName.Size = new System.Drawing.Size(147, 20);
			this.txtCompanyName.Text = "";
			this.txtCompanyName.BackColor = System.Drawing.SystemColors.Window;
			this.txtCompanyName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtCompanyName.TextChanged += new System.EventHandler(this.txtCompanyName_TextChanged);
			//
			// dtFrom
			//
			this.dtFrom.Name = "dtFrom";
			this.dtFrom.TabIndex = 4;
			this.dtFrom.Location = new System.Drawing.Point(138, 81);
			this.dtFrom.Size = new System.Drawing.Size(98, 20);
			this.dtFrom.ValueChanged += new System.EventHandler(this.dtFrom_ValueChanged);
			//
			// dtTo
			//
			this.dtTo.Name = "dtTo";
			this.dtTo.TabIndex = 5;
			this.dtTo.Location = new System.Drawing.Point(388, 81);
			this.dtTo.Size = new System.Drawing.Size(98, 20);
			this.dtTo.ValueChanged += new System.EventHandler(this.dtTo_ValueChanged);
			//
			// Label5
			//
			this.Label5.Name = "Label5";
			this.Label5.TabIndex = 24;
			this.Label5.Location = new System.Drawing.Point(291, 16);
			this.Label5.Size = new System.Drawing.Size(41, 17);
			this.Label5.Text = "Status:";
			this.Label5.BackColor = System.Drawing.SystemColors.Control;
			this.Label5.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label8
			//
			this.Label8.Name = "Label8";
			this.Label8.TabIndex = 21;
			this.Label8.Location = new System.Drawing.Point(259, 113);
			this.Label8.Size = new System.Drawing.Size(90, 17);
			this.Label8.Text = "Product code:";
			this.Label8.BackColor = System.Drawing.SystemColors.Control;
			this.Label8.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label1
			//
			this.Label1.Name = "Label1";
			this.Label1.TabIndex = 20;
			this.Label1.Location = new System.Drawing.Point(8, 113);
			this.Label1.Size = new System.Drawing.Size(90, 17);
			this.Label1.Text = "Order number:";
			this.Label1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label6
			//
			this.Label6.Name = "Label6";
			this.Label6.TabIndex = 19;
			this.Label6.Location = new System.Drawing.Point(8, 81);
			this.Label6.Size = new System.Drawing.Size(66, 17);
			this.Label6.Text = "Date range:";
			this.Label6.BackColor = System.Drawing.SystemColors.Control;
			this.Label6.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label3
			//
			this.Label3.Name = "Label3";
			this.Label3.TabIndex = 17;
			this.Label3.Location = new System.Drawing.Point(243, 49);
			this.Label3.Size = new System.Drawing.Size(98, 17);
			this.Label3.Text = "Contact last name:";
			this.Label3.BackColor = System.Drawing.SystemColors.Control;
			this.Label3.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label4
			//
			this.Label4.Name = "Label4";
			this.Label4.TabIndex = 16;
			this.Label4.Location = new System.Drawing.Point(8, 16);
			this.Label4.Size = new System.Drawing.Size(90, 17);
			this.Label4.Text = "Company name:";
			this.Label4.BackColor = System.Drawing.SystemColors.Control;
			this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label2
			//
			this.Label2.Name = "Label2";
			this.Label2.TabIndex = 15;
			this.Label2.Location = new System.Drawing.Point(8, 49);
			this.Label2.Size = new System.Drawing.Size(90, 17);
			this.Label2.Text = "Contact name:";
			this.Label2.BackColor = System.Drawing.SystemColors.Control;
			this.Label2.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// frmRequestApproval
			//
			this.ClientSize = new System.Drawing.Size(529, 502);
			this.Controls.Add(this.cmdApprove);
			this.Controls.Add(this.cmdInfo);
			this.Controls.Add(this.fgOrders);
			this.Controls.Add(this.sbStatusBar);
			this.Controls.Add(this.cmdCancel);
			this.Controls.Add(this.cmdClose);
			this.Controls.Add(this.Frame1);
			this.Name = "frmRequestApproval";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
			this.Load += new System.EventHandler(this.frmRequestApproval_Load);
			this.Text = "Create Invoice";
			((System.ComponentModel.ISupportInitialize)(this.fgOrders)).EndInit();
			this.Frame1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================
		private string Id;


		private void cmbStatus_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DoSearchRequest();
		}

		private void cmdApprove_Click(object sender, System.EventArgs e)
		{
			LoadActionOrderRequest(1);
		}

		private void cmdCancel_Click(object sender, System.EventArgs e)
		{
			LoadActionOrderRequest(2);
		}

		private void cmdInfo_Click(object sender, System.EventArgs e)
		{
			LoadActionOrderRequest();
		}
		public void cmdInfo_Click()
		{
			cmdInfo_Click(cmdInfo, new System.EventArgs());
		}

		private void LoadActionOrderRequest(int Action = 0)
		{
			if (fgOrders.Row>0) {
				int OrderId;

				OrderId = Convert.ToInt16(double.Parse(fgOrders.get_TextMatrix(fgOrders.Row, 1)));
				frmActionOrderRequest.InstancePtr.OrderId = OrderId;
				frmActionOrderRequest.InstancePtr.Action = Action;
				frmActionOrderRequest.InstancePtr.LoadData();
				VBto.ShowAsMdiChild(frmActionOrderRequest.InstancePtr); // vbModal

			}
		}

		private void dtFrom_ValueChanged(object sender, System.EventArgs e)
		{
			chkFrom.CheckState = CheckState.Checked;
			DoSearchRequest();
		}

		private void dtTo_ValueChanged(object sender, System.EventArgs e)
		{
			chkTo.CheckState = CheckState.Checked;
			DoSearchRequest();
		}


		private void fgOrders_DblClick(object sender, System.EventArgs e)
		{
			cmdInfo_Click();
		}

		private void frmRequestApproval_Load(object sender, System.EventArgs e)
		{
			InitGrid();
		}

		private void txtOrderID_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchRequest();
		}

		private void txtProductID_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchRequest();
		}

		private void txtCompanyName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchRequest();
		}

		private void txtContactLastName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchRequest();
		}

		private void txtContactName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchRequest();
		}

#if defUse_txtName_Change
		private void txtName_Change()
		{
			DoSearchRequest();
		}
#endif

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void cmdCustomers_Click(object sender, System.EventArgs e)
		{
			frmCustomers.InstancePtr.ShowDialog();
			txtCompanyName.Text = "";
			txtContactLastName.Text = "";
			txtContactName.Text = "";
			DoSearchRequest(VBto.Int(frmCustomers.InstancePtr.CurrentCustomerID));
			frmCustomers.InstancePtr.Hide();
		}

		// VBto upgrade warning: Id As short --> As int	OnWrite(string)
		private void DoSearchRequest(int Id = -1)
		{
			string filter;
			filter = "";
			if (Id!=-1) {
				filter = "o.CustomerID = "+Convert.ToString(Id);
			}
			if (txtCompanyName.Text!=String.Empty) {
				modFunctions.AppendAND(ref filter);
				filter = "c.CompanyName LIKE '%"+txtCompanyName.Text+"%'";
			}
			if (txtContactName.Text!=String.Empty) {
				modFunctions.AppendAND(ref filter);
				filter += "c.ContactFirstName LIKE '%"+txtContactName.Text+"%'";
			}
			if (txtContactLastName.Text!=String.Empty) {
				modFunctions.AppendAND(ref filter);
				filter += "c.ContactLastName LIKE '%"+txtContactLastName.Text+"%'";
			}
			if (txtOrderID.Text!=String.Empty) {
				modFunctions.AppendAND(ref filter);
				filter += "o.OrderID = "+txtOrderID.Text;
			}
			if (txtProductID.Text!=String.Empty) {
				modFunctions.AppendAND(ref filter);
				filter += "d.ProductID LIKE '%"+txtProductID.Text+"%'";
			}
			if (chkFrom.CheckState==CheckState.Checked) {
				modFunctions.AppendAND(ref filter);
				filter += "o.OrderDate >= #"+VBto.vbFormat(dtFrom.Value, "mm/dd/yyyy")+"#";
			}
			if (chkTo.CheckState==CheckState.Checked) {
				modFunctions.AppendAND(ref filter);
				filter += "o.OrderDate <= #"+VBto.vbFormat(dtTo.Value, "mm/dd/yyyy")+"#";
			}
			if (cmbStatus.SelectedIndex!=-1 && cmbStatus.Text!="All") {
				modFunctions.AppendAND(ref filter);
				filter += "o.Status = '"+cmbStatus.Text+"'";
			}

			string mwhere;
			mwhere = " Where o.OrderID = d.OrderID And c.CustomerID = o.CustomerID And u.Username = o.EmployeeId ";
			if (filter!=String.Empty) {
				filter = mwhere+" AND "+filter;
			} else {
				filter = mwhere;
			}

			string sql;

			sql = "Select o.OrderDate, o.OrderID, c.CompanyName, c.ContactFirstName + ' ' + c.ContactLastName as ContactName, u.Fullname as [Received by], Sum(d.LineTotal) as Price, o.Status "+"From OrderRequests as o, OrderRequestDetails as d, Customers as c, Users as u "+filter+" Group by o.orderDate, o.OrderID, c.CompanyName, c.ContactFirstName + ' ' + c.ContactLastName, u.Fullname, o.Status ";
			modConnection.ExecuteSql(sql);
			modMain.LogStatus("There are "+Convert.ToString(modConnection.rs.RecordCount)+" records with the selected criteria", this);

			fgOrders.Rows = modConnection.rs.RecordCount+1;
			if (fgOrders.Rows==1) fgOrders.FixedRows = 0; else  fgOrders.FixedRows = 1;
			int i;
			int j;
			i = 1;
			while (!modConnection.rs.EOF) {
				for(j=0; j<=modConnection.rs.ColumnCount-1; j++) {
					if (!(modConnection.rs.Fields[j]==null)) {
						fgOrders.set_TextMatrix(i, j, Convert.ToString(modConnection.rs.Fields[j].Value));
					}
				} // j
				modConnection.rs.MoveNext();
				i += 1;
			}

		}

		private void InitGrid()
		{

			fgOrders.Rows = 0;
			fgOrders.Cols = 7;
			fgOrders.FixedCols = 0;
			fgOrders.AddItem("Date"+"\t"+"Order"+"\t"+"Customer"+"\t"+"Contact"+"\t"+"Received by"+"\t"+"Price"+"\t"+"Status");
			fgOrders.Rows = 1;
			fgOrders.FixedRows = 0;
			fgOrders.SelectionMode = MSFlexGridLib.SelectionModeSettings.flexSelectionByRow;

		}

		// 
		// UNUSED CODE Start



#if defUse_MakeTextBoxVisible
		private void MakeTextBoxVisible(TextBox txtBox, AxMSFlexGridLib.AxMSFlexGrid grid)
		{

			txtBox.Text = grid.get_TextMatrix(grid.Row, grid.Col);
			VBto.SetBounds(txtBox, grid.CellLeft+grid.Left, grid.CellTop+grid.Top, grid.CellWidth, grid.CellHeight);
			txtBox.Visible = true;
			Application.DoEvents();
			txtBox.Focus();

		}
#endif



	}
}