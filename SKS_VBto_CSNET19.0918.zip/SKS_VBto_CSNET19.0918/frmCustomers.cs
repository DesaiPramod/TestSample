using System;
using System.Windows.Forms;
using Microsoft.VisualBasic.Compatibility.VB6;
using ADODB;

namespace SKS
{
	/// <summary>
	/// Summary description for frmCustomers.
	/// </summary>
	public class frmCustomers : System.Windows.Forms.Form
	{
		public Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray txtField;
		public Microsoft.VisualBasic.Compatibility.VB6.ADODC dcCustomers;
		public System.Windows.Forms.GroupBox Frame1;
		public System.Windows.Forms.TextBox txtField_4;
		public System.Windows.Forms.TextBox txtField_0;
		public System.Windows.Forms.TextBox txtField_6;
		public System.Windows.Forms.TextBox txtField_7;
		public System.Windows.Forms.TextBox txtField_2;
		public System.Windows.Forms.TextBox txtField_1;
		public System.Windows.Forms.TextBox txtField_3;
		public System.Windows.Forms.TextBox txtField_5;
		public System.Windows.Forms.GroupBox Frame2;
		public System.Windows.Forms.TextBox txtField_11;
		public System.Windows.Forms.TextBox txtField_13;
		public System.Windows.Forms.TextBox txtField_12;
		public System.Windows.Forms.Label Label7;
		public System.Windows.Forms.Label Label3;
		public System.Windows.Forms.Label Label2;
		public System.Windows.Forms.TextBox txtField_8;
		public System.Windows.Forms.TextBox txtField_10;
		public System.Windows.Forms.TextBox txtField_14;
		public System.Windows.Forms.TextBox txtField_9;
		public System.Windows.Forms.Label Label15;
		public System.Windows.Forms.Label Label14;
		public System.Windows.Forms.Label Label13;
		public System.Windows.Forms.Label Label12;
		public System.Windows.Forms.Label Label11;
		public System.Windows.Forms.Label Label10;
		public System.Windows.Forms.Label Label9;
		public System.Windows.Forms.Label Label8;
		public System.Windows.Forms.Label Label6;
		public System.Windows.Forms.Label Label5;
		public System.Windows.Forms.Label Label4;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.ImageList ImageList1;
		public System.Windows.Forms.ToolBar Toolbar1;
		private System.Windows.Forms.ToolBarButton Button1;
		private System.Windows.Forms.ToolBarButton Button2;
		private System.Windows.Forms.ToolBarButton Button3;
		private System.Windows.Forms.ToolBarButton Button4;
		private System.Windows.Forms.ToolBarButton Button5;
		private System.Windows.Forms.ToolBarButton Button6;
		private System.Windows.Forms.ToolTip ToolTip1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmCustomers()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmCustomers InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmCustomers();
				return _InstancePtr;
			}
		}
		protected static frmCustomers _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCustomers));
			this.components = new System.ComponentModel.Container();
			this.txtField = new Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray();
			this.dcCustomers = new Microsoft.VisualBasic.Compatibility.VB6.ADODC();
			this.Frame1 = new System.Windows.Forms.GroupBox();
			this.txtField_4 = new System.Windows.Forms.TextBox();
			this.txtField_0 = new System.Windows.Forms.TextBox();
			this.txtField_6 = new System.Windows.Forms.TextBox();
			this.txtField_7 = new System.Windows.Forms.TextBox();
			this.txtField_2 = new System.Windows.Forms.TextBox();
			this.txtField_1 = new System.Windows.Forms.TextBox();
			this.txtField_3 = new System.Windows.Forms.TextBox();
			this.txtField_5 = new System.Windows.Forms.TextBox();
			this.Frame2 = new System.Windows.Forms.GroupBox();
			this.txtField_11 = new System.Windows.Forms.TextBox();
			this.txtField_13 = new System.Windows.Forms.TextBox();
			this.txtField_12 = new System.Windows.Forms.TextBox();
			this.Label7 = new System.Windows.Forms.Label();
			this.Label3 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.txtField_8 = new System.Windows.Forms.TextBox();
			this.txtField_10 = new System.Windows.Forms.TextBox();
			this.txtField_14 = new System.Windows.Forms.TextBox();
			this.txtField_9 = new System.Windows.Forms.TextBox();
			this.Label15 = new System.Windows.Forms.Label();
			this.Label14 = new System.Windows.Forms.Label();
			this.Label13 = new System.Windows.Forms.Label();
			this.Label12 = new System.Windows.Forms.Label();
			this.Label11 = new System.Windows.Forms.Label();
			this.Label10 = new System.Windows.Forms.Label();
			this.Label9 = new System.Windows.Forms.Label();
			this.Label8 = new System.Windows.Forms.Label();
			this.Label6 = new System.Windows.Forms.Label();
			this.Label5 = new System.Windows.Forms.Label();
			this.Label4 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.ImageList1 = new System.Windows.Forms.ImageList();
			this.Toolbar1 = new System.Windows.Forms.ToolBar();
			this.Button1 = new System.Windows.Forms.ToolBarButton();
			this.Button2 = new System.Windows.Forms.ToolBarButton();
			this.Button3 = new System.Windows.Forms.ToolBarButton();
			this.Button4 = new System.Windows.Forms.ToolBarButton();
			this.Button5 = new System.Windows.Forms.ToolBarButton();
			this.Button6 = new System.Windows.Forms.ToolBarButton();
			this.ToolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtField)).BeginInit();
			//
			// dcCustomers
			//
			this.dcCustomers.Name = "dcCustomers";
			this.dcCustomers.Enabled = true;
			this.dcCustomers.Location = new System.Drawing.Point(8, 404);
			this.dcCustomers.Size = new System.Drawing.Size(179, 22);
			this.dcCustomers.Text = "Customers";
			this.dcCustomers.BackColor = System.Drawing.SystemColors.Window;
			this.dcCustomers.ForeColor = System.Drawing.SystemColors.WindowText;
			this.dcCustomers.Orientation = ADODC.OrientationEnum.adHorizontal;
			this.dcCustomers.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
			this.dcCustomers.ConnectionTimeout = 15;
			this.dcCustomers.CommandTimeout = 30;
			this.dcCustomers.CursorType = ADODB.CursorTypeEnum.adOpenStatic;
			this.dcCustomers.LockType = ADODB.LockTypeEnum.adLockOptimistic; //VBto.Stub_ADODB_LockTypeEnum_adLockOptimistic;
			this.dcCustomers.CommandType = ADODB.CommandTypeEnum.adCmdTable;
			this.dcCustomers.CacheSize = 50;
			this.dcCustomers.MaxRecords = 0;
			this.dcCustomers.BOFAction = ADODC.BOFActionEnum.adDoMoveFirst;
			this.dcCustomers.EOFAction = ADODC.EOFActionEnum.adDoMoveLast;
			this.dcCustomers.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Orders.mdb;Persist Security Info=False";
			this.dcCustomers.UserName = "";
			this.dcCustomers.RecordSource = "Customers";
			this.dcCustomers.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Regular), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// Frame1
			//
			this.Frame1.Controls.Add(this.txtField_4);
			this.Frame1.Controls.Add(this.txtField_0);
			this.Frame1.Controls.Add(this.txtField_6);
			this.Frame1.Controls.Add(this.txtField_7);
			this.Frame1.Controls.Add(this.txtField_2);
			this.Frame1.Controls.Add(this.txtField_1);
			this.Frame1.Controls.Add(this.txtField_3);
			this.Frame1.Controls.Add(this.txtField_5);
			this.Frame1.Controls.Add(this.Frame2);
			this.Frame1.Controls.Add(this.txtField_8);
			this.Frame1.Controls.Add(this.txtField_10);
			this.Frame1.Controls.Add(this.txtField_14);
			this.Frame1.Controls.Add(this.txtField_9);
			this.Frame1.Controls.Add(this.Label15);
			this.Frame1.Controls.Add(this.Label14);
			this.Frame1.Controls.Add(this.Label13);
			this.Frame1.Controls.Add(this.Label12);
			this.Frame1.Controls.Add(this.Label11);
			this.Frame1.Controls.Add(this.Label10);
			this.Frame1.Controls.Add(this.Label9);
			this.Frame1.Controls.Add(this.Label8);
			this.Frame1.Controls.Add(this.Label6);
			this.Frame1.Controls.Add(this.Label5);
			this.Frame1.Controls.Add(this.Label4);
			this.Frame1.Controls.Add(this.Label1);
			this.Frame1.Name = "Frame1";
			this.Frame1.TabIndex = 16;
			this.Frame1.Location = new System.Drawing.Point(8, 49);
			this.Frame1.Size = new System.Drawing.Size(438, 349);
			this.Frame1.Text = "Customer information";
			this.Frame1.BackColor = System.Drawing.SystemColors.Control;
			this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// txtField_4
			//
			this.txtField_4.Name = "txtField_4";
			this.txtField_4.TabIndex = 7;
			this.txtField_4.Location = new System.Drawing.Point(105, 149);
			this.txtField_4.Size = new System.Drawing.Size(106, 20);
			this.txtField_4.Text = "";
			this.txtField_4.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_4.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_0
			//
			this.txtField_0.Name = "txtField_0";
			this.txtField_0.TabIndex = 0;
			this.txtField_0.Location = new System.Drawing.Point(105, 24);
			this.txtField_0.Size = new System.Drawing.Size(106, 20);
			this.txtField_0.Text = "";
			this.txtField_0.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_0.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_6
			//
			this.txtField_6.Name = "txtField_6";
			this.txtField_6.TabIndex = 9;
			this.txtField_6.Location = new System.Drawing.Point(105, 211);
			this.txtField_6.Size = new System.Drawing.Size(106, 20);
			this.txtField_6.Text = "";
			this.txtField_6.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_6.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_7
			//
			this.txtField_7.Name = "txtField_7";
			this.txtField_7.TabIndex = 10;
			this.txtField_7.Location = new System.Drawing.Point(105, 243);
			this.txtField_7.Size = new System.Drawing.Size(106, 20);
			this.txtField_7.Text = "";
			this.txtField_7.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_7.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_2
			//
			this.txtField_2.Name = "txtField_2";
			this.txtField_2.TabIndex = 2;
			this.txtField_2.Location = new System.Drawing.Point(105, 87);
			this.txtField_2.Size = new System.Drawing.Size(106, 20);
			this.txtField_2.Text = "";
			this.txtField_2.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_2.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_1
			//
			this.txtField_1.Name = "txtField_1";
			this.txtField_1.TabIndex = 1;
			this.txtField_1.Location = new System.Drawing.Point(105, 55);
			this.txtField_1.Size = new System.Drawing.Size(106, 20);
			this.txtField_1.Text = "";
			this.txtField_1.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_1.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_3
			//
			this.txtField_3.Name = "txtField_3";
			this.txtField_3.TabIndex = 6;
			this.txtField_3.Location = new System.Drawing.Point(105, 118);
			this.txtField_3.Size = new System.Drawing.Size(317, 20);
			this.txtField_3.Text = "";
			this.txtField_3.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_3.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_5
			//
			this.txtField_5.Name = "txtField_5";
			this.txtField_5.TabIndex = 8;
			this.txtField_5.Location = new System.Drawing.Point(105, 180);
			this.txtField_5.Size = new System.Drawing.Size(106, 20);
			this.txtField_5.Text = "";
			this.txtField_5.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_5.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// Frame2
			//
			this.Frame2.Controls.Add(this.txtField_11);
			this.Frame2.Controls.Add(this.txtField_13);
			this.Frame2.Controls.Add(this.txtField_12);
			this.Frame2.Controls.Add(this.Label7);
			this.Frame2.Controls.Add(this.Label3);
			this.Frame2.Controls.Add(this.Label2);
			this.Frame2.Name = "Frame2";
			this.Frame2.TabIndex = 28;
			this.Frame2.Location = new System.Drawing.Point(227, 13);
			this.Frame2.Size = new System.Drawing.Size(196, 98);
			this.Frame2.Text = "Contact";
			this.Frame2.BackColor = System.Drawing.SystemColors.Control;
			this.Frame2.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// txtField_11
			//
			this.txtField_11.Name = "txtField_11";
			this.txtField_11.TabIndex = 3;
			this.txtField_11.Location = new System.Drawing.Point(65, 16);
			this.txtField_11.Size = new System.Drawing.Size(122, 20);
			this.txtField_11.Text = "";
			this.txtField_11.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_11.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_13
			//
			this.txtField_13.Name = "txtField_13";
			this.txtField_13.TabIndex = 5;
			this.txtField_13.Location = new System.Drawing.Point(65, 65);
			this.txtField_13.Size = new System.Drawing.Size(122, 20);
			this.txtField_13.Text = "";
			this.txtField_13.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_13.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_12
			//
			this.txtField_12.Name = "txtField_12";
			this.txtField_12.TabIndex = 4;
			this.txtField_12.Location = new System.Drawing.Point(65, 40);
			this.txtField_12.Size = new System.Drawing.Size(122, 20);
			this.txtField_12.Text = "";
			this.txtField_12.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_12.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// Label7
			//
			this.Label7.Name = "Label7";
			this.Label7.TabIndex = 31;
			this.Label7.Location = new System.Drawing.Point(8, 16);
			this.Label7.Size = new System.Drawing.Size(50, 17);
			this.Label7.Text = "Title:";
			this.Label7.BackColor = System.Drawing.SystemColors.Control;
			this.Label7.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label3
			//
			this.Label3.Name = "Label3";
			this.Label3.TabIndex = 30;
			this.Label3.Location = new System.Drawing.Point(8, 70);
			this.Label3.Size = new System.Drawing.Size(58, 17);
			this.Label3.Text = "Last name:";
			this.Label3.BackColor = System.Drawing.SystemColors.Control;
			this.Label3.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label2
			//
			this.Label2.Name = "Label2";
			this.Label2.TabIndex = 29;
			this.Label2.Location = new System.Drawing.Point(8, 43);
			this.Label2.Size = new System.Drawing.Size(58, 17);
			this.Label2.Text = "First name:";
			this.Label2.BackColor = System.Drawing.SystemColors.Control;
			this.Label2.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// txtField_8
			//
			this.txtField_8.Name = "txtField_8";
			this.txtField_8.TabIndex = 11;
			this.txtField_8.Location = new System.Drawing.Point(316, 181);
			this.txtField_8.Size = new System.Drawing.Size(106, 20);
			this.txtField_8.Text = "";
			this.txtField_8.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_8.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_10
			//
			this.txtField_10.Name = "txtField_10";
			this.txtField_10.TabIndex = 13;
			this.txtField_10.Location = new System.Drawing.Point(316, 243);
			this.txtField_10.Size = new System.Drawing.Size(106, 20);
			this.txtField_10.Text = "";
			this.txtField_10.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_10.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtField_14
			//
			this.txtField_14.Name = "txtField_14";
			this.txtField_14.TabIndex = 14;
			this.txtField_14.Location = new System.Drawing.Point(16, 283);
			this.txtField_14.Size = new System.Drawing.Size(406, 53);
			this.txtField_14.Text = "";
			this.txtField_14.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_14.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtField_14.Multiline = true;
			//
			// txtField_9
			//
			this.txtField_9.Name = "txtField_9";
			this.txtField_9.TabIndex = 12;
			this.txtField_9.Location = new System.Drawing.Point(316, 211);
			this.txtField_9.Size = new System.Drawing.Size(106, 20);
			this.txtField_9.Text = "";
			this.txtField_9.BackColor = System.Drawing.SystemColors.Window;
			this.txtField_9.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// Label15
			//
			this.Label15.Name = "Label15";
			this.Label15.TabIndex = 32;
			this.Label15.Location = new System.Drawing.Point(16, 149);
			this.Label15.Size = new System.Drawing.Size(90, 17);
			this.Label15.Text = "Zip code:";
			this.Label15.BackColor = System.Drawing.SystemColors.Control;
			this.Label15.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label14
			//
			this.Label14.Name = "Label14";
			this.Label14.TabIndex = 27;
			this.Label14.Location = new System.Drawing.Point(16, 243);
			this.Label14.Size = new System.Drawing.Size(90, 17);
			this.Label14.Text = "Country/Region";
			this.Label14.BackColor = System.Drawing.SystemColors.Control;
			this.Label14.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label13
			//
			this.Label13.Name = "Label13";
			this.Label13.TabIndex = 26;
			this.Label13.Location = new System.Drawing.Point(16, 211);
			this.Label13.Size = new System.Drawing.Size(90, 17);
			this.Label13.Text = "State or province:";
			this.Label13.BackColor = System.Drawing.SystemColors.Control;
			this.Label13.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label12
			//
			this.Label12.Name = "Label12";
			this.Label12.TabIndex = 25;
			this.Label12.Location = new System.Drawing.Point(16, 267);
			this.Label12.Size = new System.Drawing.Size(90, 17);
			this.Label12.Text = "Notes:";
			this.Label12.BackColor = System.Drawing.SystemColors.Control;
			this.Label12.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label11
			//
			this.Label11.Name = "Label11";
			this.Label11.TabIndex = 24;
			this.Label11.Location = new System.Drawing.Point(16, 87);
			this.Label11.Size = new System.Drawing.Size(90, 17);
			this.Label11.Text = "Email:";
			this.Label11.BackColor = System.Drawing.SystemColors.Control;
			this.Label11.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label10
			//
			this.Label10.Name = "Label10";
			this.Label10.TabIndex = 23;
			this.Label10.Location = new System.Drawing.Point(235, 243);
			this.Label10.Size = new System.Drawing.Size(90, 17);
			this.Label10.Text = "Fax number:";
			this.Label10.BackColor = System.Drawing.SystemColors.Control;
			this.Label10.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label9
			//
			this.Label9.Name = "Label9";
			this.Label9.TabIndex = 22;
			this.Label9.Location = new System.Drawing.Point(235, 211);
			this.Label9.Size = new System.Drawing.Size(90, 17);
			this.Label9.Text = "Extension:";
			this.Label9.BackColor = System.Drawing.SystemColors.Control;
			this.Label9.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label8
			//
			this.Label8.Name = "Label8";
			this.Label8.TabIndex = 21;
			this.Label8.Location = new System.Drawing.Point(235, 181);
			this.Label8.Size = new System.Drawing.Size(90, 17);
			this.Label8.Text = "Phone number:";
			this.Label8.BackColor = System.Drawing.SystemColors.Control;
			this.Label8.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label6
			//
			this.Label6.Name = "Label6";
			this.Label6.TabIndex = 20;
			this.Label6.Location = new System.Drawing.Point(16, 180);
			this.Label6.Size = new System.Drawing.Size(90, 17);
			this.Label6.Text = "City:";
			this.Label6.BackColor = System.Drawing.SystemColors.Control;
			this.Label6.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label5
			//
			this.Label5.Name = "Label5";
			this.Label5.TabIndex = 19;
			this.Label5.Location = new System.Drawing.Point(16, 118);
			this.Label5.Size = new System.Drawing.Size(90, 17);
			this.Label5.Text = "Billing address:";
			this.Label5.BackColor = System.Drawing.SystemColors.Control;
			this.Label5.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label4
			//
			this.Label4.Name = "Label4";
			this.Label4.TabIndex = 18;
			this.Label4.Location = new System.Drawing.Point(16, 55);
			this.Label4.Size = new System.Drawing.Size(90, 17);
			this.Label4.Text = "Department:";
			this.Label4.BackColor = System.Drawing.SystemColors.Control;
			this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label1
			//
			this.Label1.Name = "Label1";
			this.Label1.TabIndex = 17;
			this.Label1.Location = new System.Drawing.Point(16, 24);
			this.Label1.Size = new System.Drawing.Size(90, 17);
			this.Label1.Text = "Company Name:";
			this.Label1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// ImageList1
			//
			this.ImageList1.ImageSize = new System.Drawing.Size(16, 16);
			this.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.ImageList1.TransparentColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(255)));
			this.ImageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageList1.ImageStream")));
			//
			// Toolbar1
			//
			this.Toolbar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {this.Button1, this.Button2, this.Button3, this.Button4, this.Button5, this.Button6});
			this.Toolbar1.Name = "Toolbar1";
			this.Toolbar1.TabIndex = 15;
			this.Toolbar1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.Toolbar1.ButtonSize = new System.Drawing.Size(16, 16);
			this.Toolbar1.ImageList = this.ImageList1;
			this.Toolbar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.Toolbar1_ButtonClick);
			//
			// Button1
			//
			this.Button1.Name = "Button1";
			this.Button1.ImageIndex = 0;
			this.Button1.Text = "Add";
			this.Button1.ToolTipText = "Create a new record";
			this.Button1.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button2
			//
			this.Button2.Name = "Button2";
			this.Button2.ImageIndex = 1;
			this.Button2.Text = "Edit";
			this.Button2.ToolTipText = "Edit this record";
			this.Button2.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button3
			//
			this.Button3.Name = "Button3";
			this.Button3.ImageIndex = 2;
			this.Button3.Text = "Save";
			this.Button3.ToolTipText = "Save the current changes";
			this.Button3.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button4
			//
			this.Button4.Name = "Button4";
			this.Button4.ImageIndex = 3;
			this.Button4.Text = "Delete";
			this.Button4.ToolTipText = "Delete the current record";
			this.Button4.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button5
			//
			this.Button5.Name = "Button5";
			this.Button5.ImageIndex = 4;
			this.Button5.Text = "Search";
			this.Button5.ToolTipText = "Search for a record";
			this.Button5.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// Button6
			//
			this.Button6.Name = "Button6";
			this.Button6.Text = "Cancel";
			this.Button6.ToolTipText = "Cancel edited changes";
			this.Button6.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton;
			//
			// frmCustomers
			//
			this.ClientSize = new System.Drawing.Size(459, 448);
			this.Controls.Add(this.dcCustomers);
			this.Controls.Add(this.Frame1);
			this.Controls.Add(this.Toolbar1);
			this.Name = "frmCustomers";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.MinimizeBox = true;
			this.MaximizeBox = true;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmCustomers_FormClosing);
			this.Load += new System.EventHandler(this.frmCustomers_Load);
			this.Text = "Customers";
			this.txtField.TextChanged += new System.EventHandler(this.txtField_TextChanged);
			this.txtField.SetIndex( txtField_4, System.Convert.ToInt16( 4 ) );
			this.txtField.SetIndex( txtField_0, System.Convert.ToInt16( 0 ) );
			this.txtField.SetIndex( txtField_6, System.Convert.ToInt16( 6 ) );
			this.txtField.SetIndex( txtField_7, System.Convert.ToInt16( 7 ) );
			this.txtField.SetIndex( txtField_2, System.Convert.ToInt16( 2 ) );
			this.txtField.SetIndex( txtField_1, System.Convert.ToInt16( 1 ) );
			this.txtField.SetIndex( txtField_3, System.Convert.ToInt16( 3 ) );
			this.txtField.SetIndex( txtField_5, System.Convert.ToInt16( 5 ) );
			this.txtField.SetIndex( txtField_11, System.Convert.ToInt16( 11 ) );
			this.txtField.SetIndex( txtField_13, System.Convert.ToInt16( 13 ) );
			this.txtField.SetIndex( txtField_12, System.Convert.ToInt16( 12 ) );
			this.txtField.SetIndex( txtField_8, System.Convert.ToInt16( 8 ) );
			this.txtField.SetIndex( txtField_10, System.Convert.ToInt16( 10 ) );
			this.txtField.SetIndex( txtField_14, System.Convert.ToInt16( 14 ) );
			this.txtField.SetIndex( txtField_9, System.Convert.ToInt16( 9 ) );
			((System.ComponentModel.ISupportInitialize)(this.txtField)).EndInit();
			this.Frame2.ResumeLayout(false);
			this.Frame1.ResumeLayout(false);
			this.Toolbar1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================

		private bool NewMode;
		private bool EditMode;
		private bool CancellingMode;
		public string CurrentCustomerID = "";

		private void Form_Unload(ref short Cancel)
		{
			CurrentCustomerID = Convert.ToString(dcCustomers.Recordset.Fields["CustomerId"].Value);
		}

		private void frmCustomers_FormClosing(object sender, FormClosingEventArgs e)
		{
			short Cancel = 0;
			Form_Unload(ref Cancel);
			if (Cancel != 0) e.Cancel = true;
		}


		// Private Sub dcCustomers_MoveComplete(ByVal adReason As ADODB.EventReasonEnum, ByVal pError As ADODB.Error, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)
		// NewMode = False
		// EditMode = False
		// CancellingMode = False
		// End Sub

		// Private Sub dcCustomers_WillMove(ByVal adReason As ADODB.EventReasonEnum, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)
		// CancellingMode = True
		// End Sub

		private void frmCustomers_Load(object sender, System.EventArgs e)
		{
			InitForm();
		}

		public void InitForm()
		{
			dcCustomers.ConnectionString = modMain.ConnectionString;
			NewMode = false;
			EditMode = false;
			CancellingMode = false;
		}

		private void Toolbar1_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			ToolBarButton Button = e.Button;

			object x/*unused?*/;
			switch (Button.Text) {
				
				case "Add":
				{
					// Add new record
					NewMode = true;
					dcCustomers.Recordset.AddNew();
					break;
				}
				case "Edit":
				{
					// Edit mode
					EditMode = true;
					break;
				}
				case "Save":
				{
					// Save data
					dcCustomers.Recordset.Update();
					EditMode = false;
					NewMode = false;
					break;
				}
				case "Delete":
				{
					// Delete record
					if (MessageBox.Show("Are you sure you want to delete this record?", "Delete record", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes) {
						dcCustomers.Recordset.Delete();
						dcCustomers.Recordset.Requery();
					}
					break;
				}
				case "Search":
				{
					// Search for records
					modFunctions.SearchShow("Customers", "CompanyName", "customer");
					break;
				}
				case "Cancel":
				{
					CancellingMode = true;
					// Cancel edited changes
					EditMode = false;
					NewMode = false;
					dcCustomers.Recordset.CancelUpdate();
					dcCustomers.Recordset.Requery();
					CancellingMode = false;
					Close();
					break;
				}
			} //end switch
		}

		private void txtField_TextChanged(short Index, object sender, System.EventArgs e)
		{
			if (!CancellingMode) {
				EditMode = true;
			}
		}
		private void txtField_TextChanged(object sender, System.EventArgs e)
		{
			short index = txtField.GetIndex((TextBox)sender);
			txtField_TextChanged(index, sender, e);
		}

		// Used already in frmSearch
#if defUse_SearchCriteriaProducts
		public void SearchCriteriaProducts(string field, string mvalue)
		{
			modConnection.ExecuteSql("Select * from Customers where "+field+" LIKE '"+mvalue+"%'");
			if (modConnection.rs.RecordCount==0) {
				MessageBox.Show("There are no records with the selected criteria", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information);
			} else {
				modMain.LogStatus("There are "+Convert.ToString(modConnection.rs.RecordCount)+" that meet with the selected criteria");
				dcCustomers.Recordset = modConnection.rs;
			}
		}
#endif

	}
}