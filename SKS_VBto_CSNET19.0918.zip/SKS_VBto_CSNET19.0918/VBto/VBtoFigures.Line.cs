﻿// This is a part of the VBto Converter (www.vbto.net). Copyright (C) 2005-2016 StressSoft Company Ltd. All rights reserved.
// version 1.1	2016.10.21

using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.Compatibility.VB6;

namespace VBtoFigures
{

    [Browsable(false)]
    public partial class TransparentControl : UserControl
    {

        public TransparentControl()
        {
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            SetStyle(ControlStyles.Opaque, true);
            //InitializeComponent()
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle = cp.ExStyle | 0x20;
                return cp;
            }
        }

    }

    public partial class Line : TransparentControl
    {

        public Line()
        {
            Paint += VBtoLine_Paint;
            _X1 = 0; _Y1 = 0;
            _X2 = 0; _Y2 = 0;
        }

        public Line(IContainer container)
        {
            Paint += VBtoLine_Paint;
            _X1 = 0; _Y1 = 0;
            _X2 = 0; _Y2 = 0;
            container.Add(this);
        }

        private void VBtoLine_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            e.Graphics.DrawLine(mPen, _X1 - Left, _Y1 - Top, _X2 - Left, _Y2 - Top);
        }

        #region "Pen"

        private Color mLineColor = Color.Black;
        [Browsable(true)]
        public Color LineColor
        {
            get { return mLineColor; }
            set { mLineColor = value; RefreshPen(); }
        }

        private DashStyle mLineStyle = DashStyle.Solid;
        [Browsable(true)]
        public new DashStyle LineStyle
        {
            get { return mLineStyle; }
            set { mLineStyle = value; RefreshPen(); }
        }

        private int mLineWidth = 1;
        [Browsable(true)]
        public int LineWidth
        {
            get { return mLineWidth; }
            set { mLineWidth = value; RefreshPen(); }
        }

        private Pen mPen = Pens.Black;
        private void RefreshPen()
        {
            mPen = new Pen(mLineColor, mLineWidth);
            mPen.DashStyle = mLineStyle;
            if (Parent != null)
            {
                Parent.Invalidate(new Rectangle(Left, Top, Width, Height), true);
            }
        }

        #endregion

        #region "X1,Y1, X2,Y2"

        private float _X1, _Y1, _X2, _Y2;
        private void ResetX()
        {
            if (_X1 < _X2)
            {
                Width = (int)(_X2 - _X1);
                Left = (int)_X1;
            }
            else
            {
                Width = (int)(_X1 - _X2);
                Left = (int)_X2;
            }
            if (Width < LineWidth)
                Width = LineWidth;
            Refresh();
        }
        private void ResetY()
        {
            if (_Y1 < _Y2)
            {
                Height = (int)(_Y2 - _Y1);
                Top = (int)_Y1;
            }
            else
            {
                Height = (int)(_Y1 - _Y2);
                Top = (int)_Y2;
            }
            if (Height < LineWidth)
                Height = LineWidth;
            Refresh();
        }

        [Browsable(true)]
        public float X1 { get { return _X1; } set { _X1 = value; ResetX(); } }
        [Browsable(true)]
        public float Y1 { get { return _Y1; } set { _Y1 = value; ResetY(); } }
        [Browsable(true)]
        public float X2 { get { return _X2; } set { _X2 = value; ResetX(); } }
        [Browsable(true)]
        public float Y2 { get { return _Y2; } set { _Y2 = value; ResetY(); } }

        #endregion

    } //end class Line

    [ProvideProperty("Index", typeof(Line))]
    public class LineArray : BaseControlArray, IExtenderProvider
    {
        private EventHandler ClickEvent;
        private EventHandler DoubleClickEvent;
        private MouseEventHandler MouseClickEvent;
        private MouseEventHandler MouseDoubleClickEvent;
        private MouseEventHandler MouseDownEvent;
        private EventHandler MouseEnterEvent;
        private EventHandler MouseHoverEvent;
        private EventHandler MouseLeaveEvent;
        private MouseEventHandler MouseMoveEvent;
        private MouseEventHandler MouseUpEvent;

        public event EventHandler Click
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                ClickEvent = (EventHandler)Delegate.Combine(ClickEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                ClickEvent = (EventHandler)Delegate.Remove(ClickEvent, value);
            }
        }
        public event EventHandler DoubleClick
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                DoubleClickEvent = (EventHandler)Delegate.Combine(DoubleClickEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                DoubleClickEvent = (EventHandler)Delegate.Remove(DoubleClickEvent, value);
            }
        }
        public event MouseEventHandler MouseClick
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                MouseClickEvent = (MouseEventHandler)Delegate.Combine(MouseClickEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                MouseClickEvent = (MouseEventHandler)Delegate.Remove(MouseClickEvent, value);
            }
        }
        public event MouseEventHandler MouseDoubleClick
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                MouseDoubleClickEvent = (MouseEventHandler)Delegate.Combine(MouseDoubleClickEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                MouseDoubleClickEvent = (MouseEventHandler)Delegate.Remove(MouseDoubleClickEvent, value);
            }
        }
        public event MouseEventHandler MouseDown
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                MouseDownEvent = (MouseEventHandler)Delegate.Combine(MouseDownEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                MouseDownEvent = (MouseEventHandler)Delegate.Remove(MouseDownEvent, value);
            }
        }
        public event EventHandler MouseEnter
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                MouseEnterEvent = (EventHandler)Delegate.Combine(MouseEnterEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                MouseEnterEvent = (EventHandler)Delegate.Remove(MouseEnterEvent, value);
            }
        }
        public event EventHandler MouseHover
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                MouseHoverEvent = (EventHandler)Delegate.Combine(MouseHoverEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                MouseHoverEvent = (EventHandler)Delegate.Remove(MouseHoverEvent, value);
            }
        }
        public event EventHandler MouseLeave
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                MouseLeaveEvent = (EventHandler)Delegate.Combine(MouseLeaveEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                MouseLeaveEvent = (EventHandler)Delegate.Remove(MouseLeaveEvent, value);
            }
        }
        public event MouseEventHandler MouseMove
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                MouseMoveEvent = (MouseEventHandler)Delegate.Combine(MouseMoveEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                MouseMoveEvent = (MouseEventHandler)Delegate.Remove(MouseMoveEvent, value);
            }
        }
        public event MouseEventHandler MouseUp
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            add
            {
                MouseUpEvent = (MouseEventHandler)Delegate.Combine(MouseUpEvent, value);
            }
            [MethodImpl(MethodImplOptions.Synchronized)]
            remove
            {
                MouseUpEvent = (MouseEventHandler)Delegate.Remove(MouseUpEvent, value);
            }
        }


        public Line this[short Index]
        {
            get { return (Line)BaseGetItem(Index); }
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        bool IExtenderProvider.CanExtend(object target)
        {
            if (target is Line)
            {
                return BaseCanExtend(RuntimeHelpers.GetObjectValue(target));
            }
            return false;
        }

        public short GetIndex(Line pLine)
        {
            return BaseGetIndex(pLine);
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        public void SetIndex(Line pLine, short Index)
        {
            BaseSetIndex(pLine, Index, false);
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        public bool ShouldSerializeIndex(Line pLine)
        {
            return BaseShouldSerializeIndex(pLine);
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        public void ResetIndex(Line pLine)
        {
            BaseResetIndex(pLine);
        }

        public LineArray()
        {
        }

        public LineArray(IContainer Container)
            : base(Container)
        {
        }

        protected override void HookUpControlEvents(object obj)
        {
            Line pLine = (Line)obj;
            if (ClickEvent != null) pLine.Click += ClickEvent;
            if (DoubleClickEvent != null) pLine.DoubleClick += DoubleClickEvent;
            if (MouseClickEvent != null) pLine.MouseClick += MouseClickEvent;
            if (MouseDoubleClickEvent != null) pLine.MouseDoubleClick += MouseDoubleClickEvent;
            if (MouseDownEvent != null) pLine.MouseDown += MouseDownEvent;
            if (MouseEnterEvent != null) pLine.MouseEnter += MouseEnterEvent;
            if (MouseHoverEvent != null) pLine.MouseHover += MouseHoverEvent;
            if (MouseLeaveEvent != null) pLine.MouseLeave += MouseLeaveEvent;
            if (MouseMoveEvent != null) pLine.MouseMove += MouseMoveEvent;
            if (MouseUpEvent != null) pLine.MouseUp += MouseUpEvent;
        }

        protected override Type GetControlInstanceType()
        {
            return typeof(Line);
        }

        public new int UBound()
        {
            int nCount = Count();
            if (nCount > 0) return base.UBound();
            return 0;
        }

        public new void Load(short Index)
        {
            BaseSetIndex(new Line(), Index, true);
        }

        public void Add(Line pLine, short index)
        {
            BaseSetIndex(pLine, index, true);
        }

    } //end class LineArray

}
