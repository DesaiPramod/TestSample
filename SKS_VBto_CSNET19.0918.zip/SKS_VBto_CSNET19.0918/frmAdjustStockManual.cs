using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace SKS
{
	/// <summary>
	/// Summary description for frmAdjustStockManual.
	/// </summary>
	public class frmAdjustStockManual : System.Windows.Forms.Form
	{
		public Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray txtValues;
		public System.Windows.Forms.StatusBar sbStatusBar;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel1;
		public System.Windows.Forms.TextBox txtStockID;
		public System.Windows.Forms.TextBox txtOriginalPrice;
		public System.Windows.Forms.TextBox txtValues_0;
		public System.Windows.Forms.TextBox txtQuantityPerUnit;
		public System.Windows.Forms.TextBox txtProductName;
		public System.Windows.Forms.TextBox txtUnit;
		public System.Windows.Forms.TextBox txtValues_1;
		public System.Windows.Forms.TextBox txtOriginalQuantity;
		public System.Windows.Forms.GroupBox Frame3;
		public System.Windows.Forms.ListView lvStocks;
		private System.Windows.Forms.ColumnHeader lvStocksColumnHeader0;
		private System.Windows.Forms.ColumnHeader lvStocksColumnHeader1;
		private System.Windows.Forms.ColumnHeader lvStocksColumnHeader2;
		private System.Windows.Forms.ColumnHeader lvStocksColumnHeader3;
		private System.Windows.Forms.ColumnHeader lvStocksColumnHeader4;
		private System.Windows.Forms.ColumnHeader lvStocksColumnHeader5;
		private System.Windows.Forms.ColumnHeader lvStocksColumnHeader6;
		private System.Windows.Forms.ColumnHeader lvStocksColumnHeader7;
		public System.Windows.Forms.GroupBox Frame1;
		public System.Windows.Forms.TextBox txtCode;
		public System.Windows.Forms.TextBox txtName;
		public System.Windows.Forms.Button cmdProducts;
		public System.Windows.Forms.Label Label5;
		public System.Windows.Forms.Label Label4;
		public System.Windows.Forms.Button cmdClose;
		public System.Windows.Forms.Button cmdSave;
		public System.Windows.Forms.ListView lvProducts;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader0;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader1;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader2;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader3;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader4;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader5;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader6;
		public System.Windows.Forms.Label Label14;
		public System.Windows.Forms.Label lblNewQuantity;
		public System.Windows.Forms.Label Label12;
		public System.Windows.Forms.Label lblCurrentQuantity;
		public System.Windows.Forms.Label Label11;
		public System.Windows.Forms.Label Label10;
		public System.Windows.Forms.Label Label8;
		public System.Windows.Forms.Label Label9;
		public System.Windows.Forms.Label Label7;
		public System.Windows.Forms.Label Label6;
		public System.Windows.Forms.Label Label2;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.Label Label3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmAdjustStockManual()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmAdjustStockManual InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmAdjustStockManual();
				return _InstancePtr;
			}
		}
		protected static frmAdjustStockManual _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAdjustStockManual));
			this.components = new System.ComponentModel.Container();
			this.txtValues = new Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray();
			this.sbStatusBar = new System.Windows.Forms.StatusBar();
			this.sbStatusBar_Panel1 = new System.Windows.Forms.StatusBarPanel();
			this.txtStockID = new System.Windows.Forms.TextBox();
			this.txtOriginalPrice = new System.Windows.Forms.TextBox();
			this.txtValues_0 = new System.Windows.Forms.TextBox();
			this.txtQuantityPerUnit = new System.Windows.Forms.TextBox();
			this.txtProductName = new System.Windows.Forms.TextBox();
			this.txtUnit = new System.Windows.Forms.TextBox();
			this.txtValues_1 = new System.Windows.Forms.TextBox();
			this.txtOriginalQuantity = new System.Windows.Forms.TextBox();
			this.Frame3 = new System.Windows.Forms.GroupBox();
			this.lvStocks = new System.Windows.Forms.ListView();
			this.lvStocksColumnHeader0 = new System.Windows.Forms.ColumnHeader();
			this.lvStocksColumnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.lvStocksColumnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.lvStocksColumnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.lvStocksColumnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.lvStocksColumnHeader5 = new System.Windows.Forms.ColumnHeader();
			this.lvStocksColumnHeader6 = new System.Windows.Forms.ColumnHeader();
			this.lvStocksColumnHeader7 = new System.Windows.Forms.ColumnHeader();
			this.Frame1 = new System.Windows.Forms.GroupBox();
			this.txtCode = new System.Windows.Forms.TextBox();
			this.txtName = new System.Windows.Forms.TextBox();
			this.cmdProducts = new System.Windows.Forms.Button();
			this.Label5 = new System.Windows.Forms.Label();
			this.Label4 = new System.Windows.Forms.Label();
			this.cmdClose = new System.Windows.Forms.Button();
			this.cmdSave = new System.Windows.Forms.Button();
			this.lvProducts = new System.Windows.Forms.ListView();
			this.lvProductsColumnHeader0 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader5 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader6 = new System.Windows.Forms.ColumnHeader();
			this.Label14 = new System.Windows.Forms.Label();
			this.lblNewQuantity = new System.Windows.Forms.Label();
			this.Label12 = new System.Windows.Forms.Label();
			this.lblCurrentQuantity = new System.Windows.Forms.Label();
			this.Label11 = new System.Windows.Forms.Label();
			this.Label10 = new System.Windows.Forms.Label();
			this.Label8 = new System.Windows.Forms.Label();
			this.Label9 = new System.Windows.Forms.Label();
			this.Label7 = new System.Windows.Forms.Label();
			this.Label6 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.Label3 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtValues)).BeginInit();
			//
			// sbStatusBar
			//
			this.sbStatusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {this.sbStatusBar_Panel1});
			this.sbStatusBar.Name = "sbStatusBar";
			this.sbStatusBar.TabIndex = 28;
			this.sbStatusBar.Location = new System.Drawing.Point(0, 544);
			this.sbStatusBar.Size = new System.Drawing.Size(431, 25);
			this.sbStatusBar.ShowPanels = true;
			this.sbStatusBar.SizingGrip = false;
			//
			// Panel1
			//
			this.sbStatusBar_Panel1.Text = "";
			this.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbStatusBar_Panel1.Width = 429;
			//
			// txtStockID
			//
			this.txtStockID.Name = "txtStockID";
			this.txtStockID.TabStop = false;
			this.txtStockID.TabIndex = 26;
			this.txtStockID.Location = new System.Drawing.Point(97, 378);
			this.txtStockID.Size = new System.Drawing.Size(82, 20);
			this.txtStockID.Text = "";
			this.txtStockID.BackColor = System.Drawing.SystemColors.Menu;
			this.txtStockID.ForeColor = System.Drawing.SystemColors.WindowText;
			//
			// txtOriginalPrice
			//
			this.txtOriginalPrice.Name = "txtOriginalPrice";
			this.txtOriginalPrice.TabStop = false;
			this.txtOriginalPrice.TabIndex = 25;
			this.txtOriginalPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtOriginalPrice.Location = new System.Drawing.Point(97, 407);
			this.txtOriginalPrice.Size = new System.Drawing.Size(82, 20);
			this.txtOriginalPrice.Text = "";
			this.txtOriginalPrice.BackColor = System.Drawing.SystemColors.Menu;
			this.txtOriginalPrice.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtOriginalPrice.ReadOnly = true;
			//
			// txtValues_0
			//
			this.txtValues_0.Name = "txtValues_0";
			this.txtValues_0.TabIndex = 4;
			this.txtValues_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtValues_0.Location = new System.Drawing.Point(332, 407);
			this.txtValues_0.Size = new System.Drawing.Size(82, 20);
			this.txtValues_0.Text = "";
			this.txtValues_0.BackColor = System.Drawing.SystemColors.Window;
			this.txtValues_0.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtValues_0.ReadOnly = true;
			//
			// txtQuantityPerUnit
			//
			this.txtQuantityPerUnit.Name = "txtQuantityPerUnit";
			this.txtQuantityPerUnit.TabStop = false;
			this.txtQuantityPerUnit.TabIndex = 21;
			this.txtQuantityPerUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtQuantityPerUnit.Location = new System.Drawing.Point(332, 378);
			this.txtQuantityPerUnit.Size = new System.Drawing.Size(82, 20);
			this.txtQuantityPerUnit.Text = "";
			this.txtQuantityPerUnit.BackColor = System.Drawing.SystemColors.Menu;
			this.txtQuantityPerUnit.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtQuantityPerUnit.ReadOnly = true;
			//
			// txtProductName
			//
			this.txtProductName.Name = "txtProductName";
			this.txtProductName.TabStop = false;
			this.txtProductName.TabIndex = 20;
			this.txtProductName.Location = new System.Drawing.Point(97, 348);
			this.txtProductName.Size = new System.Drawing.Size(147, 20);
			this.txtProductName.Text = "";
			this.txtProductName.BackColor = System.Drawing.SystemColors.Menu;
			this.txtProductName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtProductName.ReadOnly = true;
			//
			// txtUnit
			//
			this.txtUnit.Name = "txtUnit";
			this.txtUnit.TabStop = false;
			this.txtUnit.TabIndex = 19;
			this.txtUnit.Location = new System.Drawing.Point(332, 348);
			this.txtUnit.Size = new System.Drawing.Size(82, 20);
			this.txtUnit.Text = "";
			this.txtUnit.BackColor = System.Drawing.SystemColors.Menu;
			this.txtUnit.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtUnit.ReadOnly = true;
			//
			// txtValues_1
			//
			this.txtValues_1.Name = "txtValues_1";
			this.txtValues_1.TabIndex = 5;
			this.txtValues_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtValues_1.Location = new System.Drawing.Point(332, 437);
			this.txtValues_1.Size = new System.Drawing.Size(82, 20);
			this.txtValues_1.Text = "";
			this.txtValues_1.BackColor = System.Drawing.SystemColors.Window;
			this.txtValues_1.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtValues_1.ReadOnly = true;
			//
			// txtOriginalQuantity
			//
			this.txtOriginalQuantity.Name = "txtOriginalQuantity";
			this.txtOriginalQuantity.TabStop = false;
			this.txtOriginalQuantity.TabIndex = 14;
			this.txtOriginalQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtOriginalQuantity.Location = new System.Drawing.Point(97, 437);
			this.txtOriginalQuantity.Size = new System.Drawing.Size(82, 20);
			this.txtOriginalQuantity.Text = "";
			this.txtOriginalQuantity.BackColor = System.Drawing.SystemColors.Menu;
			this.txtOriginalQuantity.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtOriginalQuantity.ReadOnly = true;
			//
			// Frame3
			//
			this.Frame3.Controls.Add(this.lvStocks);
			this.Frame3.Name = "Frame3";
			this.Frame3.TabIndex = 13;
			this.Frame3.Location = new System.Drawing.Point(8, 202);
			this.Frame3.Size = new System.Drawing.Size(414, 139);
			this.Frame3.Text = "Stocks for the product ";
			this.Frame3.BackColor = System.Drawing.SystemColors.Control;
			this.Frame3.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// lvStocks
			//
			this.lvStocks.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {this.lvStocksColumnHeader0, this.lvStocksColumnHeader1, this.lvStocksColumnHeader2, this.lvStocksColumnHeader3, this.lvStocksColumnHeader4, this.lvStocksColumnHeader5, this.lvStocksColumnHeader6, this.lvStocksColumnHeader7});
			this.lvStocks.Name = "lvStocks";
			this.lvStocks.TabIndex = 3;
			this.lvStocks.Location = new System.Drawing.Point(8, 16);
			this.lvStocks.Size = new System.Drawing.Size(397, 114);
			this.lvStocks.BackColor = System.Drawing.SystemColors.Window;
			this.lvStocks.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lvStocks.View = System.Windows.Forms.View.Details;
			this.lvStocks.MultiSelect = false;
			this.lvStocks.GridLines = true;
			this.lvStocks.FullRowSelect = true;
			this.lvStocks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lvStocks.HideSelection = false;
			this.lvStocks.SelectedIndexChanged += new System.EventHandler(this.lvStocks_SelectedIndexChanged);
			//
			// ColumnHeader(1)
			//
			this.lvStocksColumnHeader0.Text = "Stock ID";
			this.lvStocksColumnHeader0.Width = 98;
			//
			// ColumnHeader(2)
			//
			this.lvStocksColumnHeader1.Text = "Current Stock";
			this.lvStocksColumnHeader1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvStocksColumnHeader1.Width = 98;
			//
			// ColumnHeader(3)
			//
			this.lvStocksColumnHeader2.Text = "Initial Stock";
			this.lvStocksColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvStocksColumnHeader2.Width = 98;
			//
			// ColumnHeader(4)
			//
			this.lvStocksColumnHeader3.Text = "Price";
			this.lvStocksColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvStocksColumnHeader3.Width = 98;
			//
			// ColumnHeader(5)
			//
			this.lvStocksColumnHeader4.Text = "Stock Price";
			this.lvStocksColumnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvStocksColumnHeader4.Width = 98;
			//
			// ColumnHeader(6)
			//
			this.lvStocksColumnHeader5.Text = "Created";
			this.lvStocksColumnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvStocksColumnHeader5.Width = 98;
			//
			// ColumnHeader(7)
			//
			this.lvStocksColumnHeader6.Text = "Modified";
			this.lvStocksColumnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvStocksColumnHeader6.Width = 98;
			//
			// ColumnHeader(8)
			//
			this.lvStocksColumnHeader7.Text = "User";
			this.lvStocksColumnHeader7.Width = 98;
			//
			// Frame1
			//
			this.Frame1.Controls.Add(this.txtCode);
			this.Frame1.Controls.Add(this.txtName);
			this.Frame1.Controls.Add(this.cmdProducts);
			this.Frame1.Controls.Add(this.Label5);
			this.Frame1.Controls.Add(this.Label4);
			this.Frame1.Name = "Frame1";
			this.Frame1.TabIndex = 9;
			this.Frame1.Location = new System.Drawing.Point(8, 32);
			this.Frame1.Size = new System.Drawing.Size(414, 66);
			this.Frame1.Text = "Search product ";
			this.Frame1.BackColor = System.Drawing.SystemColors.Control;
			this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// txtCode
			//
			this.txtCode.Name = "txtCode";
			this.txtCode.TabIndex = 0;
			this.txtCode.Location = new System.Drawing.Point(113, 16);
			this.txtCode.Size = new System.Drawing.Size(98, 20);
			this.txtCode.Text = "";
			this.txtCode.BackColor = System.Drawing.SystemColors.Window;
			this.txtCode.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtCode.TextChanged += new System.EventHandler(this.txtCode_TextChanged);
			//
			// txtName
			//
			this.txtName.Name = "txtName";
			this.txtName.TabIndex = 1;
			this.txtName.Location = new System.Drawing.Point(113, 40);
			this.txtName.Size = new System.Drawing.Size(147, 20);
			this.txtName.Text = "";
			this.txtName.BackColor = System.Drawing.SystemColors.Window;
			this.txtName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
			//
			// cmdProducts
			//
			this.cmdProducts.Name = "cmdProducts";
			this.cmdProducts.TabStop = false;
			this.cmdProducts.TabIndex = 10;
			this.cmdProducts.Location = new System.Drawing.Point(364, 16);
			this.cmdProducts.Size = new System.Drawing.Size(25, 23);
			this.cmdProducts.Text = "...";
			this.cmdProducts.BackColor = System.Drawing.SystemColors.Control;
			this.cmdProducts.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdProducts.Click += new System.EventHandler(this.cmdProducts_Click);
			//
			// Label5
			//
			this.Label5.Name = "Label5";
			this.Label5.TabIndex = 12;
			this.Label5.Location = new System.Drawing.Point(16, 16);
			this.Label5.Size = new System.Drawing.Size(90, 17);
			this.Label5.Text = "Product code:";
			this.Label5.BackColor = System.Drawing.SystemColors.Control;
			this.Label5.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label4
			//
			this.Label4.Name = "Label4";
			this.Label4.TabIndex = 11;
			this.Label4.Location = new System.Drawing.Point(16, 40);
			this.Label4.Size = new System.Drawing.Size(90, 17);
			this.Label4.Text = "Product name:";
			this.Label4.BackColor = System.Drawing.SystemColors.Control;
			this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// cmdClose
			//
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.TabIndex = 7;
			this.cmdClose.Location = new System.Drawing.Point(348, 510);
			this.cmdClose.Size = new System.Drawing.Size(74, 25);
			this.cmdClose.Text = "&Close";
			this.cmdClose.BackColor = System.Drawing.SystemColors.Control;
			this.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			//
			// cmdSave
			//
			this.cmdSave.Name = "cmdSave";
			this.cmdSave.TabIndex = 6;
			this.cmdSave.Location = new System.Drawing.Point(267, 510);
			this.cmdSave.Size = new System.Drawing.Size(74, 25);
			this.cmdSave.Text = "&Save";
			this.cmdSave.BackColor = System.Drawing.SystemColors.Control;
			this.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
			//
			// lvProducts
			//
			this.lvProducts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {this.lvProductsColumnHeader0, this.lvProductsColumnHeader1, this.lvProductsColumnHeader2, this.lvProductsColumnHeader3, this.lvProductsColumnHeader4, this.lvProductsColumnHeader5, this.lvProductsColumnHeader6});
			this.lvProducts.Name = "lvProducts";
			this.lvProducts.TabIndex = 2;
			this.lvProducts.Location = new System.Drawing.Point(8, 105);
			this.lvProducts.Size = new System.Drawing.Size(414, 98);
			this.lvProducts.BackColor = System.Drawing.SystemColors.Window;
			this.lvProducts.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lvProducts.View = System.Windows.Forms.View.Details;
			this.lvProducts.MultiSelect = false;
			this.lvProducts.GridLines = true;
			this.lvProducts.FullRowSelect = true;
			this.lvProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lvProducts.HideSelection = false;
			this.lvProducts.SelectedIndexChanged += new System.EventHandler(this.lvProducts_SelectedIndexChanged);
			//
			// ColumnHeader(1)
			//
			this.lvProductsColumnHeader0.Text = "Code";
			this.lvProductsColumnHeader0.Width = 98;
			//
			// ColumnHeader(2)
			//
			this.lvProductsColumnHeader1.Text = "Name";
			this.lvProductsColumnHeader1.Width = 98;
			//
			// ColumnHeader(3)
			//
			this.lvProductsColumnHeader2.Text = "Price";
			this.lvProductsColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader2.Width = 98;
			//
			// ColumnHeader(4)
			//
			this.lvProductsColumnHeader3.Text = "Existence";
			this.lvProductsColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader3.Width = 98;
			//
			// ColumnHeader(5)
			//
			this.lvProductsColumnHeader4.Text = "Ordered";
			this.lvProductsColumnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader4.Width = 98;
			//
			// ColumnHeader(6)
			//
			this.lvProductsColumnHeader5.Text = "Quantity per Unit";
			this.lvProductsColumnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader5.Width = 98;
			//
			// ColumnHeader(7)
			//
			this.lvProductsColumnHeader6.Text = "Unit";
			this.lvProductsColumnHeader6.Width = 98;
			//
			// Label14
			//
			this.Label14.Name = "Label14";
			this.Label14.TabIndex = 32;
			this.Label14.Location = new System.Drawing.Point(218, 477);
			this.Label14.Size = new System.Drawing.Size(90, 17);
			this.Label14.Text = "Adjusted quantity";
			this.Label14.BackColor = System.Drawing.SystemColors.Control;
			this.Label14.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// lblNewQuantity
			//
			this.lblNewQuantity.Name = "lblNewQuantity";
			this.lblNewQuantity.TabIndex = 31;
			this.lblNewQuantity.Location = new System.Drawing.Point(316, 477);
			this.lblNewQuantity.Size = new System.Drawing.Size(90, 17);
			this.lblNewQuantity.Text = "";
			this.lblNewQuantity.BackColor = System.Drawing.SystemColors.Control;
			this.lblNewQuantity.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label12
			//
			this.Label12.Name = "Label12";
			this.Label12.TabIndex = 30;
			this.Label12.Location = new System.Drawing.Point(16, 477);
			this.Label12.Size = new System.Drawing.Size(90, 17);
			this.Label12.Text = "Stock quantity";
			this.Label12.BackColor = System.Drawing.SystemColors.Control;
			this.Label12.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// lblCurrentQuantity
			//
			this.lblCurrentQuantity.Name = "lblCurrentQuantity";
			this.lblCurrentQuantity.TabIndex = 29;
			this.lblCurrentQuantity.Location = new System.Drawing.Point(113, 477);
			this.lblCurrentQuantity.Size = new System.Drawing.Size(90, 17);
			this.lblCurrentQuantity.Text = "";
			this.lblCurrentQuantity.BackColor = System.Drawing.SystemColors.Control;
			this.lblCurrentQuantity.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label11
			//
			this.Label11.Name = "Label11";
			this.Label11.TabIndex = 27;
			this.Label11.Location = new System.Drawing.Point(16, 380);
			this.Label11.Size = new System.Drawing.Size(66, 17);
			this.Label11.Text = "Stock ID:";
			this.Label11.BackColor = System.Drawing.SystemColors.Control;
			this.Label11.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label10
			//
			this.Label10.Name = "Label10";
			this.Label10.TabIndex = 24;
			this.Label10.Location = new System.Drawing.Point(235, 380);
			this.Label10.Size = new System.Drawing.Size(90, 17);
			this.Label10.Text = "Quantity per Unit";
			this.Label10.BackColor = System.Drawing.SystemColors.Control;
			this.Label10.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label8
			//
			this.Label8.Name = "Label8";
			this.Label8.TabIndex = 23;
			this.Label8.Location = new System.Drawing.Point(16, 348);
			this.Label8.Size = new System.Drawing.Size(90, 17);
			this.Label8.Text = "Product name:";
			this.Label8.BackColor = System.Drawing.SystemColors.Control;
			this.Label8.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label9
			//
			this.Label9.Name = "Label9";
			this.Label9.TabIndex = 22;
			this.Label9.Location = new System.Drawing.Point(299, 348);
			this.Label9.Size = new System.Drawing.Size(25, 17);
			this.Label9.Text = "Unit";
			this.Label9.BackColor = System.Drawing.SystemColors.Control;
			this.Label9.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label7
			//
			this.Label7.Name = "Label7";
			this.Label7.TabIndex = 18;
			this.Label7.Location = new System.Drawing.Point(218, 440);
			this.Label7.Size = new System.Drawing.Size(90, 17);
			this.Label7.Text = "Adjusted &Quantity";
			this.Label7.BackColor = System.Drawing.SystemColors.Control;
			this.Label7.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label6
			//
			this.Label6.Name = "Label6";
			this.Label6.TabIndex = 17;
			this.Label6.Location = new System.Drawing.Point(218, 410);
			this.Label6.Size = new System.Drawing.Size(74, 17);
			this.Label6.Text = "Adjusted &Price";
			this.Label6.BackColor = System.Drawing.SystemColors.Control;
			this.Label6.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label2
			//
			this.Label2.Name = "Label2";
			this.Label2.TabIndex = 16;
			this.Label2.Location = new System.Drawing.Point(16, 440);
			this.Label2.Size = new System.Drawing.Size(82, 17);
			this.Label2.Text = "Original Quantity";
			this.Label2.BackColor = System.Drawing.SystemColors.Control;
			this.Label2.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label1
			//
			this.Label1.Name = "Label1";
			this.Label1.TabIndex = 15;
			this.Label1.Location = new System.Drawing.Point(16, 410);
			this.Label1.Size = new System.Drawing.Size(74, 17);
			this.Label1.Text = "Original Price";
			this.Label1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label3
			//
			this.Label3.Name = "Label3";
			this.Label3.TabIndex = 8;
			this.Label3.Location = new System.Drawing.Point(16, 8);
			this.Label3.Size = new System.Drawing.Size(122, 17);
			this.Label3.Text = "Select a product first";
			this.Label3.BackColor = System.Drawing.SystemColors.Control;
			this.Label3.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// frmAdjustStockManual
			//
			this.ClientSize = new System.Drawing.Size(431, 569);
			this.Controls.Add(this.sbStatusBar);
			this.Controls.Add(this.txtStockID);
			this.Controls.Add(this.txtOriginalPrice);
			this.Controls.Add(this.txtValues_0);
			this.Controls.Add(this.txtQuantityPerUnit);
			this.Controls.Add(this.txtProductName);
			this.Controls.Add(this.txtUnit);
			this.Controls.Add(this.txtValues_1);
			this.Controls.Add(this.txtOriginalQuantity);
			this.Controls.Add(this.Frame3);
			this.Controls.Add(this.Frame1);
			this.Controls.Add(this.cmdClose);
			this.Controls.Add(this.cmdSave);
			this.Controls.Add(this.lvProducts);
			this.Controls.Add(this.Label14);
			this.Controls.Add(this.lblNewQuantity);
			this.Controls.Add(this.Label12);
			this.Controls.Add(this.lblCurrentQuantity);
			this.Controls.Add(this.Label11);
			this.Controls.Add(this.Label10);
			this.Controls.Add(this.Label8);
			this.Controls.Add(this.Label9);
			this.Controls.Add(this.Label7);
			this.Controls.Add(this.Label6);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.Label3);
			this.Name = "frmAdjustStockManual";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAdjustStockManual_FormClosing);
			this.Text = "Inventory Adjust";
			this.txtValues.Enter += new System.EventHandler(this.txtValues_Enter);
			this.txtValues.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValues_KeyPress);
			this.txtValues.TextChanged += new System.EventHandler(this.txtValues_TextChanged);
			this.txtValues.SetIndex( txtValues_0, System.Convert.ToInt16( 0 ) );
			this.txtValues.SetIndex( txtValues_1, System.Convert.ToInt16( 1 ) );
			((System.ComponentModel.ISupportInitialize)(this.txtValues)).EndInit();
			this.Frame3.ResumeLayout(false);
			this.Frame1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================

		private bool editingData;
		private string currentIdProduct = "";
		// VBto upgrade warning: currentIdStock As short --> As int	OnWrite(string)
		private int currentIdStock;
		private string currentQuantityPerUnit = "";
		private string currentUnit = "";
		private string currentProductName;
		// VBto upgrade warning: currentStockPrice As double	OnWrite(string)
		private double currentStockPrice;
		// VBto upgrade warning: currentStock As double	OnWrite(string)
		private double currentStock;
		private double changedStockPrice;
		private double changedStock;
		private bool codeGeneratedChange;
		private double quantity;
		private double stockPrice, unitPrice;

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void cmdSave_Click(object sender, System.EventArgs e)
		{
			int newStockId/*unused?*/;
			int newManualLogId;
			int newStockLogId;
			editingData = false;
			try
			{	// On Error GoTo HandleError

				double deltaStockPrice;
				double deltaStock;
				changedStockPrice = Convert.ToDouble(double.Parse(txtValues[0].Text));
				changedStock = Convert.ToDouble(double.Parse(txtValues[1].Text));

				deltaStockPrice = changedStockPrice-currentStockPrice;
				deltaStock = changedStock-currentStock;

				if (deltaStockPrice==0 && deltaStock==0) {
					modMain.LogStatus("There is no modification of the Stock, the data won't be saved", this);
					return;
				}
				// UPDATE
				modConnection.ExecuteSql("Update Stocks Set StockPrice = "+Convert.ToString(changedStockPrice)+", Stock = "+Convert.ToString(changedStock)+" Where StockId = "+currentIdStock);

				// NEW
				modConnection.ExecuteSql("Select * from ManualStocks");
				modConnection.rs.AddNew();
				modConnection.rs.Fields["StockID"].Value = currentIdStock;
				modConnection.rs.Fields["Quantity"].Value = deltaStock;
				modConnection.rs.Fields["Price"].Value = deltaStockPrice;
				modConnection.rs.Fields["User"].Value = modMain.UserId;
				modConnection.rs.Fields["Date"].Value = Convert.ToString(DateTime.Today);
				modConnection.rs.Fields["Action"].Value = "MOD";
				modConnection.rs.Update();
				newManualLogId = Convert.ToInt32(modConnection.rs.Fields["ManualID"].Value);

				// NEW
				modConnection.ExecuteSql("Select * from StockLog");
				modConnection.rs.AddNew();
				modConnection.rs.Fields["User"].Value = modMain.UserId;
				modConnection.rs.Fields["Date"].Value = Convert.ToString(DateTime.Today);
				modConnection.rs.Fields["Quantity"].Value = deltaStock;
				modConnection.rs.Fields["StockPrice"].Value = deltaStockPrice;
				modConnection.rs.Fields["ProductID"].Value = currentIdProduct;
				modConnection.rs.Fields["StockID"].Value = currentIdStock;
				modConnection.rs.Fields["DocType"].Value = "MANUAL";
				modConnection.rs.Fields["DocID"].Value = newManualLogId;
				modConnection.rs.Update();
				newStockLogId = Convert.ToInt32(modConnection.rs.Fields["ID"].Value);

				modConnection.ExecuteSql("Update Products Set UnitsInStock = UnitsInStock + "+Convert.ToString(deltaStock)+" Where ProductId = '& currentIdProduct &'");

				if (MessageBox.Show("Data modified successfully"+"\r\n"+"Would you like to modify another stock manually?", "Modify data", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes) {
					ClearFields();
				} else {
					Close();
				}

				return;
			}
			catch
			{	// HandleError:
				// ...
			}
			MessageBox.Show("An error has occurred adding the data. Error: ("+Convert.ToString(Information.Err().Number)+") "+Information.Err().Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		public void cmdSave_Click()
		{
			cmdSave_Click(cmdSave, new System.EventArgs());
		}

		// VBto upgrade warning: Cancel As short	OnWrite(bool)
		private void Form_QueryUnload(ref short Cancel, int UnloadMode)
		{
			if (editingData) {
				DialogResult res;
				res = MessageBox.Show("Do you want to save the edited data?", "Save data", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
				if (res==DialogResult.Yes) {
					cmdSave_Click();
				} else if (res!=DialogResult.No) {
					Cancel = Convert.ToInt16(true);
				}
			}
		}

		private void frmAdjustStockManual_FormClosing(object sender, FormClosingEventArgs e)
		{
			short Cancel = 0;
			Form_QueryUnload(ref Cancel, 0);
			if (Cancel != 0)
			{
				e.Cancel = true;
				return;
			}
		}

		private void cmdProducts_Click(object sender, System.EventArgs e)
		{
			frmProducts.InstancePtr.ShowDialog();
			txtCode.Text = frmProducts.InstancePtr.CurrentProductID;
			txtName.Text = "";
			DoSearchProduct();
		}

		private void lvProducts_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ListViewItem Item = ((ListView)sender).FocusedItem;
			if (Item==null) return;

			DoSearchStocks();
		}

		private void lvStocks_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ListViewItem Item = ((ListView)sender).FocusedItem;
			if (Item==null) return;

			RetrieveDataProduct();
		}

		private void txtCode_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchProduct();
		}

		// Private Sub txtCode_KeyPress(KeyAscii As Integer)
		// KeyAscii = UpCase(KeyAscii)
		// End Sub

		private void txtName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchProduct();
		}

		private void DoSearchProduct()
		{
			string filter;
			filter = "";
			if (txtCode.Text!=String.Empty) {
				filter = "ProductId LIKE '%"+txtCode.Text+"%'";
			}
			if (txtName.Text!=String.Empty) {
				if (filter!=String.Empty) {
					filter += " AND ";
				}
				filter += "ProductName LIKE '%"+txtName.Text+"%'";
			}
			if (filter!=String.Empty) {
				filter = "Where "+filter;
			}
			modConnection.ExecuteSql("Select ProductID, ProductName, UnitPrice, UnitsInStock, UnitsOnOrder, QuantityPerUnit, Unit from Products "+filter);
			lvProducts.Items.Clear();
			if (modConnection.rs.RecordCount==0) {
				modMain.LogStatus("There are no records with the selected criteria");
			} else {
				ListViewItem x;
				while (!modConnection.rs.EOF) {
					x = lvProducts.Items.Add(Convert.ToString(modConnection.rs.Fields[0].Value));
					for(modMain.i=1; modMain.i<=(modConnection.rs.ColumnCount-1); modMain.i++) {
						if (!VBto.IsEmpty(modConnection.rs.Fields[modMain.i].Value)) {
							VBto.SubItemsSetText(x, modMain.i, Convert.ToString(modConnection.rs.Fields[modMain.i].Value));
						}
					} // i
					modConnection.rs.MoveNext();
				}
				if (lvProducts.Items.Count==1) {
					lvProducts.FocusedItem = lvProducts.Items[1 - 1]; lvProducts.FocusedItem.Selected = true;
				}
			}
		}


		private void DoSearchStocks()
		{
			if (lvProducts.FocusedItem==null) {
				return;
			}
			if (editingData) {
				if (MessageBox.Show("Do you want to cancel previous edited data?", "Data edition", MessageBoxButtons.YesNo, MessageBoxIcon.Question)!=DialogResult.Yes) {
					return;
				}
			}
			string productId;
			string productName;
			productId = lvProducts.FocusedItem.Text;
			productName = lvProducts.FocusedItem.SubItems[1].Text;
			currentIdProduct = lvProducts.FocusedItem.Text;

			if (!VBto.IsEmpty(lvProducts.FocusedItem.SubItems[5].Text)) currentQuantityPerUnit = lvProducts.FocusedItem.SubItems[5].Text;
			if (!VBto.IsEmpty(lvProducts.FocusedItem.SubItems[6].Text)) currentUnit = lvProducts.FocusedItem.SubItems[6].Text;
			currentProductName = lvProducts.FocusedItem.SubItems[1].Text;

			txtProductName.Text = productName;
			txtUnit.Text = currentUnit;
			txtQuantityPerUnit.Text = currentQuantityPerUnit;

			modConnection.ExecuteSql("Select StockID, Stock, InitialStock, UnitPrice, "+"StockPrice, DateStarted, DateModified, User From Stocks "+" Where ProductId = '"+productId+"'");
			lvStocks.Items.Clear();
			if (modConnection.rs.RecordCount==0) {
				modMain.LogStatus("There are no stock records of the product "+productName);
				RetrieveDataProduct();
			} else {
				ListViewItem x;
				while (!modConnection.rs.EOF) {
					x = lvStocks.Items.Add(Convert.ToString(modConnection.rs.Fields[0].Value));
					for(modMain.i=1; modMain.i<=(modConnection.rs.ColumnCount-1); modMain.i++) {
						VBto.SubItemsSetText(x, modMain.i, Convert.ToString(modConnection.rs.Fields[modMain.i].Value));
					} // i
					modConnection.rs.MoveNext();
				}
				if (lvStocks.Items.Count==1) {
					lvStocks.FocusedItem = lvStocks.Items[1 - 1]; lvStocks.FocusedItem.Selected = true;
				}
			}
		}

		private void RetrieveDataProduct()
		{
			if (editingData) {
				if (MessageBox.Show("Do you want to cancel previous edited data?", "Data edition", MessageBoxButtons.YesNo, MessageBoxIcon.Question)!=DialogResult.Yes) {
					return;
				}
			}

			bool setEmpty;
			setEmpty = true;
			if (!(lvStocks.FocusedItem==null)) {
				if (lvStocks.FocusedItem.Text!=String.Empty) {
					currentIdStock = VBto.Int(lvStocks.FocusedItem.Text);

					currentStock = double.Parse(lvStocks.FocusedItem.SubItems[1].Text);
					currentStockPrice = double.Parse(lvStocks.FocusedItem.SubItems[4].Text);

					codeGeneratedChange = true;
					txtOriginalQuantity.Text = Convert.ToString(currentStock);
					txtOriginalPrice.Text = Convert.ToString(currentStockPrice);
					txtStockID.Text = Convert.ToString(currentIdStock);
					txtValues[0].Text = Convert.ToString(currentStockPrice);
					txtValues[1].Text = Convert.ToString(currentStock);
					lblNewQuantity.Text = VBto.vbFormat(Convert.ToDouble(currentStock*double.Parse(currentQuantityPerUnit)), "##,###.00")+currentUnit;
					lblCurrentQuantity.Text = VBto.vbFormat(Convert.ToDouble(currentStock*double.Parse(currentQuantityPerUnit)), "##,###.00")+currentUnit;
					codeGeneratedChange = false;
					setEmpty = false;
					txtValues[0].ReadOnly = false;
					txtValues[1].ReadOnly = false;
					txtValues[0].Focus();
				}
			}
			if (setEmpty) {
				codeGeneratedChange = true;
				txtOriginalQuantity.Text = "";
				txtOriginalPrice.Text = "";
				txtStockID.Text = "";
				txtValues[0].Text = "";
				txtValues[1].Text = "";
				lblNewQuantity.Text = "";
				lblCurrentQuantity.Text = "";
				codeGeneratedChange = false;
			}
			editingData = false;

		}

		private void txtValues_Enter(short Index, object sender, System.EventArgs e)
		{
			modFunctions.SelectAll(txtValues[Index]);
		}
		private void txtValues_Enter(object sender, System.EventArgs e)
		{
			short index = txtValues.GetIndex((TextBox)sender);
			txtValues_Enter(index, sender, e);
		}

		private void txtValues_KeyPress(short Index, object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Keys KeyAscii = (Keys)Strings.Asc(e.KeyChar);

			
			if (KeyAscii>=Keys.D0 && KeyAscii<=Keys.D9)
			{
			}
			else if ((KeyAscii==Keys.Back) || (KeyAscii==Keys.Clear) || (KeyAscii==Keys.Delete))
			{
			}
			else if ((KeyAscii==Keys.Left) || (KeyAscii==Keys.Right) || (KeyAscii==Keys.Up) || (KeyAscii==Keys.Down) || (KeyAscii==Keys.Tab))
			{
			}
			else 
			{
				KeyAscii = 0;
				Interaction.Beep();
			}

			e.KeyChar = Strings.Chr((int)KeyAscii); if (KeyAscii == 0) e.Handled = true;
		}
		private void txtValues_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			short index = txtValues.GetIndex((TextBox)sender);
			txtValues_KeyPress(index, sender, e);
		}

		private void txtValues_TextChanged(short Index, object sender, System.EventArgs e)
		{
			if (!codeGeneratedChange) {
				editingData = true;
				codeGeneratedChange = true;
				if (txtValues[0].Text!=String.Empty) changedStockPrice = Convert.ToDouble(double.Parse(txtValues[0].Text));
				if (txtValues[1].Text!=String.Empty) changedStock = Convert.ToDouble(double.Parse(txtValues[1].Text));
				switch (Index) {
					
					case 1:
					{
						if (changedStock>currentStock) {
							changedStock = currentStock;
							modMain.LogStatus("Cannot pass the original stock, to add more, add a new stock manually", this);
							txtValues[1].Text = Convert.ToString(changedStock);
						}
						break;
					}
				} //end switch
				lblNewQuantity.Text = VBto.vbFormat(Convert.ToDouble(changedStock*double.Parse(currentQuantityPerUnit)), "##,###.00")+currentUnit;
				lblCurrentQuantity.Text = VBto.vbFormat(Convert.ToDouble(currentStock*double.Parse(currentQuantityPerUnit)), "##,###.00")+currentUnit;
				codeGeneratedChange = false;
			}
		}
		private void txtValues_TextChanged(object sender, System.EventArgs e)
		{
			short index = txtValues.GetIndex((TextBox)sender);
			txtValues_TextChanged(index, sender, e);
		}

		private void ClearFields()
		{
			codeGeneratedChange = true;
			txtValues[0].Text = "";
			txtValues[1].Text = "";
			txtValues[0].ReadOnly = true;
			txtValues[1].ReadOnly = true;
			txtCode.Text = "";
			txtName.Text = "";
			txtUnit.Text = "";
			txtStockID.Text = "";
			txtOriginalPrice.Text = "";
			txtOriginalQuantity.Text = "";
			txtProductName.Text = "";
			txtQuantityPerUnit.Text = "";
			lvProducts.Items.Clear();
			lvStocks.Items.Clear();
			lblCurrentQuantity.Text = "";
			lblNewQuantity.Text = "";
			txtCode.Focus();
			editingData = false;
			codeGeneratedChange = false;
			modMain.ClearLogStatus(this);
		}

	}
}