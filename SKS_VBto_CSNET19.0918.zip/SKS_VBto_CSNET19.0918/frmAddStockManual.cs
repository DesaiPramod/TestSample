using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace SKS
{
	/// <summary>
	/// Summary description for frmAddStockManual.
	/// </summary>
	public class frmAddStockManual : System.Windows.Forms.Form
	{
		public Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray txtValues;
		public System.Windows.Forms.Button cmdSave;
		public System.Windows.Forms.Button cmdClose;
		public System.Windows.Forms.StatusBar sbStatusBar;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel1;
		public System.Windows.Forms.TextBox txtUnit;
		public System.Windows.Forms.TextBox txtProductName;
		public System.Windows.Forms.TextBox txtQuantityPerUnit;
		public System.Windows.Forms.TextBox txtValues_2;
		public System.Windows.Forms.TextBox txtValues_1;
		public System.Windows.Forms.TextBox txtValues_0;
		public System.Windows.Forms.GroupBox Frame1;
		public System.Windows.Forms.Button cmdProducts;
		public System.Windows.Forms.TextBox txtName;
		public System.Windows.Forms.TextBox txtCode;
		public System.Windows.Forms.Label Label4;
		public System.Windows.Forms.Label Label5;
		public System.Windows.Forms.ListView lvProducts;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader0;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader1;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader2;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader3;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader4;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader5;
		private System.Windows.Forms.ColumnHeader lvProductsColumnHeader6;
		public System.Windows.Forms.Label lblNewQuantity;
		public System.Windows.Forms.Label Label10;
		public System.Windows.Forms.Label Label9;
		public System.Windows.Forms.Label Label8;
		public System.Windows.Forms.Label Label7;
		public System.Windows.Forms.Label Label6;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.Label Label2;
		public System.Windows.Forms.Label Label3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmAddStockManual()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmAddStockManual InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmAddStockManual();
				return _InstancePtr;
			}
		}
		protected static frmAddStockManual _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAddStockManual));
			this.components = new System.ComponentModel.Container();
			this.txtValues = new Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray();
			this.cmdSave = new System.Windows.Forms.Button();
			this.cmdClose = new System.Windows.Forms.Button();
			this.sbStatusBar = new System.Windows.Forms.StatusBar();
			this.sbStatusBar_Panel1 = new System.Windows.Forms.StatusBarPanel();
			this.txtUnit = new System.Windows.Forms.TextBox();
			this.txtProductName = new System.Windows.Forms.TextBox();
			this.txtQuantityPerUnit = new System.Windows.Forms.TextBox();
			this.txtValues_2 = new System.Windows.Forms.TextBox();
			this.txtValues_1 = new System.Windows.Forms.TextBox();
			this.txtValues_0 = new System.Windows.Forms.TextBox();
			this.Frame1 = new System.Windows.Forms.GroupBox();
			this.cmdProducts = new System.Windows.Forms.Button();
			this.txtName = new System.Windows.Forms.TextBox();
			this.txtCode = new System.Windows.Forms.TextBox();
			this.Label4 = new System.Windows.Forms.Label();
			this.Label5 = new System.Windows.Forms.Label();
			this.lvProducts = new System.Windows.Forms.ListView();
			this.lvProductsColumnHeader0 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader5 = new System.Windows.Forms.ColumnHeader();
			this.lvProductsColumnHeader6 = new System.Windows.Forms.ColumnHeader();
			this.lblNewQuantity = new System.Windows.Forms.Label();
			this.Label10 = new System.Windows.Forms.Label();
			this.Label9 = new System.Windows.Forms.Label();
			this.Label8 = new System.Windows.Forms.Label();
			this.Label7 = new System.Windows.Forms.Label();
			this.Label6 = new System.Windows.Forms.Label();
			this.Label1 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.Label3 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtValues)).BeginInit();
			//
			// cmdSave
			//
			this.cmdSave.Name = "cmdSave";
			this.cmdSave.TabIndex = 24;
			this.cmdSave.Location = new System.Drawing.Point(227, 380);
			this.cmdSave.Size = new System.Drawing.Size(90, 25);
			this.cmdSave.Text = "&Save";
			this.cmdSave.BackColor = System.Drawing.SystemColors.Control;
			this.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
			//
			// cmdClose
			//
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.TabIndex = 23;
			this.cmdClose.Location = new System.Drawing.Point(332, 380);
			this.cmdClose.Size = new System.Drawing.Size(90, 25);
			this.cmdClose.Text = "&Close";
			this.cmdClose.BackColor = System.Drawing.SystemColors.Control;
			this.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			//
			// sbStatusBar
			//
			this.sbStatusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {this.sbStatusBar_Panel1});
			this.sbStatusBar.Name = "sbStatusBar";
			this.sbStatusBar.TabIndex = 20;
			this.sbStatusBar.Location = new System.Drawing.Point(0, 421);
			this.sbStatusBar.Size = new System.Drawing.Size(429, 23);
			this.sbStatusBar.ShowPanels = true;
			this.sbStatusBar.SizingGrip = false;
			//
			// Panel1
			//
			this.sbStatusBar_Panel1.Text = "";
			this.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbStatusBar_Panel1.Width = 408;
			//
			// txtUnit
			//
			this.txtUnit.Name = "txtUnit";
			this.txtUnit.TabStop = false;
			this.txtUnit.TabIndex = 18;
			this.txtUnit.Location = new System.Drawing.Point(324, 267);
			this.txtUnit.Size = new System.Drawing.Size(82, 20);
			this.txtUnit.Text = "";
			this.txtUnit.BackColor = System.Drawing.SystemColors.Menu;
			this.txtUnit.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtUnit.ReadOnly = true;
			//
			// txtProductName
			//
			this.txtProductName.Name = "txtProductName";
			this.txtProductName.TabStop = false;
			this.txtProductName.TabIndex = 16;
			this.txtProductName.Location = new System.Drawing.Point(97, 267);
			this.txtProductName.Size = new System.Drawing.Size(147, 20);
			this.txtProductName.Text = "";
			this.txtProductName.BackColor = System.Drawing.SystemColors.Menu;
			this.txtProductName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtProductName.ReadOnly = true;
			//
			// txtQuantityPerUnit
			//
			this.txtQuantityPerUnit.Name = "txtQuantityPerUnit";
			this.txtQuantityPerUnit.TabStop = false;
			this.txtQuantityPerUnit.TabIndex = 15;
			this.txtQuantityPerUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtQuantityPerUnit.Location = new System.Drawing.Point(324, 299);
			this.txtQuantityPerUnit.Size = new System.Drawing.Size(82, 20);
			this.txtQuantityPerUnit.Text = "";
			this.txtQuantityPerUnit.BackColor = System.Drawing.SystemColors.Menu;
			this.txtQuantityPerUnit.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtQuantityPerUnit.ReadOnly = true;
			//
			// txtValues_2
			//
			this.txtValues_2.Name = "txtValues_2";
			this.txtValues_2.TabIndex = 5;
			this.txtValues_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtValues_2.Location = new System.Drawing.Point(324, 332);
			this.txtValues_2.Size = new System.Drawing.Size(82, 20);
			this.txtValues_2.Text = "";
			this.txtValues_2.BackColor = System.Drawing.SystemColors.Window;
			this.txtValues_2.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtValues_2.ReadOnly = true;
			//
			// txtValues_1
			//
			this.txtValues_1.Name = "txtValues_1";
			this.txtValues_1.TabIndex = 4;
			this.txtValues_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtValues_1.Location = new System.Drawing.Point(97, 332);
			this.txtValues_1.Size = new System.Drawing.Size(82, 20);
			this.txtValues_1.Text = "";
			this.txtValues_1.BackColor = System.Drawing.SystemColors.Window;
			this.txtValues_1.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtValues_1.ReadOnly = true;
			//
			// txtValues_0
			//
			this.txtValues_0.Name = "txtValues_0";
			this.txtValues_0.TabIndex = 3;
			this.txtValues_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtValues_0.Location = new System.Drawing.Point(97, 299);
			this.txtValues_0.Size = new System.Drawing.Size(82, 20);
			this.txtValues_0.Text = "";
			this.txtValues_0.BackColor = System.Drawing.SystemColors.Window;
			this.txtValues_0.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtValues_0.ReadOnly = true;
			//
			// Frame1
			//
			this.Frame1.Controls.Add(this.cmdProducts);
			this.Frame1.Controls.Add(this.txtName);
			this.Frame1.Controls.Add(this.txtCode);
			this.Frame1.Controls.Add(this.Label4);
			this.Frame1.Controls.Add(this.Label5);
			this.Frame1.Name = "Frame1";
			this.Frame1.TabIndex = 6;
			this.Frame1.Location = new System.Drawing.Point(8, 32);
			this.Frame1.Size = new System.Drawing.Size(414, 66);
			this.Frame1.Text = "Search product ";
			this.Frame1.BackColor = System.Drawing.SystemColors.Control;
			this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// cmdProducts
			//
			this.cmdProducts.Name = "cmdProducts";
			this.cmdProducts.TabStop = false;
			this.cmdProducts.TabIndex = 7;
			this.cmdProducts.Location = new System.Drawing.Point(364, 16);
			this.cmdProducts.Size = new System.Drawing.Size(25, 23);
			this.cmdProducts.Text = "...";
			this.cmdProducts.BackColor = System.Drawing.SystemColors.Control;
			this.cmdProducts.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdProducts.Click += new System.EventHandler(this.cmdProducts_Click);
			//
			// txtName
			//
			this.txtName.Name = "txtName";
			this.txtName.TabIndex = 1;
			this.txtName.Location = new System.Drawing.Point(113, 40);
			this.txtName.Size = new System.Drawing.Size(147, 20);
			this.txtName.Text = "";
			this.txtName.BackColor = System.Drawing.SystemColors.Window;
			this.txtName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
			this.txtName.Leave += new System.EventHandler(this.txtName_Leave);
			//
			// txtCode
			//
			this.txtCode.Name = "txtCode";
			this.txtCode.TabIndex = 0;
			this.txtCode.Location = new System.Drawing.Point(113, 16);
			this.txtCode.Size = new System.Drawing.Size(98, 20);
			this.txtCode.Text = "";
			this.txtCode.BackColor = System.Drawing.SystemColors.Window;
			this.txtCode.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtCode.TextChanged += new System.EventHandler(this.txtCode_TextChanged);
			this.txtCode.Leave += new System.EventHandler(this.txtCode_Leave);
			//
			// Label4
			//
			this.Label4.Name = "Label4";
			this.Label4.TabIndex = 9;
			this.Label4.Location = new System.Drawing.Point(16, 40);
			this.Label4.Size = new System.Drawing.Size(90, 17);
			this.Label4.Text = "Product name:";
			this.Label4.BackColor = System.Drawing.SystemColors.Control;
			this.Label4.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label5
			//
			this.Label5.Name = "Label5";
			this.Label5.TabIndex = 8;
			this.Label5.Location = new System.Drawing.Point(16, 16);
			this.Label5.Size = new System.Drawing.Size(90, 17);
			this.Label5.Text = "Product code:";
			this.Label5.BackColor = System.Drawing.SystemColors.Control;
			this.Label5.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// lvProducts
			//
			this.lvProducts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {this.lvProductsColumnHeader0, this.lvProductsColumnHeader1, this.lvProductsColumnHeader2, this.lvProductsColumnHeader3, this.lvProductsColumnHeader4, this.lvProductsColumnHeader5, this.lvProductsColumnHeader6});
			this.lvProducts.Name = "lvProducts";
			this.lvProducts.TabIndex = 2;
			this.lvProducts.Location = new System.Drawing.Point(8, 105);
			this.lvProducts.Size = new System.Drawing.Size(414, 155);
			this.lvProducts.BackColor = System.Drawing.SystemColors.Window;
			this.lvProducts.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lvProducts.View = System.Windows.Forms.View.Details;
			this.lvProducts.MultiSelect = false;
			this.lvProducts.GridLines = true;
			this.lvProducts.FullRowSelect = true;
			this.lvProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lvProducts.HideSelection = false;
			this.lvProducts.Click += new System.EventHandler(this.lvProducts_Click);
			this.lvProducts.SelectedIndexChanged += new System.EventHandler(this.lvProducts_SelectedIndexChanged);
			//
			// ColumnHeader(1)
			//
			this.lvProductsColumnHeader0.Text = "Code";
			this.lvProductsColumnHeader0.Width = 98;
			//
			// ColumnHeader(2)
			//
			this.lvProductsColumnHeader1.Text = "Name";
			this.lvProductsColumnHeader1.Width = 98;
			//
			// ColumnHeader(3)
			//
			this.lvProductsColumnHeader2.Text = "Price";
			this.lvProductsColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader2.Width = 98;
			//
			// ColumnHeader(4)
			//
			this.lvProductsColumnHeader3.Text = "Existence";
			this.lvProductsColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader3.Width = 98;
			//
			// ColumnHeader(5)
			//
			this.lvProductsColumnHeader4.Text = "Ordered";
			this.lvProductsColumnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader4.Width = 98;
			//
			// ColumnHeader(6)
			//
			this.lvProductsColumnHeader5.Text = "Quantity per Unit";
			this.lvProductsColumnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.lvProductsColumnHeader5.Width = 98;
			//
			// ColumnHeader(7)
			//
			this.lvProductsColumnHeader6.Text = "Unit";
			this.lvProductsColumnHeader6.Width = 98;
			//
			// lblNewQuantity
			//
			this.lblNewQuantity.Name = "lblNewQuantity";
			this.lblNewQuantity.TabIndex = 22;
			this.lblNewQuantity.Location = new System.Drawing.Point(105, 367);
			this.lblNewQuantity.Size = new System.Drawing.Size(90, 17);
			this.lblNewQuantity.Text = "";
			this.lblNewQuantity.BackColor = System.Drawing.SystemColors.Control;
			this.lblNewQuantity.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label10
			//
			this.Label10.Name = "Label10";
			this.Label10.TabIndex = 21;
			this.Label10.Location = new System.Drawing.Point(8, 367);
			this.Label10.Size = new System.Drawing.Size(90, 17);
			this.Label10.Text = "Stock quantity";
			this.Label10.BackColor = System.Drawing.SystemColors.Control;
			this.Label10.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label9
			//
			this.Label9.Name = "Label9";
			this.Label9.TabIndex = 19;
			this.Label9.Location = new System.Drawing.Point(291, 267);
			this.Label9.Size = new System.Drawing.Size(25, 17);
			this.Label9.Text = "Unit";
			this.Label9.BackColor = System.Drawing.SystemColors.Control;
			this.Label9.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label8
			//
			this.Label8.Name = "Label8";
			this.Label8.TabIndex = 17;
			this.Label8.Location = new System.Drawing.Point(8, 267);
			this.Label8.Size = new System.Drawing.Size(90, 17);
			this.Label8.Text = "Product name:";
			this.Label8.BackColor = System.Drawing.SystemColors.Control;
			this.Label8.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label7
			//
			this.Label7.Name = "Label7";
			this.Label7.TabIndex = 14;
			this.Label7.Location = new System.Drawing.Point(227, 299);
			this.Label7.Size = new System.Drawing.Size(90, 17);
			this.Label7.Text = "Quantity per Unit";
			this.Label7.BackColor = System.Drawing.SystemColors.Control;
			this.Label7.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label6
			//
			this.Label6.Name = "Label6";
			this.Label6.TabIndex = 13;
			this.Label6.Location = new System.Drawing.Point(227, 335);
			this.Label6.Size = new System.Drawing.Size(74, 17);
			this.Label6.Text = "Unit Price";
			this.Label6.BackColor = System.Drawing.SystemColors.Control;
			this.Label6.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label1
			//
			this.Label1.Name = "Label1";
			this.Label1.TabIndex = 12;
			this.Label1.Location = new System.Drawing.Point(8, 335);
			this.Label1.Size = new System.Drawing.Size(74, 17);
			this.Label1.Text = "Stock Price";
			this.Label1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label2
			//
			this.Label2.Name = "Label2";
			this.Label2.TabIndex = 11;
			this.Label2.Location = new System.Drawing.Point(8, 302);
			this.Label2.Size = new System.Drawing.Size(82, 17);
			this.Label2.Text = "Quantity";
			this.Label2.BackColor = System.Drawing.SystemColors.Control;
			this.Label2.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// Label3
			//
			this.Label3.Name = "Label3";
			this.Label3.TabIndex = 10;
			this.Label3.Location = new System.Drawing.Point(16, 8);
			this.Label3.Size = new System.Drawing.Size(122, 17);
			this.Label3.Text = "Select a product first";
			this.Label3.BackColor = System.Drawing.SystemColors.Control;
			this.Label3.ForeColor = System.Drawing.SystemColors.ControlText;
			//
			// frmAddStockManual
			//
			this.ClientSize = new System.Drawing.Size(429, 444);
			this.Controls.Add(this.cmdSave);
			this.Controls.Add(this.cmdClose);
			this.Controls.Add(this.sbStatusBar);
			this.Controls.Add(this.txtUnit);
			this.Controls.Add(this.txtProductName);
			this.Controls.Add(this.txtQuantityPerUnit);
			this.Controls.Add(this.txtValues_2);
			this.Controls.Add(this.txtValues_1);
			this.Controls.Add(this.txtValues_0);
			this.Controls.Add(this.Frame1);
			this.Controls.Add(this.lvProducts);
			this.Controls.Add(this.lblNewQuantity);
			this.Controls.Add(this.Label10);
			this.Controls.Add(this.Label9);
			this.Controls.Add(this.Label8);
			this.Controls.Add(this.Label7);
			this.Controls.Add(this.Label6);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.Label3);
			this.Name = "frmAddStockManual";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.MinimizeBox = false;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
			this.Load += new System.EventHandler(this.frmAddStockManual_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAddStockManual_FormClosing);
			this.Text = "Inventory Update";
			this.txtValues.TextChanged += new System.EventHandler(this.txtValues_TextChanged);
			this.txtValues.Enter += new System.EventHandler(this.txtValues_Enter);
			this.txtValues.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValues_KeyPress);
			this.txtValues.SetIndex( txtValues_2, System.Convert.ToInt16( 2 ) );
			this.txtValues.SetIndex( txtValues_1, System.Convert.ToInt16( 1 ) );
			this.txtValues.SetIndex( txtValues_0, System.Convert.ToInt16( 0 ) );
			((System.ComponentModel.ISupportInitialize)(this.txtValues)).EndInit();
			this.Frame1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================

		private bool editingData;
		private string currentIdProduct = "";
		private string currentQuantityPerUnit = "";
		private string currentUnit = "";
		private string currentProductName;
		// VBto upgrade warning: currentPriceReference As double	OnWrite(string)
		private double currentPriceReference;
		private bool codeGeneratedChange;
		private double quantity;
		private double stockPrice, unitPrice;

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void cmdProducts_Click(object sender, System.EventArgs e)
		{
			frmProducts.InstancePtr.ShowDialog();
			txtCode.Text = frmProducts.InstancePtr.CurrentProductID;
			txtName.Text = "";
			DoSearchProduct();
		}

		private void cmdSave_Click(object sender, System.EventArgs e)
		{
			int newStockId;
			int newManualLogId;
			int newStockLogId;
			editingData = false;
			try
			{	// On Error GoTo HandleError
				modConnection.ExecuteSql("Select * from Stocks");
				modConnection.rs.AddNew();
				modConnection.rs.Fields["ProductID"].Value = currentIdProduct;
				modConnection.rs.Fields["Stock"].Value = txtValues[0].Text;
				modConnection.rs.Fields["InitialStock"].Value = txtValues[0].Text;
				modConnection.rs.Fields["DateStarted"].Value = Convert.ToString(DateTime.Today);
				modConnection.rs.Fields["DateModified"].Value = Convert.ToString(DateTime.Today);
				modConnection.rs.Fields["User"].Value = modMain.UserId;
				modConnection.rs.Fields["UnitPrice"].Value = txtValues[2].Text;
				modConnection.rs.Fields["StockPrice"].Value = txtValues[1].Text;
				modConnection.rs.Update();
				newStockId = Convert.ToInt32(modConnection.rs.Fields["StockID"].Value);

				modConnection.ExecuteSql("Select * from ManualStocks");
				modConnection.rs.AddNew();
				modConnection.rs.Fields["StockID"].Value = newStockId;
				modConnection.rs.Fields["Quantity"].Value = txtValues[0].Text;
				modConnection.rs.Fields["Price"].Value = txtValues[1].Text;
				modConnection.rs.Fields["User"].Value = modMain.UserId;
				modConnection.rs.Fields["Date"].Value = Convert.ToString(DateTime.Today);
				modConnection.rs.Fields["Action"].Value = "ADD";
				modConnection.rs.Update();
				newManualLogId = Convert.ToInt32(modConnection.rs.Fields["ManualID"].Value);

				modConnection.ExecuteSql("Select * from StockLog");
				modConnection.rs.AddNew();
				modConnection.rs.Fields["User"].Value = modMain.UserId;
				modConnection.rs.Fields["Date"].Value = Convert.ToString(DateTime.Today);
				modConnection.rs.Fields["Quantity"].Value = txtValues[0].Text;
				modConnection.rs.Fields["StockPrice"].Value = txtValues[1].Text;
				modConnection.rs.Fields["ProductID"].Value = currentIdProduct;
				modConnection.rs.Fields["StockID"].Value = newStockId;
				modConnection.rs.Fields["DocType"].Value = "MANUAL";
				modConnection.rs.Fields["DocID"].Value = newManualLogId;
				modConnection.rs.Update();
				newStockLogId = Convert.ToInt32(modConnection.rs.Fields["ID"].Value);

				modConnection.ExecuteSql("Update Products Set UnitsInStock = UnitsInStock + "+txtValues[0].Text+" Where ProductId = '& currentIdProduct &'");

				if (MessageBox.Show("Data added successfully"+"\r\n"+"Would you like to add a new stock manually?", "New data", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==DialogResult.Yes) {
					ClearFields();
				} else {
					Close();
				}

				return;
			}
			catch
			{	// HandleError:
				// ...
			}
			MessageBox.Show("An error has occurred adding the data. Error: ("+Convert.ToString(Information.Err().Number)+") "+Information.Err().Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		public void cmdSave_Click()
		{
			cmdSave_Click(cmdSave, new System.EventArgs());
		}

		private void frmAddStockManual_Load(object sender, System.EventArgs e)
		{
			editingData = false;
			codeGeneratedChange = false;
		}

		// VBto upgrade warning: Cancel As short	OnWrite(bool)
		private void Form_QueryUnload(ref short Cancel, int UnloadMode)
		{
			if (editingData) {
				DialogResult res;
				res = MessageBox.Show("Do you want to save the edited data?", "Save data", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
				if (res==DialogResult.Yes) {
					cmdSave_Click();
				} else if (res!=DialogResult.No) {
					Cancel = Convert.ToInt16(true);
				}
			}
		}

		private void frmAddStockManual_FormClosing(object sender, FormClosingEventArgs e)
		{
			short Cancel = 0;
			Form_QueryUnload(ref Cancel, 0);
			if (Cancel != 0)
			{
				e.Cancel = true;
				return;
			}
		}

		private void lvProducts_Click(object sender, System.EventArgs e)
		{
			RetrieveDataProduct();
		}

		private void lvProducts_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ListViewItem Item = ((ListView)sender).FocusedItem;
			if (Item==null) return;

			RetrieveDataProduct();
		}

		private void txtCode_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchProduct();
		}

		// Private Sub txtCode_KeyPress(KeyAscii As Integer)
		// KeyAscii = UpCase(KeyAscii)
		// End Sub

		private void txtCode_Leave(object sender, System.EventArgs e)
		{
			if (lvProducts.Items.Count==1) {
				RetrieveDataProduct();
			}
		}

		private void txtName_TextChanged(object sender, System.EventArgs e)
		{
			DoSearchProduct();
		}


		private void DoSearchProduct()
		{
			string filter;
			filter = "";
			if (txtCode.Text!=String.Empty) {
				filter = "ProductId LIKE '%"+txtCode.Text+"%'";
			}
			if (txtName.Text!=String.Empty) {
				if (filter!=String.Empty) {
					filter += " AND ";
				}
				filter += "ProductName LIKE '%"+txtName.Text+"%'";
			}
			if (filter!=String.Empty) {
				filter = "Where "+filter;
			}
			modConnection.ExecuteSql("Select ProductID, ProductName, UnitPrice, UnitsInStock, UnitsOnOrder, QuantityPerUnit, Unit from Products "+filter);
			lvProducts.Items.Clear();
			if (modConnection.rs.RecordCount==0) {
				modMain.LogStatus("There are no records with the selected criteria", this);
			} else {
				ListViewItem x;
				while (!modConnection.rs.EOF) {
					x = lvProducts.Items.Add(Convert.ToString(modConnection.rs.Fields[0].Value));
					for(modMain.i=1; modMain.i<=(modConnection.rs.ColumnCount-1); modMain.i++) {
						if (!VBto.IsEmpty(modConnection.rs.Fields[modMain.i].Value)) {
							VBto.SubItemsSetText(x, modMain.i, Convert.ToString(modConnection.rs.Fields[modMain.i].Value));
						}
					} // i
					modConnection.rs.MoveNext();
				}
				if (lvProducts.Items.Count==1) {
					lvProducts.FocusedItem = lvProducts.Items[1 - 1]; lvProducts.FocusedItem.Selected = true;
					// RetrieveDataProduct
				}
			}
		}

		private void RetrieveDataProduct()
		{
			if (editingData) {
				if (MessageBox.Show("Do you want to cancel previous edited data?", "Data edition", MessageBoxButtons.YesNo, MessageBoxIcon.Question)!=DialogResult.Yes) {
					return;
				}
			}

			if (lvProducts.FocusedItem.Text!=String.Empty) {

				currentIdProduct = lvProducts.FocusedItem.Text;
				if (lvProducts.FocusedItem.SubItems[5].Text!=String.Empty) currentQuantityPerUnit = lvProducts.FocusedItem.SubItems[5].Text;
				if (lvProducts.FocusedItem.SubItems[6].Text!=String.Empty) currentUnit = lvProducts.FocusedItem.SubItems[6].Text;
				currentProductName = lvProducts.FocusedItem.SubItems[1].Text;
				currentPriceReference = double.Parse(lvProducts.FocusedItem.SubItems[2].Text);

				txtProductName.Text = currentProductName;
				txtQuantityPerUnit.Text = currentQuantityPerUnit;
				txtUnit.Text = currentUnit;
				txtValues[0].ReadOnly = false;
				txtValues[1].ReadOnly = false;
				txtValues[2].ReadOnly = false;
				txtValues[0].Text = Convert.ToString(1);
				txtValues[1].Text = Convert.ToString(currentPriceReference);
				txtValues[2].Text = Convert.ToString(currentPriceReference);
				txtValues[0].Focus();
				modFunctions.SelectAll(txtValues[0]);
				editingData = false;
			}
		}


		private void txtName_Leave(object sender, System.EventArgs e)
		{
			if (lvProducts.Items.Count==1) {
				RetrieveDataProduct();
			}
		}

		private void txtValues_TextChanged(short Index, object sender, System.EventArgs e)
		{
			if (!codeGeneratedChange) {
				editingData = true;
				codeGeneratedChange = true;
				if (txtValues[0].Text!=String.Empty) quantity = Convert.ToDouble(double.Parse(txtValues[0].Text));
				if (txtValues[1].Text!=String.Empty) stockPrice = Convert.ToDouble(double.Parse(txtValues[1].Text));
				if (txtValues[2].Text!=String.Empty) unitPrice = Convert.ToDouble(double.Parse(txtValues[2].Text));
				switch (Index) {
					
					case 0:
					{
						txtValues[1].Text = Convert.ToString(unitPrice*quantity);
						break;
					}
					case 1:
					{
						txtValues[2].Text = Convert.ToString(stockPrice/quantity);
						break;
					}
					case 2:
					{
						txtValues[1].Text = Convert.ToString(unitPrice*quantity);
						break;
					}
				} //end switch
				lblNewQuantity.Text = VBto.vbFormat(Convert.ToDouble(quantity*double.Parse(currentQuantityPerUnit)), "##,###.00")+currentUnit;
				codeGeneratedChange = false;
			}
		}
		private void txtValues_TextChanged(object sender, System.EventArgs e)
		{
			short index = txtValues.GetIndex((TextBox)sender);
			txtValues_TextChanged(index, sender, e);
		}

		private void txtValues_Enter(short Index, object sender, System.EventArgs e)
		{
			modFunctions.SelectAll(txtValues[Index]);
		}
		private void txtValues_Enter(object sender, System.EventArgs e)
		{
			short index = txtValues.GetIndex((TextBox)sender);
			txtValues_Enter(index, sender, e);
		}

		private void txtValues_KeyPress(short Index, object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			Keys KeyAscii = (Keys)Strings.Asc(e.KeyChar);

			
			if (KeyAscii>=Keys.D0 && KeyAscii<=Keys.D9)
			{
			}
			else if ((KeyAscii==Keys.Back) || (KeyAscii==Keys.Clear) || (KeyAscii==Keys.Delete))
			{
			}
			else if ((KeyAscii==Keys.Left) || (KeyAscii==Keys.Right) || (KeyAscii==Keys.Up) || (KeyAscii==Keys.Down) || (KeyAscii==Keys.Tab))
			{
			}
			else 
			{
				KeyAscii = 0;
				Interaction.Beep();
			}

			e.KeyChar = Strings.Chr((int)KeyAscii); if (KeyAscii == 0) e.Handled = true;
		}
		private void txtValues_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			short index = txtValues.GetIndex((TextBox)sender);
			txtValues_KeyPress(index, sender, e);
		}

		private void ClearFields()
		{
			codeGeneratedChange = true;
			txtValues[0].ReadOnly = true;
			txtValues[1].ReadOnly = true;
			txtValues[2].ReadOnly = true;
			txtValues[0].Text = "";
			txtValues[1].Text = "";
			txtValues[2].Text = "";
			txtCode.Text = "";
			txtName.Text = "";
			txtUnit.Text = "";
			txtProductName.Text = "";
			txtQuantityPerUnit.Text = "";
			lvProducts.Items.Clear();
			txtCode.Focus();
			editingData = false;
			codeGeneratedChange = false;
			lblNewQuantity.Text = "";
			modMain.ClearLogStatus(this);
		}

	}
}