
namespace SKS
{
	/// <summary>
	/// Summary description for frmMain.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		public System.Windows.Forms.StatusBar sbStatusBar;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel1;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel2;
		private System.Windows.Forms.StatusBarPanel sbStatusBar_Panel3;
		private System.Windows.Forms.MainMenu MainMenu1;
		public System.Windows.Forms.MenuItem mnuFile;
		public System.Windows.Forms.MenuItem mnuCustomer;
		public System.Windows.Forms.MenuItem mnuProviders;
		public System.Windows.Forms.MenuItem mnuExit;
		public System.Windows.Forms.MenuItem mnuOrders;
		public System.Windows.Forms.MenuItem mnuCreateOrderRequest;
		public System.Windows.Forms.MenuItem mnuOrderRequestsApproval;
		public System.Windows.Forms.MenuItem lExit2;
		public System.Windows.Forms.MenuItem mnuCreateOrderReception;
		public System.Windows.Forms.MenuItem mnuOrderReceptionsApproval;
		public System.Windows.Forms.MenuItem mnuMainInventory;
		public System.Windows.Forms.MenuItem mnuAddStockManually;
		public System.Windows.Forms.MenuItem mnuAdjustStockManually;
		public System.Windows.Forms.MenuItem mnuAccounts;
		public System.Windows.Forms.MenuItem mnuProducts;
		public System.Windows.Forms.MenuItem mnuSecurity;
		public System.Windows.Forms.MenuItem mnuHelp;
		public System.Windows.Forms.MenuItem mnuAbout;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmMain InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmMain();
				return _InstancePtr;
			}
		}
		protected static frmMain _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
			this.sbStatusBar = new System.Windows.Forms.StatusBar();
			this.sbStatusBar_Panel1 = new System.Windows.Forms.StatusBarPanel();
			this.sbStatusBar_Panel2 = new System.Windows.Forms.StatusBarPanel();
			this.sbStatusBar_Panel3 = new System.Windows.Forms.StatusBarPanel();
			this.MainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.mnuCustomer = new System.Windows.Forms.MenuItem();
			this.mnuProviders = new System.Windows.Forms.MenuItem();
			this.mnuExit = new System.Windows.Forms.MenuItem();
			this.mnuOrders = new System.Windows.Forms.MenuItem();
			this.mnuCreateOrderRequest = new System.Windows.Forms.MenuItem();
			this.mnuOrderRequestsApproval = new System.Windows.Forms.MenuItem();
			this.lExit2 = new System.Windows.Forms.MenuItem();
			this.mnuCreateOrderReception = new System.Windows.Forms.MenuItem();
			this.mnuOrderReceptionsApproval = new System.Windows.Forms.MenuItem();
			this.mnuMainInventory = new System.Windows.Forms.MenuItem();
			this.mnuAddStockManually = new System.Windows.Forms.MenuItem();
			this.mnuAdjustStockManually = new System.Windows.Forms.MenuItem();
			this.mnuAccounts = new System.Windows.Forms.MenuItem();
			this.mnuProducts = new System.Windows.Forms.MenuItem();
			this.mnuSecurity = new System.Windows.Forms.MenuItem();
			this.mnuHelp = new System.Windows.Forms.MenuItem();
			this.mnuAbout = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			//
			// sbStatusBar
			//
			this.sbStatusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {this.sbStatusBar_Panel1, this.sbStatusBar_Panel2, this.sbStatusBar_Panel3});
			this.sbStatusBar.Name = "sbStatusBar";
			this.sbStatusBar.TabIndex = 0;
			this.sbStatusBar.Location = new System.Drawing.Point(0, 666);
			this.sbStatusBar.Size = new System.Drawing.Size(1126, 25);
			this.sbStatusBar.ShowPanels = true;
			this.sbStatusBar.SizingGrip = false;
			//
			// Panel1
			//
			this.sbStatusBar_Panel1.Text = "";
			this.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.sbStatusBar_Panel1.Width = 909;
			this.sbStatusBar_Panel1.MinWidth = 67;
			//
			// Panel2
			//
			this.sbStatusBar_Panel2.Text = "";
			//
			// Panel3
			//
			this.sbStatusBar_Panel3.Text = "";
			//
			// mnuFile
			//
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {this.mnuCustomer, this.mnuProviders, this.mnuExit});
			this.mnuFile.Name = "mnuFile";
			this.mnuFile.Text = "&File";
			//
			// mnuCustomer
			//
			this.mnuCustomer.Name = "mnuCustomer";
			this.mnuCustomer.Text = "&Manage Customers";
			this.mnuCustomer.Click += new System.EventHandler(this.mnuCustomer_Click);
			//
			// mnuProviders
			//
			this.mnuProviders.Name = "mnuProviders";
			this.mnuProviders.Text = "Manage Su&ppliers ";
			this.mnuProviders.Click += new System.EventHandler(this.mnuProviders_Click);
			//
			// mnuExit
			//
			this.mnuExit.Name = "mnuExit";
			this.mnuExit.Text = "&Exit";
			this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
			//
			// mnuOrders
			//
			this.mnuOrders.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {this.mnuCreateOrderRequest, this.mnuOrderRequestsApproval, this.lExit2, this.mnuCreateOrderReception, this.mnuOrderReceptionsApproval});
			this.mnuOrders.Name = "mnuOrders";
			this.mnuOrders.Text = "&Orders";
			//
			// mnuCreateOrderRequest
			//
			this.mnuCreateOrderRequest.Name = "mnuCreateOrderRequest";
			this.mnuCreateOrderRequest.Text = "Create Order";
			this.mnuCreateOrderRequest.Click += new System.EventHandler(this.mnuCreateOrderRequest_Click);
			//
			// mnuOrderRequestsApproval
			//
			this.mnuOrderRequestsApproval.Name = "mnuOrderRequestsApproval";
			this.mnuOrderRequestsApproval.Text = "Create Invoice";
			this.mnuOrderRequestsApproval.Click += new System.EventHandler(this.mnuOrderRequestsApproval_Click);
			//
			// lExit2
			//
			this.lExit2.Name = "lExit2";
			this.lExit2.Text = "-";
			//
			// mnuCreateOrderReception
			//
			this.mnuCreateOrderReception.Name = "mnuCreateOrderReception";
			this.mnuCreateOrderReception.Text = "Add Stock Order";
			this.mnuCreateOrderReception.Click += new System.EventHandler(this.mnuCreateOrderReception_Click);
			//
			// mnuOrderReceptionsApproval
			//
			this.mnuOrderReceptionsApproval.Name = "mnuOrderReceptionsApproval";
			this.mnuOrderReceptionsApproval.Text = "Add Stock to Inventory";
			this.mnuOrderReceptionsApproval.Click += new System.EventHandler(this.mnuOrderReceptionsApproval_Click);
			//
			// mnuMainInventory
			//
			this.mnuMainInventory.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {this.mnuAddStockManually, this.mnuAdjustStockManually});
			this.mnuMainInventory.Name = "mnuMainInventory";
			this.mnuMainInventory.Text = "&Inventory";
			//
			// mnuAddStockManually
			//
			this.mnuAddStockManually.Name = "mnuAddStockManually";
			this.mnuAddStockManually.Text = "Inventory Update";
			this.mnuAddStockManually.Click += new System.EventHandler(this.mnuAddStockManually_Click);
			//
			// mnuAdjustStockManually
			//
			this.mnuAdjustStockManually.Name = "mnuAdjustStockManually";
			this.mnuAdjustStockManually.Text = "Inventory Adjust";
			this.mnuAdjustStockManually.Click += new System.EventHandler(this.mnuAdjustStockManually_Click);
			//
			// mnuAccounts
			//
			this.mnuAccounts.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {this.mnuProducts, this.mnuSecurity});
			this.mnuAccounts.Name = "mnuAccounts";
			this.mnuAccounts.Text = "&Maintenance";
			//
			// mnuProducts
			//
			this.mnuProducts.Name = "mnuProducts";
			this.mnuProducts.Text = "Manage Products";
			this.mnuProducts.Click += new System.EventHandler(this.mnuProducts_Click);
			//
			// mnuSecurity
			//
			this.mnuSecurity.Name = "mnuSecurity";
			this.mnuSecurity.Text = "Manage Users";
			this.mnuSecurity.Click += new System.EventHandler(this.mnuSecurity_Click);
			//
			// mnuHelp
			//
			this.mnuHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {this.mnuAbout});
			this.mnuHelp.Name = "mnuHelp";
			this.mnuHelp.Text = "&Help";
			//
			// mnuAbout
			//
			this.mnuAbout.Name = "mnuAbout";
			this.mnuAbout.Text = "&About";
			this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
			//
			// MainMenu1
			//
			this.MainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {this.mnuFile, this.mnuOrders, this.mnuMainInventory, this.mnuAccounts, this.mnuHelp});
			//
			// frmMain
			//
			this.ClientSize = new System.Drawing.Size(1126, 692);
			this.Controls.Add(this.sbStatusBar);
			this.Menu = this.MainMenu1;
			this.IsMdiContainer = true;
			this.Name = "frmMain";
			this.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.MinimizeBox = true;
			this.MaximizeBox = true;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("frmMain.Icon")));
			this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.frmMain_Load);
			this.Text = "Sales Agent";
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================

		private void frmMain_Load(object sender, System.EventArgs e)
		{
			frmSplash.InstancePtr.ShowDialog();
			VBto.ShowAsMdiChild(frmOrderRequest.InstancePtr, this);


		}

		private void mnuAbout_Click(object sender, System.EventArgs e)
		{
			frmAbout.InstancePtr.ShowDialog();
		}

		private void mnuAddStockManually_Click(object sender, System.EventArgs e)
		{
			VBto.ShowAsMdiChild(frmAddStockManual.InstancePtr, this);
		}

		private void mnuAdjustStockManually_Click(object sender, System.EventArgs e)
		{
			VBto.ShowAsMdiChild(frmAdjustStockManual.InstancePtr, this);
		}

		private void mnuCreateOrderReception_Click(object sender, System.EventArgs e)
		{
			VBto.ShowAsMdiChild(frmOrderReception.InstancePtr, this);
		}

		private void mnuCreateOrderRequest_Click(object sender, System.EventArgs e)
		{
			VBto.ShowAsMdiChild(frmOrderRequest.InstancePtr, this);
		}

		private void mnuCustomer_Click(object sender, System.EventArgs e)
		{
			frmCustomers.InstancePtr.ShowDialog();
			frmCustomers.InstancePtr.InitForm();
		}

		private void mnuExit_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void mnuOrderReceptionsApproval_Click(object sender, System.EventArgs e)
		{
			VBto.ShowAsMdiChild(frmReceptionApproval.InstancePtr, this);
		}

		private void mnuOrderRequestsApproval_Click(object sender, System.EventArgs e)
		{
			VBto.ShowAsMdiChild(frmRequestApproval.InstancePtr, this);
		}

		private void mnuProducts_Click(object sender, System.EventArgs e)
		{
			frmProducts.InstancePtr.ShowDialog();
		}

		private void mnuProviders_Click(object sender, System.EventArgs e)
		{
			frmProviders.InstancePtr.ShowDialog();
		}

		private void mnuSecurity_Click(object sender, System.EventArgs e)
		{
			VBto.ShowAsMdiChild(frmUsersManage.InstancePtr, this);
		}



	}
}