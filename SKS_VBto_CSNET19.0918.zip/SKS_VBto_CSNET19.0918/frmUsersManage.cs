using System;
using System.Windows.Forms;

namespace SKS
{
	/// <summary>
	/// Summary description for frmUsersManage.
	/// </summary>
	public class frmUsersManage : System.Windows.Forms.Form
	{
		public Microsoft.VisualBasic.Compatibility.VB6.LabelArray Label1;
		public System.Windows.Forms.ListView lstAccounts;
		private System.Windows.Forms.ColumnHeader lstAccountsColumnHeader0;
		private System.Windows.Forms.ColumnHeader lstAccountsColumnHeader1;
		private System.Windows.Forms.ColumnHeader lstAccountsColumnHeader2;
		public System.Windows.Forms.Button cmdClear;
		public System.Windows.Forms.Button cmdSave;
		public System.Windows.Forms.PictureBox ctrlLiner1;
		public System.Windows.Forms.GroupBox Frame1;
		public System.Windows.Forms.TextBox txtFullname;
		public System.Windows.Forms.TextBox txtPassword;
		public System.Windows.Forms.TextBox txtUsername;
		public System.Windows.Forms.ComboBox cboLevel;
		public System.Windows.Forms.Label Label1_2;
		public System.Windows.Forms.Label Label1_0;
		public System.Windows.Forms.Label Label1_1;
		public System.Windows.Forms.Label Label1_3;
		public System.Windows.Forms.Label lblId;
		public System.Windows.Forms.Button cmdClose;
		public System.Windows.Forms.Button cmdEdit;
		public System.Windows.Forms.Button cmdDelete;
		public System.Windows.Forms.Label Label1_4;
		public System.Windows.Forms.PictureBox Image1;
		public System.Windows.Forms.Label Label19;
		public System.Windows.Forms.Label Label4;
		private System.Windows.Forms.ToolTip ToolTip1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmUsersManage()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			if (_InstancePtr == null && System.Windows.Forms.Application.OpenForms.Count == 0)
				_InstancePtr = this;
		}

		/// <summary>
		/// Default instance for Form
		/// </summary>
		public static frmUsersManage InstancePtr
		{
			get
			{
				if (_InstancePtr == null) // || _InstancePtr.IsDisposed
					_InstancePtr = new frmUsersManage();
				return _InstancePtr;
			}
		}
		protected static frmUsersManage _InstancePtr = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (_InstancePtr == this)
				_InstancePtr = null;
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmUsersManage));
			this.components = new System.ComponentModel.Container();
			this.Label1 = new Microsoft.VisualBasic.Compatibility.VB6.LabelArray();
			this.lstAccounts = new System.Windows.Forms.ListView();
			this.lstAccountsColumnHeader0 = new System.Windows.Forms.ColumnHeader();
			this.lstAccountsColumnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.lstAccountsColumnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.cmdClear = new System.Windows.Forms.Button();
			this.cmdSave = new System.Windows.Forms.Button();
			this.ctrlLiner1 = new System.Windows.Forms.PictureBox();
			this.Frame1 = new System.Windows.Forms.GroupBox();
			this.txtFullname = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.txtUsername = new System.Windows.Forms.TextBox();
			this.cboLevel = new System.Windows.Forms.ComboBox();
			this.Label1_2 = new System.Windows.Forms.Label();
			this.Label1_0 = new System.Windows.Forms.Label();
			this.Label1_1 = new System.Windows.Forms.Label();
			this.Label1_3 = new System.Windows.Forms.Label();
			this.lblId = new System.Windows.Forms.Label();
			this.cmdClose = new System.Windows.Forms.Button();
			this.cmdEdit = new System.Windows.Forms.Button();
			this.cmdDelete = new System.Windows.Forms.Button();
			this.Label1_4 = new System.Windows.Forms.Label();
			this.Image1 = new System.Windows.Forms.PictureBox();
			this.Label19 = new System.Windows.Forms.Label();
			this.Label4 = new System.Windows.Forms.Label();
			this.ToolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.Label1)).BeginInit();
			//
			// lstAccounts
			//
			this.lstAccounts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {this.lstAccountsColumnHeader0, this.lstAccountsColumnHeader1, this.lstAccountsColumnHeader2});
			this.lstAccounts.Name = "lstAccounts";
			this.lstAccounts.TabIndex = 7;
			this.lstAccounts.Location = new System.Drawing.Point(0, 267);
			this.lstAccounts.Size = new System.Drawing.Size(341, 114);
			this.lstAccounts.BackColor = System.Drawing.SystemColors.Window;
			this.lstAccounts.ForeColor = System.Drawing.SystemColors.WindowText;
			this.lstAccounts.LabelEdit = true;
			this.lstAccounts.View = System.Windows.Forms.View.Details;
			this.lstAccounts.MultiSelect = false;
			this.lstAccounts.FullRowSelect = true;
			this.lstAccounts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lstAccounts.DoubleClick += new System.EventHandler(this.lstAccounts_DoubleClick);
			//
			// ColumnHeader(1)
			//
			this.lstAccountsColumnHeader0.Text = "UserId";
			this.lstAccountsColumnHeader0.Width = 98;
			//
			// ColumnHeader(2)
			//
			this.lstAccountsColumnHeader1.Text = "Name";
			this.lstAccountsColumnHeader1.Width = 98;
			//
			// ColumnHeader(3)
			//
			this.lstAccountsColumnHeader2.Text = "RoleLevel";
			this.lstAccountsColumnHeader2.Width = 98;
			//
			// cmdClear
			//
			this.cmdClear.Name = "cmdClear";
			this.cmdClear.TabIndex = 5;
			this.cmdClear.Location = new System.Drawing.Point(170, 235);
			this.cmdClear.Size = new System.Drawing.Size(82, 25);
			this.cmdClear.Text = "&New";
			this.cmdClear.BackColor = System.Drawing.SystemColors.Control;
			this.cmdClear.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
			//
			// cmdSave
			//
			this.cmdSave.Name = "cmdSave";
			this.cmdSave.TabIndex = 4;
			this.cmdSave.Location = new System.Drawing.Point(81, 235);
			this.cmdSave.Size = new System.Drawing.Size(82, 25);
			this.cmdSave.Text = "&Save";
			this.cmdSave.BackColor = System.Drawing.SystemColors.Control;
			this.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
			//
			// ctrlLiner1
			//
			this.ctrlLiner1.Name = "ctrlLiner1";
			this.ctrlLiner1.TabIndex = 15;
			this.ctrlLiner1.Location = new System.Drawing.Point(0, 57);
			this.ctrlLiner1.Size = new System.Drawing.Size(317, 2);
			this.ctrlLiner1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.ctrlLiner1.BackColor = System.Drawing.SystemColors.Control;
			//
			// Frame1
			//
			this.Frame1.Controls.Add(this.txtFullname);
			this.Frame1.Controls.Add(this.txtPassword);
			this.Frame1.Controls.Add(this.txtUsername);
			this.Frame1.Controls.Add(this.cboLevel);
			this.Frame1.Controls.Add(this.Label1_2);
			this.Frame1.Controls.Add(this.Label1_0);
			this.Frame1.Controls.Add(this.Label1_1);
			this.Frame1.Controls.Add(this.Label1_3);
			this.Frame1.Controls.Add(this.lblId);
			this.Frame1.Name = "Frame1";
			this.Frame1.TabIndex = 10;
			this.Frame1.Location = new System.Drawing.Point(8, 65);
			this.Frame1.Size = new System.Drawing.Size(333, 155);
			this.Frame1.Text = "User information";
			this.Frame1.BackColor = System.Drawing.SystemColors.Control;
			this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Frame1.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// txtFullname
			//
			this.txtFullname.Name = "txtFullname";
			this.txtFullname.TabIndex = 2;
			this.txtFullname.Location = new System.Drawing.Point(121, 89);
			this.txtFullname.Size = new System.Drawing.Size(195, 19);
			this.txtFullname.Text = "";
			this.txtFullname.BackColor = System.Drawing.SystemColors.Window;
			this.txtFullname.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtFullname.MaxLength = 50;
			this.txtFullname.Font = new System.Drawing.Font("MS Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtFullname.Enter += new System.EventHandler(this.txtFullname_Enter);
			//
			// txtPassword
			//
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.TabIndex = 1;
			this.txtPassword.Location = new System.Drawing.Point(121, 57);
			this.txtPassword.Size = new System.Drawing.Size(195, 19);
			this.txtPassword.Text = "";
			this.txtPassword.BackColor = System.Drawing.SystemColors.Window;
			this.txtPassword.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtPassword.MaxLength = 50;
			this.txtPassword.Font = new System.Drawing.Font("Wingdings", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Regular), System.Drawing.GraphicsUnit.Point, ((System.Byte)(2)));
			this.txtPassword.Enter += new System.EventHandler(this.txtPassword_Enter);
			//
			// txtUsername
			//
			this.txtUsername.Name = "txtUsername";
			this.txtUsername.TabIndex = 0;
			this.txtUsername.Location = new System.Drawing.Point(121, 24);
			this.txtUsername.Size = new System.Drawing.Size(195, 19);
			this.txtUsername.Text = "";
			this.txtUsername.BackColor = System.Drawing.SystemColors.Window;
			this.txtUsername.ForeColor = System.Drawing.SystemColors.WindowText;
			this.txtUsername.MaxLength = 50;
			this.txtUsername.Font = new System.Drawing.Font("MS Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtUsername.Enter += new System.EventHandler(this.txtUsername_Enter);
			//
			// cboLevel
			//
			this.cboLevel.Name = "cboLevel";
			this.cboLevel.TabIndex = 3;
			this.cboLevel.Location = new System.Drawing.Point(121, 121);
			this.cboLevel.Size = new System.Drawing.Size(195, 21);
			this.cboLevel.Text = "";
			this.cboLevel.BackColor = System.Drawing.SystemColors.Window;
			this.cboLevel.ForeColor = System.Drawing.SystemColors.WindowText;
			this.cboLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboLevel.Font = new System.Drawing.Font("MS Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			//
			// Label1_2
			//
			this.Label1_2.Name = "Label1_2";
			this.Label1_2.TabIndex = 16;
			this.Label1_2.AutoSize = true;
			this.Label1_2.Location = new System.Drawing.Point(16, 89);
			this.Label1_2.Size = new System.Drawing.Size(69, 13);
			this.Label1_2.Text = "Full name: *";
			this.Label1_2.BackColor = System.Drawing.SystemColors.Control;
			this.Label1_2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.Label1_2.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// Label1_0
			//
			this.Label1_0.Name = "Label1_0";
			this.Label1_0.TabIndex = 14;
			this.Label1_0.AutoSize = true;
			this.Label1_0.Location = new System.Drawing.Point(16, 24);
			this.Label1_0.Size = new System.Drawing.Size(71, 13);
			this.Label1_0.Text = "Username: *";
			this.Label1_0.BackColor = System.Drawing.SystemColors.Control;
			this.Label1_0.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.Label1_0.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// Label1_1
			//
			this.Label1_1.Name = "Label1_1";
			this.Label1_1.TabIndex = 13;
			this.Label1_1.AutoSize = true;
			this.Label1_1.Location = new System.Drawing.Point(16, 57);
			this.Label1_1.Size = new System.Drawing.Size(97, 13);
			this.Label1_1.Text = "New password: *";
			this.Label1_1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1_1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.Label1_1.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// Label1_3
			//
			this.Label1_3.Name = "Label1_3";
			this.Label1_3.TabIndex = 12;
			this.Label1_3.AutoSize = true;
			this.Label1_3.Location = new System.Drawing.Point(16, 121);
			this.Label1_3.Size = new System.Drawing.Size(72, 13);
			this.Label1_3.Text = "User level: *";
			this.Label1_3.BackColor = System.Drawing.SystemColors.Control;
			this.Label1_3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.Label1_3.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// lblId
			//
			this.lblId.Name = "lblId";
			this.lblId.TabIndex = 11;
			this.lblId.AutoSize = true;
			this.lblId.Location = new System.Drawing.Point(129, 24);
			this.lblId.Size = new System.Drawing.Size(3, 13);
			this.lblId.Text = "";
			this.lblId.BackColor = System.Drawing.SystemColors.Control;
			this.lblId.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.lblId.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// cmdClose
			//
			this.cmdClose.Name = "cmdClose";
			this.cmdClose.TabIndex = 6;
			this.cmdClose.Location = new System.Drawing.Point(259, 235);
			this.cmdClose.Size = new System.Drawing.Size(82, 25);
			this.cmdClose.Text = "&Close";
			this.cmdClose.BackColor = System.Drawing.SystemColors.Control;
			this.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
			//
			// cmdEdit
			//
			this.cmdEdit.Name = "cmdEdit";
			this.cmdEdit.TabIndex = 8;
			this.cmdEdit.Location = new System.Drawing.Point(170, 388);
			this.cmdEdit.Size = new System.Drawing.Size(82, 25);
			this.cmdEdit.Text = "&Edit";
			this.cmdEdit.BackColor = System.Drawing.SystemColors.Control;
			this.cmdEdit.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdEdit.Click += new System.EventHandler(this.cmdEdit_Click);
			//
			// cmdDelete
			//
			this.cmdDelete.Name = "cmdDelete";
			this.cmdDelete.TabIndex = 9;
			this.cmdDelete.Location = new System.Drawing.Point(259, 388);
			this.cmdDelete.Size = new System.Drawing.Size(82, 25);
			this.cmdDelete.Text = "&Delete";
			this.cmdDelete.BackColor = System.Drawing.SystemColors.Control;
			this.cmdDelete.ForeColor = System.Drawing.SystemColors.ControlText;
			this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
			//
			// Label1_4
			//
			this.Label1_4.Name = "Label1_4";
			this.Label1_4.TabIndex = 19;
			this.Label1_4.AutoSize = true;
			this.Label1_4.Location = new System.Drawing.Point(8, 396);
			this.Label1_4.Size = new System.Drawing.Size(96, 13);
			this.Label1_4.Text = "* Required fields";
			this.Label1_4.BackColor = System.Drawing.SystemColors.Control;
			this.Label1_4.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.Label1_4.Font = new System.Drawing.Font("MS Sans Serif", 8.25F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// Image1
			//
			this.Image1.Name = "Image1";
			this.ToolTip1.SetToolTip(this.Image1, "View warnings");
			this.Image1.Location = new System.Drawing.Point(8, 8);
			this.Image1.Size = new System.Drawing.Size(32, 32);
			this.Image1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.Image1.BackColor = System.Drawing.SystemColors.Control;
			this.Image1.Image = ((System.Drawing.Image)(resources.GetObject("Image1.Image")));
			this.Image1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			//
			// Label19
			//
			this.Label19.Name = "Label19";
			this.Label19.TabIndex = 18;
			this.Label19.AutoSize = true;
			this.Label19.Location = new System.Drawing.Point(49, 8);
			this.Label19.Size = new System.Drawing.Size(34, 16);
			this.Label19.Text = "User";
			this.Label19.BackColor = System.Drawing.Color.Transparent;
			this.Label19.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			this.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.Label19.Font = new System.Drawing.Font("MS Sans Serif", 9.75F, ((System.Drawing.FontStyle)System.Drawing.FontStyle.Bold), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			//
			// Label4
			//
			this.Label4.Name = "Label4";
			this.Label4.TabIndex = 17;
			this.Label4.AutoSize = true;
			this.Label4.Location = new System.Drawing.Point(49, 32);
			this.Label4.Size = new System.Drawing.Size(178, 13);
			this.Label4.Text = "Set user information and access level";
			this.Label4.BackColor = System.Drawing.Color.Transparent;
			this.Label4.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(64)), ((System.Byte)(64)), ((System.Byte)(64)));
			//
			// frmUsersManage
			//
			this.ClientSize = new System.Drawing.Size(349, 419);
			this.Controls.Add(this.lstAccounts);
			this.Controls.Add(this.cmdClear);
			this.Controls.Add(this.cmdSave);
			this.Controls.Add(this.ctrlLiner1);
			this.Controls.Add(this.Frame1);
			this.Controls.Add(this.cmdClose);
			this.Controls.Add(this.cmdEdit);
			this.Controls.Add(this.cmdDelete);
			this.Controls.Add(this.Label1_4);
			this.Controls.Add(this.Image1);
			this.Controls.Add(this.Label19);
			this.Controls.Add(this.Label4);
			this.Name = "frmUsersManage";
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.MinimizeBox = true;
			this.MaximizeBox = false;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("frmUsersManage.Icon")));
			this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
			this.Load += new System.EventHandler(this.frmUsersManage_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmUsersManage_FormClosing);
			this.Text = "Users Management";
			this.Label1.SetIndex( Label1_2, System.Convert.ToInt16( 2 ) );
			this.Label1.SetIndex( Label1_0, System.Convert.ToInt16( 0 ) );
			this.Label1.SetIndex( Label1_1, System.Convert.ToInt16( 1 ) );
			this.Label1.SetIndex( Label1_3, System.Convert.ToInt16( 3 ) );
			this.Label1.SetIndex( Label1_4, System.Convert.ToInt16( 4 ) );
			((System.ComponentModel.ISupportInitialize)(this.Label1)).EndInit();
			this.txtPassword.ResumeLayout(false);
			this.Label1_2.ResumeLayout(false);
			this.Label1_0.ResumeLayout(false);
			this.Label1_1.ResumeLayout(false);
			this.Label1_3.ResumeLayout(false);
			this.lblId.ResumeLayout(false);
			this.Frame1.ResumeLayout(false);
			this.Label1_4.ResumeLayout(false);
			this.Label19.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion


		//=========================================================
		string CurrentEditedUser = "";

		private void cmdClear_Click(object sender, System.EventArgs e)
		{
			txtUsername.Text = String.Empty;
			txtUsername.Focus();
			ClearFields();
		}

		private void cmdDelete_Click(object sender, System.EventArgs e)
		{
			if (modFunctions.NoRecords(lstAccounts, "Please add/select a user")) return;
			if (MessageBox.Show("Are you sure you want to delete the user '"+lstAccounts.FocusedItem.Text+"'?", null, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)==DialogResult.Yes) {
				modConnection.ExecuteSql("Select * from Users");
				if (modConnection.rs.RecordCount==1) {
					MessageBox.Show("You cannot delete the last user", "Delete error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				modConnection.ExecuteSql("delete * from Users where Username = '"+lstAccounts.FocusedItem.Text+"'");
				LoadUsers();
			}
		}

		private void cmdEdit_Click(object sender, System.EventArgs e)
		{
			if (modFunctions.NoRecords(lstAccounts, "Please add/select a user")) return;
			modConnection.ExecuteSql("Select * from Users where Username = '"+lstAccounts.FocusedItem.Text+"'");
			txtUsername.Text = Convert.ToString(modConnection.rs.Fields["UserName"].Value);
			if (modConnection.rs.EOF) {
				MessageBox.Show("This user does not exist", null, MessageBoxButtons.OK, MessageBoxIcon.Information);
				txtUsername.Focus();
			} else {
				txtUsername.Text = Convert.ToString(modConnection.rs.Fields["UserName"].Value);
				CurrentEditedUser = txtUsername.Text;
				txtPassword.Text = Convert.ToString(modConnection.rs.Fields["Password"].Value);
				txtFullname.Text = Convert.ToString(modConnection.rs.Fields["Fullname"].Value);
				cboLevel.Text = Convert.ToString(modConnection.rs.Fields["RoleLevel"].Value);
				cmdSave.Text = "&Update";
			}
		}
		public void cmdEdit_Click()
		{
			cmdEdit_Click(cmdEdit, new System.EventArgs());
		}

		private void cmdSave_Click(object sender, System.EventArgs e)
		{
			string SecId;
			if (modFunctions.TextBoxEmpty(txtUsername)) return;
			if (modFunctions.TextBoxEmpty(txtPassword)) return;
			if (modFunctions.TextBoxEmpty(txtFullname)) return;
			if (modFunctions.ComboEmpty(cboLevel)) return;

			modConnection.ExecuteSql("Select * from Users where Username = '"+txtUsername.Text+"'");
					
			if (cmdSave.Text!="&Update") {
				if (!modConnection.rs.EOF && modConnection.rs.RecordCount>0) {
					MessageBox.Show("Add failed: Username already exists", null, MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}

				if (cboLevel.Text!="Administrator") {
					modConnection.ExecuteSql2("Select * from Users where level = 'Administrator'");
					if (modConnection.rs2.EOF) {
						MessageBox.Show("Update failed: No any Administrator found on accounts.  You are not allowed to change the level of this account", null, MessageBoxButtons.OK, MessageBoxIcon.Hand);
						return;
					}
				}
				if (!modMain.CurrentUserAdmin && cboLevel.Text=="Administrator") {
					MessageBox.Show("You cannot add another level without being 'Administrator'", null, MessageBoxButtons.OK, MessageBoxIcon.Information);
					cboLevel.Focus();
					return;
				}
				modConnection.rs.AddNew();
				modMain.msg = "Added new user "+txtUsername.Text;
			} else if (CurrentEditedUser!=txtUsername.Text) {
				modConnection.ExecuteSql2("Select * from Users where username = '"+txtUsername.Text+"'");
				if (!modConnection.rs2.EOF) {
					MessageBox.Show("Username '"+txtUsername.Text+"' already exists.", null, MessageBoxButtons.OK, MessageBoxIcon.Information);
					txtUsername.Focus();
					modFunctions.SelectAll(txtUsername);
					return;
				}
				modMain.msg = "Record for the user "+txtUsername.Text+" has been successfully updated";
			} else {
				modMain.msg = "Record for the user "+txtUsername.Text+" has been successfully updated";
			}
			modConnection.rs.Fields["UserName"].Value = txtUsername.Text;
			modConnection.rs.Fields["Password"].Value = txtPassword.Text;
			modConnection.rs.Fields["RoleLevel"].Value = cboLevel.Text;
			modConnection.rs.Fields["Fullname"].Value = txtFullname.Text;
			modConnection.rs.Update();
			modMain.LogStatus(modMain.msg);
			ClearFields();
			LoadUsers();

			if (modMain.CurrentUserAdmin) {
				Close();
			}
		}

		public void LoadUsers()
		{
			modConnection.ExecuteSql("Select * from Users");
			lstAccounts.Items.Clear();
			ListViewItem x;
			while (!modConnection.rs.EOF) {
				x = lstAccounts.Items.Add(Convert.ToString(modConnection.rs.Fields["UserName"].Value));
				VBto.SubItemsSetText(x, 1, Convert.ToString(modConnection.rs.Fields["Fullname"].Value));
				VBto.SubItemsSetText(x, 2, Convert.ToString(modConnection.rs.Fields["RoleLevel"].Value));
				modConnection.rs.MoveNext();
			}
		}

#if defUse_LoadUsersAvoidingWith
		public void LoadUsersAvoidingWith()
		{
			modConnection.ExecuteSql("Select * from Users");
			lstAccounts.Items.Clear();
			ListViewItem x;
			while (!modConnection.rs.EOF) {
				x = lstAccounts.Items.Add(Convert.ToString(modConnection.rs.Fields["UserName"].Value));
				VBto.SubItemsSetText(x, 1, Convert.ToString(modConnection.rs.Fields["Fullname"].Value));
				VBto.SubItemsSetText(x, 2, Convert.ToString(modConnection.rs.Fields["RoleLevel"].Value));
				modConnection.rs.MoveNext();
			}
		}
#endif


		public void ClearFields()
		{
			txtUsername.Text = String.Empty;
			txtPassword.Text = String.Empty;
			txtFullname.Text = String.Empty;
			cboLevel.SelectedIndex = -1;
			cmdSave.Text = "&Save";
		}

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void frmUsersManage_Load(object sender, System.EventArgs e)
		{
			modConnection.ExecuteSql("Select * from Levels");
			while (!modConnection.rs.EOF) {
				cboLevel.Items.Add(Convert.ToString(modConnection.rs.Fields["Level"].Value));
				modConnection.rs.MoveNext();
			}
			if (modMain.CurrentUserAdmin) {
				cboLevel.Text = "Administrator";
			} else {
				cboLevel.SelectedIndex = -1;
			}
			LoadUsers();
		}

		private void Form_Unload(ref short Cancel)
		{
			if (modMain.CurrentUserAdmin) {
				modConnection.ExecuteSql("Select * from Users");
				if (modConnection.rs.EOF) {
					MessageBox.Show("System has failed to initialized. Please contact your administrator"+"\n"+"\n"+"Status: analysing accounts configuration"+"\n"+"Error: No users found", null, MessageBoxButtons.OK, MessageBoxIcon.Hand);
					Application.Exit();
				}
				// frmxSplash.tmrLoad.Enabled = True
			}
			modMain.LogStatus("");
		}

		private void frmUsersManage_FormClosing(object sender, FormClosingEventArgs e)
		{
			short Cancel = 0;
			Form_Unload(ref Cancel);
			if (Cancel != 0) e.Cancel = true;
		}

		private void lstAccounts_DoubleClick(object sender, System.EventArgs e)
		{
			cmdEdit_Click();
		}

		private void txtFullname_Enter(object sender, System.EventArgs e)
		{
			modFunctions.SelectAll(txtFullname);
		}

		private void txtPassword_Enter(object sender, System.EventArgs e)
		{
			modFunctions.SelectAll(txtPassword);
		}

		private void txtUsername_Enter(object sender, System.EventArgs e)
		{
			modFunctions.SelectAll(txtUsername);
		}

	}
}